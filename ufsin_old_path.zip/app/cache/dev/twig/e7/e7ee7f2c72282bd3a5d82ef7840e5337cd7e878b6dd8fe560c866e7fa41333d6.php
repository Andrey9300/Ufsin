<?php

/* :otchet/ajax:proverka_narusheniya.html.twig */
class __TwigTemplate_84c1bb30bc8e8c1d2fbb71708b5393439b2481e045cb808b72b0c1f2f070763f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet/ajax:proverka_narusheniya.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_47cdaf7ccf2e20c057abea7ea47f2cb74c9bee5154bcbeec303a19588401b337 = $this->env->getExtension("native_profiler");
        $__internal_47cdaf7ccf2e20c057abea7ea47f2cb74c9bee5154bcbeec303a19588401b337->enter($__internal_47cdaf7ccf2e20c057abea7ea47f2cb74c9bee5154bcbeec303a19588401b337_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:proverka_narusheniya.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_47cdaf7ccf2e20c057abea7ea47f2cb74c9bee5154bcbeec303a19588401b337->leave($__internal_47cdaf7ccf2e20c057abea7ea47f2cb74c9bee5154bcbeec303a19588401b337_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_e96fa1973164c08adfbc9dd89cc7b5224fa8f35558821e173645eb5ab87e9e0e = $this->env->getExtension("native_profiler");
        $__internal_e96fa1973164c08adfbc9dd89cc7b5224fa8f35558821e173645eb5ab87e9e0e->enter($__internal_e96fa1973164c08adfbc9dd89cc7b5224fa8f35558821e173645eb5ab87e9e0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/proverka_menu.html", ":otchet/ajax:proverka_narusheniya.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Статистика нарушений по учреждениям и типам проверки</h3>
        
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetProverka/narusheniya\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>
    
    <div>В - выполнено, Н - невыполнено, Ч - частично, И - итого</div>
    <table class=\"table table-hover table-bordered numbers\" style=\"position:absolute; left:5px; font-size:14px;\">
        <thead>
            <tr>
                <td></td>
                <td colspan=\"16\">Плановые</td>
                <td colspan=\"12\">Внеплановые</td>
                <td colspan=\"8\" id=\"narusheniya\">Итог</td>
            </tr>
            <tr>
                <td>Учреждение</td>
                ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverkaType"]) ? $context["proverkaType"] : $this->getContext($context, "proverkaType")));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 37
            echo "                    <td colspan=\"4\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["type"], "name", array()), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "                <td colspan=\"4\">Плановые</td>
                <td colspan=\"4\">Внеплановые</td>
            </tr>
            <tr>
\t\t\t\t<td></td>
\t\t\t\t";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverkaType"]) ? $context["proverkaType"] : $this->getContext($context, "proverkaType")));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 45
            echo "\t\t\t\t\t<td>В</td>
\t\t\t\t\t<td>Н</td>
\t\t\t\t\t<td>Ч</td>
\t\t\t\t\t<td>И</td>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "\t\t\t\t<td>В</td>
\t\t\t\t<td>Н</td>
\t\t\t\t<td>Ч</td>
\t\t\t\t<td>И</td>
\t\t\t\t<td>В</td>
\t\t\t\t<td>Н</td>
\t\t\t\t<td>Ч</td>
\t\t\t\t<td>И</td>
            </tr>\t\t\t
        </thead>
        <tbody>
        
        ";
        // line 62
        $context["flag1"] = "0";
        // line 63
        echo "        ";
        $context["flag2"] = "0";
        // line 64
        echo "        ";
        $context["flag3"] = "0";
        // line 65
        echo "        ";
        $context["count1"] = "0";
        // line 66
        echo "        ";
        $context["count2"] = "0";
        // line 67
        echo "        ";
        $context["count3"] = "0";
        // line 68
        echo "        ";
        $context["count_all"] = "0";
        // line 69
        echo "        ";
        $context["count_P_V"] = "0";
        // line 70
        echo "        ";
        $context["count_P_N"] = "0";
        // line 71
        echo "        ";
        $context["count_P_CH"] = "0";
        // line 72
        echo "        ";
        $context["count_V_V"] = "0";
        // line 73
        echo "        ";
        $context["count_V_N"] = "0";
        // line 74
        echo "        ";
        $context["count_V_CH"] = "0";
        // line 75
        echo "        ";
        $context["otmetki"] = array(0 => "1", 1 => "0", 2 => "-1");
        // line 76
        echo "
        ";
        // line 77
        $context["cgsn_v"] = "0";
        // line 78
        echo "        ";
        $context["cgsn_n"] = "0";
        // line 79
        echo "        ";
        $context["cgsn_ch"] = "0";
        // line 80
        echo "        ";
        $context["kr_v"] = "0";
        // line 81
        echo "        ";
        $context["kr_n"] = "0";
        // line 82
        echo "        ";
        $context["kr_ch"] = "0";
        // line 83
        echo "        ";
        $context["inspec_v"] = "0";
        // line 84
        echo "        ";
        $context["inspec_n"] = "0";
        // line 85
        echo "        ";
        $context["inspec_ch"] = "0";
        // line 86
        echo "        ";
        $context["dk_v"] = "0";
        // line 87
        echo "        ";
        $context["dk_n"] = "0";
        // line 88
        echo "        ";
        $context["dk_ch"] = "0";
        // line 89
        echo "        ";
        $context["prok_v"] = "0";
        // line 90
        echo "        ";
        $context["prok_n"] = "0";
        // line 91
        echo "        ";
        $context["prok_ch"] = "0";
        // line 92
        echo "        ";
        $context["gal_v"] = "0";
        // line 93
        echo "        ";
        $context["gal_n"] = "0";
        // line 94
        echo "        ";
        $context["gal_ch"] = "0";
        // line 95
        echo "        ";
        $context["cgsn_v_v"] = "0";
        // line 96
        echo "        ";
        $context["cgsn_v_n"] = "0";
        // line 97
        echo "        ";
        $context["cgsn_v_ch"] = "0";
        // line 98
        echo "        
        
        ";
        // line 100
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverka_temp"]) ? $context["proverka_temp"] : $this->getContext($context, "proverka_temp")));
        foreach ($context['_seq'] as $context["_key"] => $context["proverka"]) {
            // line 101
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["proverka"]);
            foreach ($context['_seq'] as $context["key"] => $context["prov"]) {
                // line 102
                echo "                
                
                ";
                // line 104
                if (($context["key"] == "ЦГСЭН")) {
                    // line 105
                    echo "                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["prov"]);
                    foreach ($context['_seq'] as $context["k"] => $context["p"]) {
                        // line 106
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["p"]);
                        foreach ($context['_seq'] as $context["k1"] => $context["p1"]) {
                            // line 107
                            echo "                        
                            ";
                            // line 108
                            if (($context["k1"] == "1")) {
                                // line 109
                                echo "                                ";
                                $context["cgsn_v"] = ((isset($context["cgsn_v"]) ? $context["cgsn_v"] : $this->getContext($context, "cgsn_v")) + $context["p1"]);
                                // line 110
                                echo "                            ";
                            }
                            // line 111
                            echo "                            ";
                            if (($context["k1"] == "0")) {
                                // line 112
                                echo "                                ";
                                $context["cgsn_n"] = ((isset($context["cgsn_n"]) ? $context["cgsn_n"] : $this->getContext($context, "cgsn_n")) + $context["p1"]);
                                // line 113
                                echo "                            ";
                            }
                            // line 114
                            echo "                            ";
                            if (($context["k1"] == "-1")) {
                                // line 115
                                echo "                                ";
                                $context["cgsn_ch"] = ((isset($context["cgsn_ch"]) ? $context["cgsn_ch"] : $this->getContext($context, "cgsn_ch")) + $context["p1"]);
                                // line 116
                                echo "                            ";
                            }
                            // line 117
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['k1'], $context['p1'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 118
                        echo "                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['p'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 119
                    echo "                ";
                }
                // line 120
                echo "                
                ";
                // line 121
                if (($context["key"] == "Контрольная проверка")) {
                    // line 122
                    echo "                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["prov"]);
                    foreach ($context['_seq'] as $context["k"] => $context["p"]) {
                        // line 123
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["p"]);
                        foreach ($context['_seq'] as $context["k1"] => $context["p1"]) {
                            // line 124
                            echo "                        
                            ";
                            // line 125
                            if (($context["k1"] == "1")) {
                                // line 126
                                echo "                                ";
                                $context["kr_v"] = ((isset($context["kr_v"]) ? $context["kr_v"] : $this->getContext($context, "kr_v")) + $context["p1"]);
                                // line 127
                                echo "                            ";
                            }
                            // line 128
                            echo "                            ";
                            if (($context["k1"] == "0")) {
                                // line 129
                                echo "                                ";
                                $context["kr_n"] = ((isset($context["kr_n"]) ? $context["kr_n"] : $this->getContext($context, "kr_n")) + $context["p1"]);
                                // line 130
                                echo "                            ";
                            }
                            // line 131
                            echo "                            ";
                            if (($context["k1"] == "-1")) {
                                // line 132
                                echo "                                ";
                                $context["kr_ch"] = ((isset($context["kr_ch"]) ? $context["kr_ch"] : $this->getContext($context, "kr_ch")) + $context["p1"]);
                                // line 133
                                echo "                            ";
                            }
                            // line 134
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['k1'], $context['p1'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 135
                        echo "                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['p'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 136
                    echo "                ";
                }
                // line 137
                echo "                
                ";
                // line 138
                if (($context["key"] == "Инспектирование")) {
                    // line 139
                    echo "                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["prov"]);
                    foreach ($context['_seq'] as $context["k"] => $context["p"]) {
                        // line 140
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["p"]);
                        foreach ($context['_seq'] as $context["k1"] => $context["p1"]) {
                            // line 141
                            echo "                        
                            ";
                            // line 142
                            if (($context["k1"] == "1")) {
                                // line 143
                                echo "                                ";
                                $context["inspec_v"] = ((isset($context["inspec_v"]) ? $context["inspec_v"] : $this->getContext($context, "inspec_v")) + $context["p1"]);
                                // line 144
                                echo "                            ";
                            }
                            // line 145
                            echo "                            ";
                            if (($context["k1"] == "0")) {
                                // line 146
                                echo "                                ";
                                $context["inspec_n"] = ((isset($context["inspec_n"]) ? $context["inspec_n"] : $this->getContext($context, "inspec_n")) + $context["p1"]);
                                // line 147
                                echo "                            ";
                            }
                            // line 148
                            echo "                            ";
                            if (($context["k1"] == "-1")) {
                                // line 149
                                echo "                                ";
                                $context["inspec_ch"] = ((isset($context["inspec_ch"]) ? $context["inspec_ch"] : $this->getContext($context, "inspec_ch")) + $context["p1"]);
                                // line 150
                                echo "                            ";
                            }
                            // line 151
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['k1'], $context['p1'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 152
                        echo "                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['p'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 153
                    echo "                ";
                }
                // line 154
                echo "                
                ";
                // line 155
                if (($context["key"] == "День куратора")) {
                    // line 156
                    echo "                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["prov"]);
                    foreach ($context['_seq'] as $context["k"] => $context["p"]) {
                        // line 157
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["p"]);
                        foreach ($context['_seq'] as $context["k1"] => $context["p1"]) {
                            // line 158
                            echo "                        
                            ";
                            // line 159
                            if (($context["k1"] == "1")) {
                                // line 160
                                echo "                                ";
                                $context["dk_v"] = ((isset($context["dk_v"]) ? $context["dk_v"] : $this->getContext($context, "dk_v")) + $context["p1"]);
                                // line 161
                                echo "                            ";
                            }
                            // line 162
                            echo "                            ";
                            if (($context["k1"] == "0")) {
                                // line 163
                                echo "                                ";
                                $context["dk_n"] = ((isset($context["dk_n"]) ? $context["dk_n"] : $this->getContext($context, "dk_n")) + $context["p1"]);
                                // line 164
                                echo "                            ";
                            }
                            // line 165
                            echo "                            ";
                            if (($context["k1"] == "-1")) {
                                // line 166
                                echo "                                ";
                                $context["dk_ch"] = ((isset($context["dk_ch"]) ? $context["dk_ch"] : $this->getContext($context, "dk_ch")) + $context["p1"]);
                                // line 167
                                echo "                            ";
                            }
                            // line 168
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['k1'], $context['p1'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 169
                        echo "                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['p'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 170
                    echo "                ";
                }
                // line 171
                echo "                
                ";
                // line 172
                if (($context["key"] == "Прокуратура")) {
                    // line 173
                    echo "                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["prov"]);
                    foreach ($context['_seq'] as $context["k"] => $context["p"]) {
                        // line 174
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["p"]);
                        foreach ($context['_seq'] as $context["k1"] => $context["p1"]) {
                            // line 175
                            echo "                        
                            ";
                            // line 176
                            if (($context["k1"] == "1")) {
                                // line 177
                                echo "                                ";
                                $context["prok_v"] = ((isset($context["prok_v"]) ? $context["prok_v"] : $this->getContext($context, "prok_v")) + $context["p1"]);
                                // line 178
                                echo "                            ";
                            }
                            // line 179
                            echo "                            ";
                            if (($context["k1"] == "0")) {
                                // line 180
                                echo "                                ";
                                $context["prok_n"] = ((isset($context["prok_n"]) ? $context["prok_n"] : $this->getContext($context, "prok_n")) + $context["p1"]);
                                // line 181
                                echo "                            ";
                            }
                            // line 182
                            echo "                            ";
                            if (($context["k1"] == "-1")) {
                                // line 183
                                echo "                                ";
                                $context["prok_ch"] = ((isset($context["prok_ch"]) ? $context["prok_ch"] : $this->getContext($context, "prok_ch")) + $context["p1"]);
                                // line 184
                                echo "                            ";
                            }
                            // line 185
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['k1'], $context['p1'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 186
                        echo "                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['p'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 187
                    echo "                ";
                }
                // line 188
                echo "                
                ";
                // line 189
                if (($context["key"] == "По жалобе")) {
                    // line 190
                    echo "                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["prov"]);
                    foreach ($context['_seq'] as $context["k"] => $context["p"]) {
                        // line 191
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["p"]);
                        foreach ($context['_seq'] as $context["k1"] => $context["p1"]) {
                            // line 192
                            echo "                        
                            ";
                            // line 193
                            if (($context["k1"] == "1")) {
                                // line 194
                                echo "                                ";
                                $context["gal_v"] = ((isset($context["gal_v"]) ? $context["gal_v"] : $this->getContext($context, "gal_v")) + $context["p1"]);
                                // line 195
                                echo "                            ";
                            }
                            // line 196
                            echo "                            ";
                            if (($context["k1"] == "0")) {
                                // line 197
                                echo "                                ";
                                $context["gal_n"] = ((isset($context["gal_n"]) ? $context["gal_n"] : $this->getContext($context, "gal_n")) + $context["p1"]);
                                // line 198
                                echo "                            ";
                            }
                            // line 199
                            echo "                            ";
                            if (($context["k1"] == "-1")) {
                                // line 200
                                echo "                                ";
                                $context["gal_ch"] = ((isset($context["gal_ch"]) ? $context["gal_ch"] : $this->getContext($context, "gal_ch")) + $context["p1"]);
                                // line 201
                                echo "                            ";
                            }
                            // line 202
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['k1'], $context['p1'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 203
                        echo "                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['p'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 204
                    echo "                ";
                }
                // line 205
                echo "                
                ";
                // line 206
                if (($context["key"] == "ЦГСЭН внеплановая")) {
                    // line 207
                    echo "                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["prov"]);
                    foreach ($context['_seq'] as $context["k"] => $context["p"]) {
                        // line 208
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["p"]);
                        foreach ($context['_seq'] as $context["k1"] => $context["p1"]) {
                            // line 209
                            echo "                        
                            ";
                            // line 210
                            if (($context["k1"] == "1")) {
                                // line 211
                                echo "                                ";
                                $context["cgsn_v_v"] = ((isset($context["cgsn_v_v"]) ? $context["cgsn_v_v"] : $this->getContext($context, "cgsn_v_v")) + $context["p1"]);
                                // line 212
                                echo "                            ";
                            }
                            // line 213
                            echo "                            ";
                            if (($context["k1"] == "0")) {
                                // line 214
                                echo "                                ";
                                $context["cgsn_v_n"] = ((isset($context["cgsn_v_n"]) ? $context["cgsn_v_n"] : $this->getContext($context, "cgsn_v_n")) + $context["p1"]);
                                // line 215
                                echo "                            ";
                            }
                            // line 216
                            echo "                            ";
                            if (($context["k1"] == "-1")) {
                                // line 217
                                echo "                                ";
                                $context["cgsn_v_ch"] = ((isset($context["cgsn_v_ch"]) ? $context["cgsn_v_ch"] : $this->getContext($context, "cgsn_v_ch")) + $context["p1"]);
                                // line 218
                                echo "                            ";
                            }
                            // line 219
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['k1'], $context['p1'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 220
                        echo "                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['p'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 221
                    echo "                ";
                }
                // line 222
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['prov'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 223
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['proverka'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 224
        echo "
        ";
        // line 225
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverka_temp"]) ? $context["proverka_temp"] : $this->getContext($context, "proverka_temp")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["proverki"]) {
            // line 226
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 227
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "</td>
            ";
            // line 228
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["proverkaType"]) ? $context["proverkaType"] : $this->getContext($context, "proverkaType")));
            foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                // line 229
                echo "                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["proverki"]);
                foreach ($context['_seq'] as $context["key_proverka"] => $context["proverka"]) {
                    // line 230
                    echo "                    ";
                    if (($this->getAttribute($context["type"], "name", array()) == $context["key_proverka"])) {
                        // line 231
                        echo "                        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($context["proverka"]);
                        foreach ($context['_seq'] as $context["key"] => $context["otmetka"]) {
                            // line 232
                            echo "                 
                            ";
                            // line 233
                            $context['_parent'] = $context;
                            $context['_seq'] = twig_ensure_traversable($context["otmetka"]);
                            foreach ($context['_seq'] as $context["key"] => $context["count"]) {
                                // line 234
                                echo "                        
                                ";
                                // line 235
                                if ($this->getAttribute($context["otmetka"], "1", array(), "array", true, true)) {
                                    // line 236
                                    echo "                                    ";
                                    if (($context["key"] == "1")) {
                                        // line 237
                                        echo "                                        ";
                                        $context["count_all"] = ((isset($context["count_all"]) ? $context["count_all"] : $this->getContext($context, "count_all")) + $context["count"]);
                                        // line 238
                                        echo "                                        ";
                                        $context["count1"] = ((isset($context["count1"]) ? $context["count1"] : $this->getContext($context, "count1")) + $context["count"]);
                                        // line 239
                                        echo "                                        
                                        ";
                                        // line 240
                                        if ((((($context["key_proverka"] == "ЦГСЭН") || (                                        // line 241
$context["key_proverka"] == "Контрольная проверка")) || (                                        // line 242
$context["key_proverka"] == "Инспектирование")) || (                                        // line 243
$context["key_proverka"] == "День куратора"))) {
                                            // line 244
                                            echo "                                            ";
                                            $context["count_P_V"] = ((isset($context["count_P_V"]) ? $context["count_P_V"] : $this->getContext($context, "count_P_V")) + $context["count"]);
                                            // line 245
                                            echo "                                        ";
                                        } else {
                                            // line 246
                                            echo "                                            ";
                                            $context["count_V_V"] = ((isset($context["count_V_V"]) ? $context["count_V_V"] : $this->getContext($context, "count_V_V")) + $context["count"]);
                                            // line 247
                                            echo "                                        ";
                                        }
                                        // line 248
                                        echo "                                        
\t\t\t\t\t\t\t\t\t\t";
                                        // line 249
                                        $context["flag1"] = "1";
                                        // line 250
                                        echo "                                    ";
                                    }
                                    echo "    
                                ";
                                }
                                // line 252
                                echo "                                ";
                                if ($this->getAttribute($context["otmetka"], "0", array(), "array", true, true)) {
                                    // line 253
                                    echo "                                    ";
                                    if (($context["key"] == "0")) {
                                        // line 254
                                        echo "                                        ";
                                        $context["count_all"] = ((isset($context["count_all"]) ? $context["count_all"] : $this->getContext($context, "count_all")) + $context["count"]);
                                        // line 255
                                        echo "                                        ";
                                        $context["count2"] = ((isset($context["count2"]) ? $context["count2"] : $this->getContext($context, "count2")) + $context["count"]);
                                        // line 256
                                        echo "                                        
                                        ";
                                        // line 257
                                        if ((((($context["key_proverka"] == "ЦГСЭН") || (                                        // line 258
$context["key_proverka"] == "Контрольная проверка")) || (                                        // line 259
$context["key_proverka"] == "Инспектирование")) || (                                        // line 260
$context["key_proverka"] == "День куратора"))) {
                                            // line 261
                                            echo "                                            ";
                                            $context["count_P_N"] = ((isset($context["count_P_N"]) ? $context["count_P_N"] : $this->getContext($context, "count_P_N")) + $context["count"]);
                                            // line 262
                                            echo "                                        ";
                                        } else {
                                            // line 263
                                            echo "                                            ";
                                            $context["count_V_N"] = ((isset($context["count_V_N"]) ? $context["count_V_N"] : $this->getContext($context, "count_V_N")) + $context["count"]);
                                            // line 264
                                            echo "                                        ";
                                        }
                                        // line 265
                                        echo "                                        
\t\t\t\t\t\t\t\t\t\t";
                                        // line 266
                                        $context["flag2"] = "1";
                                        // line 267
                                        echo "                                    ";
                                    }
                                    echo "    
                                ";
                                }
                                // line 269
                                echo "                                ";
                                if ($this->getAttribute($context["otmetka"], "-1", array(), "array", true, true)) {
                                    // line 270
                                    echo "                                    ";
                                    if (($context["key"] == "-1")) {
                                        // line 271
                                        echo "                                        ";
                                        $context["count_all"] = ((isset($context["count_all"]) ? $context["count_all"] : $this->getContext($context, "count_all")) + $context["count"]);
                                        // line 272
                                        echo "\t\t\t\t\t\t\t\t\t\t";
                                        $context["count3"] = ((isset($context["count3"]) ? $context["count3"] : $this->getContext($context, "count3")) + $context["count"]);
                                        // line 273
                                        echo "\t\t\t\t\t\t\t\t\t\t
                                        ";
                                        // line 274
                                        if ((((($context["key_proverka"] == "ЦГСЭН") || (                                        // line 275
$context["key_proverka"] == "Контрольная проверка")) || (                                        // line 276
$context["key_proverka"] == "Инспектирование")) || (                                        // line 277
$context["key_proverka"] == "День куратора"))) {
                                            // line 278
                                            echo "                                            ";
                                            $context["count_P_CH"] = ((isset($context["count_P_CH"]) ? $context["count_P_CH"] : $this->getContext($context, "count_P_CH")) + $context["count"]);
                                            // line 279
                                            echo "                                        ";
                                        } else {
                                            // line 280
                                            echo "                                            ";
                                            $context["count_V_CH"] = ((isset($context["count_V_CH"]) ? $context["count_V_CH"] : $this->getContext($context, "count_V_CH")) + $context["count"]);
                                            // line 281
                                            echo "                                        ";
                                        }
                                        // line 282
                                        echo "                                        
\t\t\t\t\t\t\t\t\t\t";
                                        // line 283
                                        $context["flag3"] = "1";
                                        // line 284
                                        echo "                                    ";
                                    }
                                    echo "    
                                ";
                                }
                                // line 285
                                echo " 
                            ";
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['_iterated'], $context['key'], $context['count'], $context['_parent'], $context['loop']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            // line 287
                            echo "                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['key'], $context['otmetka'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        echo "   
                        
                    
                    ";
                    }
                    // line 291
                    echo "                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key_proverka'], $context['proverka'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 292
                echo "\t\t\t\t
                ";
                // line 293
                if (((isset($context["flag1"]) ? $context["flag1"] : $this->getContext($context, "flag1")) == "1")) {
                    echo "    
                    <td>";
                    // line 294
                    echo twig_escape_filter($this->env, (isset($context["count1"]) ? $context["count1"] : $this->getContext($context, "count1")), "html", null, true);
                    echo "</td>
                ";
                } else {
                    // line 296
                    echo "                    <td>-</td>
                ";
                }
                // line 298
                echo "                ";
                if (((isset($context["flag2"]) ? $context["flag2"] : $this->getContext($context, "flag2")) == "1")) {
                    echo "    
                    <td>";
                    // line 299
                    echo twig_escape_filter($this->env, (isset($context["count2"]) ? $context["count2"] : $this->getContext($context, "count2")), "html", null, true);
                    echo "</td>
                ";
                } else {
                    // line 301
                    echo "                    <td>-</td>
                ";
                }
                // line 303
                echo "                ";
                if (((isset($context["flag3"]) ? $context["flag3"] : $this->getContext($context, "flag3")) == "1")) {
                    echo "    
                    <td>";
                    // line 304
                    echo twig_escape_filter($this->env, (isset($context["count3"]) ? $context["count3"] : $this->getContext($context, "count3")), "html", null, true);
                    echo "</td>
                ";
                } else {
                    // line 306
                    echo "                    <td>-</td>
                ";
                }
                // line 308
                echo "                ";
                if ((isset($context["count_all"]) ? $context["count_all"] : $this->getContext($context, "count_all"))) {
                    echo "    
                    <td>";
                    // line 309
                    echo twig_escape_filter($this->env, (isset($context["count_all"]) ? $context["count_all"] : $this->getContext($context, "count_all")), "html", null, true);
                    echo "</td>
                ";
                } else {
                    // line 311
                    echo "                    <td>-</td>
                ";
                }
                // line 313
                echo "\t\t\t\t
\t\t\t\t";
                // line 314
                $context["flag1"] = "0";
                // line 315
                echo "\t\t\t\t";
                $context["flag2"] = "0";
                // line 316
                echo "\t\t\t\t";
                $context["flag3"] = "0";
                // line 317
                echo "\t\t\t\t";
                $context["count1"] = "0";
                // line 318
                echo "\t\t\t\t";
                $context["count2"] = "0";
                // line 319
                echo "\t\t\t\t";
                $context["count3"] = "0";
                // line 320
                echo "\t\t\t\t";
                $context["count_all"] = "0";
                // line 321
                echo "\t\t\t\t
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 322
            echo " 

\t\t\t\t<td>";
            // line 324
            echo twig_escape_filter($this->env, (isset($context["count_P_V"]) ? $context["count_P_V"] : $this->getContext($context, "count_P_V")), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 325
            echo twig_escape_filter($this->env, (isset($context["count_P_N"]) ? $context["count_P_N"] : $this->getContext($context, "count_P_N")), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 326
            echo twig_escape_filter($this->env, (isset($context["count_P_CH"]) ? $context["count_P_CH"] : $this->getContext($context, "count_P_CH")), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 327
            echo twig_escape_filter($this->env, (((isset($context["count_P_V"]) ? $context["count_P_V"] : $this->getContext($context, "count_P_V")) + (isset($context["count_P_N"]) ? $context["count_P_N"] : $this->getContext($context, "count_P_N"))) + (isset($context["count_P_CH"]) ? $context["count_P_CH"] : $this->getContext($context, "count_P_CH"))), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 328
            echo twig_escape_filter($this->env, (isset($context["count_V_V"]) ? $context["count_V_V"] : $this->getContext($context, "count_V_V")), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 329
            echo twig_escape_filter($this->env, (isset($context["count_V_N"]) ? $context["count_V_N"] : $this->getContext($context, "count_V_N")), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 330
            echo twig_escape_filter($this->env, (isset($context["count_V_CH"]) ? $context["count_V_CH"] : $this->getContext($context, "count_V_CH")), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 331
            echo twig_escape_filter($this->env, (((isset($context["count_V_V"]) ? $context["count_V_V"] : $this->getContext($context, "count_V_V")) + (isset($context["count_V_N"]) ? $context["count_V_N"] : $this->getContext($context, "count_V_N"))) + (isset($context["count_V_CH"]) ? $context["count_V_CH"] : $this->getContext($context, "count_V_CH"))), "html", null, true);
            echo "</td>

                
                ";
            // line 334
            $context["count_P_V"] = "0";
            // line 335
            echo "                ";
            $context["count_P_N"] = "0";
            // line 336
            echo "                ";
            $context["count_P_CH"] = "0";
            // line 337
            echo "                ";
            $context["count_V_V"] = "0";
            // line 338
            echo "                ";
            $context["count_V_N"] = "0";
            // line 339
            echo "                ";
            $context["count_V_CH"] = "0";
            // line 340
            echo "
            </tr> 
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['proverki'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 343
        echo "        </tbody>
        <tfoot>
            <tr>
                <td rowspan=\"4\" style=\"padding-top:50px\">Всего</td>
\t\t\t\t<td>";
        // line 347
        echo twig_escape_filter($this->env, (isset($context["cgsn_v"]) ? $context["cgsn_v"] : $this->getContext($context, "cgsn_v")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 348
        echo twig_escape_filter($this->env, (isset($context["cgsn_n"]) ? $context["cgsn_n"] : $this->getContext($context, "cgsn_n")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 349
        echo twig_escape_filter($this->env, (isset($context["cgsn_ch"]) ? $context["cgsn_ch"] : $this->getContext($context, "cgsn_ch")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 350
        echo twig_escape_filter($this->env, (((isset($context["cgsn_v"]) ? $context["cgsn_v"] : $this->getContext($context, "cgsn_v")) + (isset($context["cgsn_n"]) ? $context["cgsn_n"] : $this->getContext($context, "cgsn_n"))) + (isset($context["cgsn_ch"]) ? $context["cgsn_ch"] : $this->getContext($context, "cgsn_ch"))), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 351
        echo twig_escape_filter($this->env, (isset($context["kr_v"]) ? $context["kr_v"] : $this->getContext($context, "kr_v")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 352
        echo twig_escape_filter($this->env, (isset($context["kr_n"]) ? $context["kr_n"] : $this->getContext($context, "kr_n")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 353
        echo twig_escape_filter($this->env, (isset($context["kr_ch"]) ? $context["kr_ch"] : $this->getContext($context, "kr_ch")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 354
        echo twig_escape_filter($this->env, (((isset($context["kr_v"]) ? $context["kr_v"] : $this->getContext($context, "kr_v")) + (isset($context["kr_n"]) ? $context["kr_n"] : $this->getContext($context, "kr_n"))) + (isset($context["kr_ch"]) ? $context["kr_ch"] : $this->getContext($context, "kr_ch"))), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 355
        echo twig_escape_filter($this->env, (isset($context["inspec_v"]) ? $context["inspec_v"] : $this->getContext($context, "inspec_v")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 356
        echo twig_escape_filter($this->env, (isset($context["inspec_n"]) ? $context["inspec_n"] : $this->getContext($context, "inspec_n")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 357
        echo twig_escape_filter($this->env, (isset($context["inspec_ch"]) ? $context["inspec_ch"] : $this->getContext($context, "inspec_ch")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 358
        echo twig_escape_filter($this->env, (((isset($context["inspec_v"]) ? $context["inspec_v"] : $this->getContext($context, "inspec_v")) + (isset($context["inspec_n"]) ? $context["inspec_n"] : $this->getContext($context, "inspec_n"))) + (isset($context["inspec_ch"]) ? $context["inspec_ch"] : $this->getContext($context, "inspec_ch"))), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 359
        echo twig_escape_filter($this->env, (isset($context["dk_v"]) ? $context["dk_v"] : $this->getContext($context, "dk_v")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 360
        echo twig_escape_filter($this->env, (isset($context["dk_n"]) ? $context["dk_n"] : $this->getContext($context, "dk_n")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 361
        echo twig_escape_filter($this->env, (isset($context["dk_ch"]) ? $context["dk_ch"] : $this->getContext($context, "dk_ch")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 362
        echo twig_escape_filter($this->env, (((isset($context["dk_v"]) ? $context["dk_v"] : $this->getContext($context, "dk_v")) + (isset($context["dk_n"]) ? $context["dk_n"] : $this->getContext($context, "dk_n"))) + (isset($context["dk_ch"]) ? $context["dk_ch"] : $this->getContext($context, "dk_ch"))), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 363
        echo twig_escape_filter($this->env, (isset($context["prok_v"]) ? $context["prok_v"] : $this->getContext($context, "prok_v")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 364
        echo twig_escape_filter($this->env, (isset($context["prok_n"]) ? $context["prok_n"] : $this->getContext($context, "prok_n")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 365
        echo twig_escape_filter($this->env, (isset($context["prok_ch"]) ? $context["prok_ch"] : $this->getContext($context, "prok_ch")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 366
        echo twig_escape_filter($this->env, (((isset($context["prok_v"]) ? $context["prok_v"] : $this->getContext($context, "prok_v")) + (isset($context["prok_n"]) ? $context["prok_n"] : $this->getContext($context, "prok_n"))) + (isset($context["prok_ch"]) ? $context["prok_ch"] : $this->getContext($context, "prok_ch"))), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 367
        echo twig_escape_filter($this->env, (isset($context["gal_v"]) ? $context["gal_v"] : $this->getContext($context, "gal_v")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 368
        echo twig_escape_filter($this->env, (isset($context["gal_n"]) ? $context["gal_n"] : $this->getContext($context, "gal_n")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 369
        echo twig_escape_filter($this->env, (isset($context["gal_ch"]) ? $context["gal_ch"] : $this->getContext($context, "gal_ch")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 370
        echo twig_escape_filter($this->env, (((isset($context["gal_v"]) ? $context["gal_v"] : $this->getContext($context, "gal_v")) + (isset($context["gal_n"]) ? $context["gal_n"] : $this->getContext($context, "gal_n"))) + (isset($context["gal_ch"]) ? $context["gal_ch"] : $this->getContext($context, "gal_ch"))), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 371
        echo twig_escape_filter($this->env, (isset($context["cgsn_v_v"]) ? $context["cgsn_v_v"] : $this->getContext($context, "cgsn_v_v")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 372
        echo twig_escape_filter($this->env, (isset($context["cgsn_v_n"]) ? $context["cgsn_v_n"] : $this->getContext($context, "cgsn_v_n")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 373
        echo twig_escape_filter($this->env, (isset($context["cgsn_v_ch"]) ? $context["cgsn_v_ch"] : $this->getContext($context, "cgsn_v_ch")), "html", null, true);
        echo "</td>
\t\t\t\t<td>";
        // line 374
        echo twig_escape_filter($this->env, (((isset($context["cgsn_v_v"]) ? $context["cgsn_v_v"] : $this->getContext($context, "cgsn_v_v")) + (isset($context["cgsn_v_n"]) ? $context["cgsn_v_n"] : $this->getContext($context, "cgsn_v_n"))) + (isset($context["cgsn_v_ch"]) ? $context["cgsn_v_ch"] : $this->getContext($context, "cgsn_v_ch"))), "html", null, true);
        echo "</td>
                <td style=\"text-align:center;padding-top:50px\" colspan=\"8\" rowspan=\"4\" id=\"vsego\">";
        // line 375
        echo twig_escape_filter($this->env, (((((((((((((((((((((isset($context["cgsn_v"]) ? $context["cgsn_v"] : $this->getContext($context, "cgsn_v")) + (isset($context["kr_v"]) ? $context["kr_v"] : $this->getContext($context, "kr_v"))) + (isset($context["inspec_v"]) ? $context["inspec_v"] : $this->getContext($context, "inspec_v"))) + (isset($context["dk_v"]) ? $context["dk_v"] : $this->getContext($context, "dk_v"))) + (isset($context["cgsn_n"]) ? $context["cgsn_n"] : $this->getContext($context, "cgsn_n"))) + (isset($context["kr_n"]) ? $context["kr_n"] : $this->getContext($context, "kr_n"))) + (isset($context["inspec_n"]) ? $context["inspec_n"] : $this->getContext($context, "inspec_n"))) + (isset($context["dk_n"]) ? $context["dk_n"] : $this->getContext($context, "dk_n"))) + (isset($context["cgsn_ch"]) ? $context["cgsn_ch"] : $this->getContext($context, "cgsn_ch"))) + (isset($context["kr_ch"]) ? $context["kr_ch"] : $this->getContext($context, "kr_ch"))) + (isset($context["inspec_ch"]) ? $context["inspec_ch"] : $this->getContext($context, "inspec_ch"))) + (isset($context["dk_ch"]) ? $context["dk_ch"] : $this->getContext($context, "dk_ch"))) + (isset($context["prok_v"]) ? $context["prok_v"] : $this->getContext($context, "prok_v"))) + (isset($context["gal_v"]) ? $context["gal_v"] : $this->getContext($context, "gal_v"))) + (isset($context["cgsn_v_v"]) ? $context["cgsn_v_v"] : $this->getContext($context, "cgsn_v_v"))) + (isset($context["prok_n"]) ? $context["prok_n"] : $this->getContext($context, "prok_n"))) + (isset($context["gal_n"]) ? $context["gal_n"] : $this->getContext($context, "gal_n"))) + (isset($context["cgsn_v_n"]) ? $context["cgsn_v_n"] : $this->getContext($context, "cgsn_v_n"))) + (isset($context["prok_ch"]) ? $context["prok_ch"] : $this->getContext($context, "prok_ch"))) + (isset($context["gal_ch"]) ? $context["gal_ch"] : $this->getContext($context, "gal_ch"))) + (isset($context["cgsn_v_ch"]) ? $context["cgsn_v_ch"] : $this->getContext($context, "cgsn_v_ch"))), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (((((((isset($context["cgsn_v"]) ? $context["cgsn_v"] : $this->getContext($context, "cgsn_v")) + (isset($context["kr_v"]) ? $context["kr_v"] : $this->getContext($context, "kr_v"))) + (isset($context["inspec_v"]) ? $context["inspec_v"] : $this->getContext($context, "inspec_v"))) + (isset($context["dk_v"]) ? $context["dk_v"] : $this->getContext($context, "dk_v"))) + (isset($context["prok_v"]) ? $context["prok_v"] : $this->getContext($context, "prok_v"))) + (isset($context["gal_v"]) ? $context["gal_v"] : $this->getContext($context, "gal_v"))) + (isset($context["cgsn_v_v"]) ? $context["cgsn_v_v"] : $this->getContext($context, "cgsn_v_v"))), "html", null, true);
        echo ")</td>
            </tr>  
            <tr>
                <td colspan=\"16\">Плановые</td>  
                <td colspan=\"12\">Внеплановые</td> 
            </tr>
            <tr>
                <td colspan=\"4\">В</td>  
                <td colspan=\"4\">Н</td>  
                <td colspan=\"4\">Ч</td>  
                <td colspan=\"4\">И</td>  
                <td colspan=\"4\">В</td>  
                <td colspan=\"4\">Н</td>  
                <td colspan=\"2\">Ч</td>  
                <td colspan=\"2\">И</td>  
            </tr>
            <tr>
                <td colspan=\"4\">";
        // line 392
        echo twig_escape_filter($this->env, ((((isset($context["cgsn_v"]) ? $context["cgsn_v"] : $this->getContext($context, "cgsn_v")) + (isset($context["kr_v"]) ? $context["kr_v"] : $this->getContext($context, "kr_v"))) + (isset($context["inspec_v"]) ? $context["inspec_v"] : $this->getContext($context, "inspec_v"))) + (isset($context["dk_v"]) ? $context["dk_v"] : $this->getContext($context, "dk_v"))), "html", null, true);
        echo "</td>  
                <td colspan=\"4\">";
        // line 393
        echo twig_escape_filter($this->env, ((((isset($context["cgsn_n"]) ? $context["cgsn_n"] : $this->getContext($context, "cgsn_n")) + (isset($context["kr_n"]) ? $context["kr_n"] : $this->getContext($context, "kr_n"))) + (isset($context["inspec_n"]) ? $context["inspec_n"] : $this->getContext($context, "inspec_n"))) + (isset($context["dk_n"]) ? $context["dk_n"] : $this->getContext($context, "dk_n"))), "html", null, true);
        echo "</td>  
                <td colspan=\"4\">";
        // line 394
        echo twig_escape_filter($this->env, ((((isset($context["cgsn_ch"]) ? $context["cgsn_ch"] : $this->getContext($context, "cgsn_ch")) + (isset($context["kr_ch"]) ? $context["kr_ch"] : $this->getContext($context, "kr_ch"))) + (isset($context["inspec_ch"]) ? $context["inspec_ch"] : $this->getContext($context, "inspec_ch"))) + (isset($context["dk_ch"]) ? $context["dk_ch"] : $this->getContext($context, "dk_ch"))), "html", null, true);
        echo "</td>  
                <td colspan=\"4\">";
        // line 395
        echo twig_escape_filter($this->env, ((((((((((((isset($context["cgsn_v"]) ? $context["cgsn_v"] : $this->getContext($context, "cgsn_v")) + (isset($context["kr_v"]) ? $context["kr_v"] : $this->getContext($context, "kr_v"))) + (isset($context["inspec_v"]) ? $context["inspec_v"] : $this->getContext($context, "inspec_v"))) + (isset($context["dk_v"]) ? $context["dk_v"] : $this->getContext($context, "dk_v"))) + (isset($context["cgsn_n"]) ? $context["cgsn_n"] : $this->getContext($context, "cgsn_n"))) + (isset($context["kr_n"]) ? $context["kr_n"] : $this->getContext($context, "kr_n"))) + (isset($context["inspec_n"]) ? $context["inspec_n"] : $this->getContext($context, "inspec_n"))) + (isset($context["dk_n"]) ? $context["dk_n"] : $this->getContext($context, "dk_n"))) + (isset($context["cgsn_ch"]) ? $context["cgsn_ch"] : $this->getContext($context, "cgsn_ch"))) + (isset($context["kr_ch"]) ? $context["kr_ch"] : $this->getContext($context, "kr_ch"))) + (isset($context["inspec_ch"]) ? $context["inspec_ch"] : $this->getContext($context, "inspec_ch"))) + (isset($context["dk_ch"]) ? $context["dk_ch"] : $this->getContext($context, "dk_ch"))), "html", null, true);
        echo "</td>  
                <td colspan=\"4\">";
        // line 396
        echo twig_escape_filter($this->env, (((isset($context["prok_v"]) ? $context["prok_v"] : $this->getContext($context, "prok_v")) + (isset($context["gal_v"]) ? $context["gal_v"] : $this->getContext($context, "gal_v"))) + (isset($context["cgsn_v_v"]) ? $context["cgsn_v_v"] : $this->getContext($context, "cgsn_v_v"))), "html", null, true);
        echo "</td>  
                <td colspan=\"4\">";
        // line 397
        echo twig_escape_filter($this->env, (((isset($context["prok_n"]) ? $context["prok_n"] : $this->getContext($context, "prok_n")) + (isset($context["gal_n"]) ? $context["gal_n"] : $this->getContext($context, "gal_n"))) + (isset($context["cgsn_v_n"]) ? $context["cgsn_v_n"] : $this->getContext($context, "cgsn_v_n"))), "html", null, true);
        echo "</td>  
                <td colspan=\"2\">";
        // line 398
        echo twig_escape_filter($this->env, (((isset($context["prok_ch"]) ? $context["prok_ch"] : $this->getContext($context, "prok_ch")) + (isset($context["gal_ch"]) ? $context["gal_ch"] : $this->getContext($context, "gal_ch"))) + (isset($context["cgsn_v_ch"]) ? $context["cgsn_v_ch"] : $this->getContext($context, "cgsn_v_ch"))), "html", null, true);
        echo "</td>  
                <td colspan=\"2\">";
        // line 399
        echo twig_escape_filter($this->env, (((((((((isset($context["prok_v"]) ? $context["prok_v"] : $this->getContext($context, "prok_v")) + (isset($context["gal_v"]) ? $context["gal_v"] : $this->getContext($context, "gal_v"))) + (isset($context["cgsn_v_v"]) ? $context["cgsn_v_v"] : $this->getContext($context, "cgsn_v_v"))) + (isset($context["prok_n"]) ? $context["prok_n"] : $this->getContext($context, "prok_n"))) + (isset($context["gal_n"]) ? $context["gal_n"] : $this->getContext($context, "gal_n"))) + (isset($context["cgsn_v_n"]) ? $context["cgsn_v_n"] : $this->getContext($context, "cgsn_v_n"))) + (isset($context["prok_ch"]) ? $context["prok_ch"] : $this->getContext($context, "prok_ch"))) + (isset($context["gal_ch"]) ? $context["gal_ch"] : $this->getContext($context, "gal_ch"))) + (isset($context["cgsn_v_ch"]) ? $context["cgsn_v_ch"] : $this->getContext($context, "cgsn_v_ch"))), "html", null, true);
        echo "</td> 
            </tr>\t\t\t
        </tfoot>
        
    </table>
</div>
";
        
        $__internal_e96fa1973164c08adfbc9dd89cc7b5224fa8f35558821e173645eb5ab87e9e0e->leave($__internal_e96fa1973164c08adfbc9dd89cc7b5224fa8f35558821e173645eb5ab87e9e0e_prof);

    }

    // line 407
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_50890fda74107b4be5c1ac7b980f4089f84ce879c1d5a610efdb725dab423c2e = $this->env->getExtension("native_profiler");
        $__internal_50890fda74107b4be5c1ac7b980f4089f84ce879c1d5a610efdb725dab423c2e->enter($__internal_50890fda74107b4be5c1ac7b980f4089f84ce879c1d5a610efdb725dab423c2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 408
        echo "
";
        
        $__internal_50890fda74107b4be5c1ac7b980f4089f84ce879c1d5a610efdb725dab423c2e->leave($__internal_50890fda74107b4be5c1ac7b980f4089f84ce879c1d5a610efdb725dab423c2e_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:proverka_narusheniya.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1232 => 408,  1226 => 407,  1212 => 399,  1208 => 398,  1204 => 397,  1200 => 396,  1196 => 395,  1192 => 394,  1188 => 393,  1184 => 392,  1162 => 375,  1158 => 374,  1154 => 373,  1150 => 372,  1146 => 371,  1142 => 370,  1138 => 369,  1134 => 368,  1130 => 367,  1126 => 366,  1122 => 365,  1118 => 364,  1114 => 363,  1110 => 362,  1106 => 361,  1102 => 360,  1098 => 359,  1094 => 358,  1090 => 357,  1086 => 356,  1082 => 355,  1078 => 354,  1074 => 353,  1070 => 352,  1066 => 351,  1062 => 350,  1058 => 349,  1054 => 348,  1050 => 347,  1044 => 343,  1028 => 340,  1025 => 339,  1022 => 338,  1019 => 337,  1016 => 336,  1013 => 335,  1011 => 334,  1005 => 331,  1001 => 330,  997 => 329,  993 => 328,  989 => 327,  985 => 326,  981 => 325,  977 => 324,  973 => 322,  966 => 321,  963 => 320,  960 => 319,  957 => 318,  954 => 317,  951 => 316,  948 => 315,  946 => 314,  943 => 313,  939 => 311,  934 => 309,  929 => 308,  925 => 306,  920 => 304,  915 => 303,  911 => 301,  906 => 299,  901 => 298,  897 => 296,  892 => 294,  888 => 293,  885 => 292,  879 => 291,  868 => 287,  861 => 285,  855 => 284,  853 => 283,  850 => 282,  847 => 281,  844 => 280,  841 => 279,  838 => 278,  836 => 277,  835 => 276,  834 => 275,  833 => 274,  830 => 273,  827 => 272,  824 => 271,  821 => 270,  818 => 269,  812 => 267,  810 => 266,  807 => 265,  804 => 264,  801 => 263,  798 => 262,  795 => 261,  793 => 260,  792 => 259,  791 => 258,  790 => 257,  787 => 256,  784 => 255,  781 => 254,  778 => 253,  775 => 252,  769 => 250,  767 => 249,  764 => 248,  761 => 247,  758 => 246,  755 => 245,  752 => 244,  750 => 243,  749 => 242,  748 => 241,  747 => 240,  744 => 239,  741 => 238,  738 => 237,  735 => 236,  733 => 235,  730 => 234,  726 => 233,  723 => 232,  718 => 231,  715 => 230,  710 => 229,  706 => 228,  702 => 227,  697 => 226,  680 => 225,  677 => 224,  671 => 223,  665 => 222,  662 => 221,  656 => 220,  650 => 219,  647 => 218,  644 => 217,  641 => 216,  638 => 215,  635 => 214,  632 => 213,  629 => 212,  626 => 211,  624 => 210,  621 => 209,  616 => 208,  611 => 207,  609 => 206,  606 => 205,  603 => 204,  597 => 203,  591 => 202,  588 => 201,  585 => 200,  582 => 199,  579 => 198,  576 => 197,  573 => 196,  570 => 195,  567 => 194,  565 => 193,  562 => 192,  557 => 191,  552 => 190,  550 => 189,  547 => 188,  544 => 187,  538 => 186,  532 => 185,  529 => 184,  526 => 183,  523 => 182,  520 => 181,  517 => 180,  514 => 179,  511 => 178,  508 => 177,  506 => 176,  503 => 175,  498 => 174,  493 => 173,  491 => 172,  488 => 171,  485 => 170,  479 => 169,  473 => 168,  470 => 167,  467 => 166,  464 => 165,  461 => 164,  458 => 163,  455 => 162,  452 => 161,  449 => 160,  447 => 159,  444 => 158,  439 => 157,  434 => 156,  432 => 155,  429 => 154,  426 => 153,  420 => 152,  414 => 151,  411 => 150,  408 => 149,  405 => 148,  402 => 147,  399 => 146,  396 => 145,  393 => 144,  390 => 143,  388 => 142,  385 => 141,  380 => 140,  375 => 139,  373 => 138,  370 => 137,  367 => 136,  361 => 135,  355 => 134,  352 => 133,  349 => 132,  346 => 131,  343 => 130,  340 => 129,  337 => 128,  334 => 127,  331 => 126,  329 => 125,  326 => 124,  321 => 123,  316 => 122,  314 => 121,  311 => 120,  308 => 119,  302 => 118,  296 => 117,  293 => 116,  290 => 115,  287 => 114,  284 => 113,  281 => 112,  278 => 111,  275 => 110,  272 => 109,  270 => 108,  267 => 107,  262 => 106,  257 => 105,  255 => 104,  251 => 102,  246 => 101,  242 => 100,  238 => 98,  235 => 97,  232 => 96,  229 => 95,  226 => 94,  223 => 93,  220 => 92,  217 => 91,  214 => 90,  211 => 89,  208 => 88,  205 => 87,  202 => 86,  199 => 85,  196 => 84,  193 => 83,  190 => 82,  187 => 81,  184 => 80,  181 => 79,  178 => 78,  176 => 77,  173 => 76,  170 => 75,  167 => 74,  164 => 73,  161 => 72,  158 => 71,  155 => 70,  152 => 69,  149 => 68,  146 => 67,  143 => 66,  140 => 65,  137 => 64,  134 => 63,  132 => 62,  118 => 50,  108 => 45,  104 => 44,  97 => 39,  88 => 37,  84 => 36,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/proverka_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Статистика нарушений по учреждениям и типам проверки</h3>*/
/*         */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetProverka/narusheniya" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/*     */
/*     <div>В - выполнено, Н - невыполнено, Ч - частично, И - итого</div>*/
/*     <table class="table table-hover table-bordered numbers" style="position:absolute; left:5px; font-size:14px;">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 <td colspan="16">Плановые</td>*/
/*                 <td colspan="12">Внеплановые</td>*/
/*                 <td colspan="8" id="narusheniya">Итог</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <td>Учреждение</td>*/
/*                 {% for type in proverkaType %}*/
/*                     <td colspan="4">{{type.name}}</td>*/
/*                 {% endfor %}*/
/*                 <td colspan="4">Плановые</td>*/
/*                 <td colspan="4">Внеплановые</td>*/
/*             </tr>*/
/*             <tr>*/
/* 				<td></td>*/
/* 				{% for type in proverkaType %}*/
/* 					<td>В</td>*/
/* 					<td>Н</td>*/
/* 					<td>Ч</td>*/
/* 					<td>И</td>*/
/* 				{% endfor %}*/
/* 				<td>В</td>*/
/* 				<td>Н</td>*/
/* 				<td>Ч</td>*/
/* 				<td>И</td>*/
/* 				<td>В</td>*/
/* 				<td>Н</td>*/
/* 				<td>Ч</td>*/
/* 				<td>И</td>*/
/*             </tr>			*/
/*         </thead>*/
/*         <tbody>*/
/*         */
/*         {% set flag1 = "0" %}*/
/*         {% set flag2 = "0" %}*/
/*         {% set flag3 = "0" %}*/
/*         {% set count1 = "0" %}*/
/*         {% set count2 = "0" %}*/
/*         {% set count3 = "0" %}*/
/*         {% set count_all = "0" %}*/
/*         {% set count_P_V = "0" %}*/
/*         {% set count_P_N = "0" %}*/
/*         {% set count_P_CH = "0" %}*/
/*         {% set count_V_V = "0" %}*/
/*         {% set count_V_N = "0" %}*/
/*         {% set count_V_CH = "0" %}*/
/*         {% set otmetki = ["1", "0", "-1"] %}*/
/* */
/*         {% set cgsn_v = "0" %}*/
/*         {% set cgsn_n = "0" %}*/
/*         {% set cgsn_ch = "0" %}*/
/*         {% set kr_v = "0" %}*/
/*         {% set kr_n = "0" %}*/
/*         {% set kr_ch = "0" %}*/
/*         {% set inspec_v = "0" %}*/
/*         {% set inspec_n = "0" %}*/
/*         {% set inspec_ch = "0" %}*/
/*         {% set dk_v = "0" %}*/
/*         {% set dk_n = "0" %}*/
/*         {% set dk_ch = "0" %}*/
/*         {% set prok_v = "0" %}*/
/*         {% set prok_n = "0" %}*/
/*         {% set prok_ch = "0" %}*/
/*         {% set gal_v = "0" %}*/
/*         {% set gal_n = "0" %}*/
/*         {% set gal_ch = "0" %}*/
/*         {% set cgsn_v_v = "0" %}*/
/*         {% set cgsn_v_n = "0" %}*/
/*         {% set cgsn_v_ch = "0" %}*/
/*         */
/*         */
/*         {% for proverka in proverka_temp %}*/
/*             {% for key, prov in proverka %}*/
/*                 */
/*                 */
/*                 {% if key == "ЦГСЭН" %}*/
/*                     {% for k, p in prov %}*/
/*                         {% for k1, p1 in p %}*/
/*                         */
/*                             {% if k1 == "1" %}*/
/*                                 {% set cgsn_v = cgsn_v + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "0" %}*/
/*                                 {% set cgsn_n = cgsn_n + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "-1" %}*/
/*                                 {% set cgsn_ch = cgsn_ch + p1 %}*/
/*                             {% endif %}*/
/*                         {% endfor %}*/
/*                     {% endfor %}*/
/*                 {% endif %}*/
/*                 */
/*                 {% if key == "Контрольная проверка" %}*/
/*                     {% for k, p in prov %}*/
/*                         {% for k1, p1 in p %}*/
/*                         */
/*                             {% if k1 == "1" %}*/
/*                                 {% set kr_v = kr_v + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "0" %}*/
/*                                 {% set kr_n = kr_n + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "-1" %}*/
/*                                 {% set kr_ch = kr_ch + p1 %}*/
/*                             {% endif %}*/
/*                         {% endfor %}*/
/*                     {% endfor %}*/
/*                 {% endif %}*/
/*                 */
/*                 {% if key == "Инспектирование" %}*/
/*                     {% for k, p in prov %}*/
/*                         {% for k1, p1 in p %}*/
/*                         */
/*                             {% if k1 == "1" %}*/
/*                                 {% set inspec_v = inspec_v + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "0" %}*/
/*                                 {% set inspec_n = inspec_n + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "-1" %}*/
/*                                 {% set inspec_ch = inspec_ch + p1 %}*/
/*                             {% endif %}*/
/*                         {% endfor %}*/
/*                     {% endfor %}*/
/*                 {% endif %}*/
/*                 */
/*                 {% if key == "День куратора" %}*/
/*                     {% for k, p in prov %}*/
/*                         {% for k1, p1 in p %}*/
/*                         */
/*                             {% if k1 == "1" %}*/
/*                                 {% set dk_v = dk_v + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "0" %}*/
/*                                 {% set dk_n = dk_n + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "-1" %}*/
/*                                 {% set dk_ch = dk_ch + p1 %}*/
/*                             {% endif %}*/
/*                         {% endfor %}*/
/*                     {% endfor %}*/
/*                 {% endif %}*/
/*                 */
/*                 {% if key == "Прокуратура" %}*/
/*                     {% for k, p in prov %}*/
/*                         {% for k1, p1 in p %}*/
/*                         */
/*                             {% if k1 == "1" %}*/
/*                                 {% set prok_v = prok_v + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "0" %}*/
/*                                 {% set prok_n = prok_n + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "-1" %}*/
/*                                 {% set prok_ch = prok_ch + p1 %}*/
/*                             {% endif %}*/
/*                         {% endfor %}*/
/*                     {% endfor %}*/
/*                 {% endif %}*/
/*                 */
/*                 {% if key == "По жалобе" %}*/
/*                     {% for k, p in prov %}*/
/*                         {% for k1, p1 in p %}*/
/*                         */
/*                             {% if k1 == "1" %}*/
/*                                 {% set gal_v = gal_v + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "0" %}*/
/*                                 {% set gal_n = gal_n + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "-1" %}*/
/*                                 {% set gal_ch = gal_ch + p1 %}*/
/*                             {% endif %}*/
/*                         {% endfor %}*/
/*                     {% endfor %}*/
/*                 {% endif %}*/
/*                 */
/*                 {% if key == "ЦГСЭН внеплановая" %}*/
/*                     {% for k, p in prov %}*/
/*                         {% for k1, p1 in p %}*/
/*                         */
/*                             {% if k1 == "1" %}*/
/*                                 {% set cgsn_v_v = cgsn_v_v + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "0" %}*/
/*                                 {% set cgsn_v_n = cgsn_v_n + p1 %}*/
/*                             {% endif %}*/
/*                             {% if k1 == "-1" %}*/
/*                                 {% set cgsn_v_ch = cgsn_v_ch + p1 %}*/
/*                             {% endif %}*/
/*                         {% endfor %}*/
/*                     {% endfor %}*/
/*                 {% endif %}*/
/*             {% endfor %}*/
/*         {% endfor %}*/
/* */
/*         {% for key, proverki in proverka_temp %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{ key }}</td>*/
/*             {% for type in proverkaType %}*/
/*                 {% for key_proverka, proverka in proverki %}*/
/*                     {% if type.name == key_proverka %}*/
/*                         {% for key, otmetka in proverka %}*/
/*                  */
/*                             {% for key, count in otmetka %}*/
/*                         */
/*                                 {% if otmetka["1"] is defined %}*/
/*                                     {% if key == "1" %}*/
/*                                         {% set count_all = count_all + count %}*/
/*                                         {% set count1 = count1 + count %}*/
/*                                         */
/*                                         {% if key_proverka == "ЦГСЭН" or*/
/*                                               key_proverka == "Контрольная проверка" or*/
/*                                               key_proverka == "Инспектирование" or*/
/*                                               key_proverka == "День куратора" %}*/
/*                                             {% set count_P_V = count_P_V + count %}*/
/*                                         {% else %}*/
/*                                             {% set count_V_V = count_V_V + count %}*/
/*                                         {% endif %}*/
/*                                         */
/* 										{% set flag1 = "1" %}*/
/*                                     {% endif %}    */
/*                                 {% endif %}*/
/*                                 {% if otmetka["0"] is defined %}*/
/*                                     {% if key == "0" %}*/
/*                                         {% set count_all = count_all + count %}*/
/*                                         {% set count2 = count2 + count %}*/
/*                                         */
/*                                         {% if key_proverka == "ЦГСЭН" or*/
/*                                               key_proverka == "Контрольная проверка" or*/
/*                                               key_proverka == "Инспектирование" or*/
/*                                               key_proverka == "День куратора" %}*/
/*                                             {% set count_P_N = count_P_N + count %}*/
/*                                         {% else %}*/
/*                                             {% set count_V_N = count_V_N + count %}*/
/*                                         {% endif %}*/
/*                                         */
/* 										{% set flag2 = "1" %}*/
/*                                     {% endif %}    */
/*                                 {% endif %}*/
/*                                 {% if otmetka["-1"] is defined %}*/
/*                                     {% if key == "-1" %}*/
/*                                         {% set count_all = count_all + count %}*/
/* 										{% set count3 = count3 + count %}*/
/* 										*/
/*                                         {% if key_proverka == "ЦГСЭН" or*/
/*                                               key_proverka == "Контрольная проверка" or*/
/*                                               key_proverka == "Инспектирование" or*/
/*                                               key_proverka == "День куратора" %}*/
/*                                             {% set count_P_CH = count_P_CH + count %}*/
/*                                         {% else %}*/
/*                                             {% set count_V_CH = count_V_CH + count %}*/
/*                                         {% endif %}*/
/*                                         */
/* 										{% set flag3 = "1" %}*/
/*                                     {% endif %}    */
/*                                 {% endif %} */
/*                             {% endfor %}*/
/*                         {% endfor %}   */
/*                         */
/*                     */
/*                     {% endif %}*/
/*                 {% endfor %}*/
/* 				*/
/*                 {% if flag1 == "1" %}    */
/*                     <td>{{ count1 }}</td>*/
/*                 {% else %}*/
/*                     <td>-</td>*/
/*                 {% endif %}*/
/*                 {% if flag2 == "1" %}    */
/*                     <td>{{ count2 }}</td>*/
/*                 {% else %}*/
/*                     <td>-</td>*/
/*                 {% endif %}*/
/*                 {% if flag3 == "1" %}    */
/*                     <td>{{ count3 }}</td>*/
/*                 {% else %}*/
/*                     <td>-</td>*/
/*                 {% endif %}*/
/*                 {% if count_all %}    */
/*                     <td>{{ count_all }}</td>*/
/*                 {% else %}*/
/*                     <td>-</td>*/
/*                 {% endif %}*/
/* 				*/
/* 				{% set flag1 = "0" %}*/
/* 				{% set flag2 = "0" %}*/
/* 				{% set flag3 = "0" %}*/
/* 				{% set count1 = "0" %}*/
/* 				{% set count2 = "0" %}*/
/* 				{% set count3 = "0" %}*/
/* 				{% set count_all = "0" %}*/
/* 				*/
/*             {% endfor %} */
/* */
/* 				<td>{{ count_P_V }}</td>*/
/* 				<td>{{ count_P_N }}</td>*/
/* 				<td>{{ count_P_CH }}</td>*/
/* 				<td>{{ count_P_V + count_P_N + count_P_CH }}</td>*/
/* 				<td>{{ count_V_V }}</td>*/
/* 				<td>{{ count_V_N }}</td>*/
/* 				<td>{{ count_V_CH }}</td>*/
/* 				<td>{{ count_V_V + count_V_N + count_V_CH }}</td>*/
/* */
/*                 */
/*                 {% set count_P_V = "0" %}*/
/*                 {% set count_P_N = "0" %}*/
/*                 {% set count_P_CH = "0" %}*/
/*                 {% set count_V_V = "0" %}*/
/*                 {% set count_V_N = "0" %}*/
/*                 {% set count_V_CH = "0" %}*/
/* */
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*             <tr>*/
/*                 <td rowspan="4" style="padding-top:50px">Всего</td>*/
/* 				<td>{{ cgsn_v }}</td>*/
/* 				<td>{{ cgsn_n }}</td>*/
/* 				<td>{{ cgsn_ch }}</td>*/
/* 				<td>{{ cgsn_v + cgsn_n + cgsn_ch }}</td>*/
/* 				<td>{{ kr_v }}</td>*/
/* 				<td>{{ kr_n }}</td>*/
/* 				<td>{{ kr_ch }}</td>*/
/* 				<td>{{ kr_v + kr_n + kr_ch}}</td>*/
/* 				<td>{{ inspec_v }}</td>*/
/* 				<td>{{ inspec_n }}</td>*/
/* 				<td>{{ inspec_ch }}</td>*/
/* 				<td>{{ inspec_v + inspec_n + inspec_ch }}</td>*/
/* 				<td>{{ dk_v }}</td>*/
/* 				<td>{{ dk_n }}</td>*/
/* 				<td>{{ dk_ch }}</td>*/
/* 				<td>{{ dk_v + dk_n + dk_ch }}</td>*/
/* 				<td>{{ prok_v }}</td>*/
/* 				<td>{{ prok_n }}</td>*/
/* 				<td>{{ prok_ch }}</td>*/
/* 				<td>{{ prok_v + prok_n + prok_ch }}</td>*/
/* 				<td>{{ gal_v }}</td>*/
/* 				<td>{{ gal_n }}</td>*/
/* 				<td>{{ gal_ch }}</td>*/
/* 				<td>{{ gal_v + gal_n + gal_ch }}</td>*/
/* 				<td>{{ cgsn_v_v }}</td>*/
/* 				<td>{{ cgsn_v_n }}</td>*/
/* 				<td>{{ cgsn_v_ch }}</td>*/
/* 				<td>{{ cgsn_v_v + cgsn_v_n + cgsn_v_ch }}</td>*/
/*                 <td style="text-align:center;padding-top:50px" colspan="8" rowspan="4" id="vsego">{{ cgsn_v + kr_v + inspec_v + dk_v + cgsn_n + kr_n + inspec_n + dk_n + cgsn_ch + kr_ch + inspec_ch + dk_ch + prok_v + gal_v + cgsn_v_v + prok_n + gal_n + cgsn_v_n + prok_ch + gal_ch + cgsn_v_ch }} ({{cgsn_v + kr_v + inspec_v + dk_v + prok_v + gal_v + cgsn_v_v }})</td>*/
/*             </tr>  */
/*             <tr>*/
/*                 <td colspan="16">Плановые</td>  */
/*                 <td colspan="12">Внеплановые</td> */
/*             </tr>*/
/*             <tr>*/
/*                 <td colspan="4">В</td>  */
/*                 <td colspan="4">Н</td>  */
/*                 <td colspan="4">Ч</td>  */
/*                 <td colspan="4">И</td>  */
/*                 <td colspan="4">В</td>  */
/*                 <td colspan="4">Н</td>  */
/*                 <td colspan="2">Ч</td>  */
/*                 <td colspan="2">И</td>  */
/*             </tr>*/
/*             <tr>*/
/*                 <td colspan="4">{{ cgsn_v + kr_v + inspec_v + dk_v }}</td>  */
/*                 <td colspan="4">{{ cgsn_n + kr_n + inspec_n + dk_n }}</td>  */
/*                 <td colspan="4">{{ cgsn_ch + kr_ch + inspec_ch + dk_ch }}</td>  */
/*                 <td colspan="4">{{ cgsn_v + kr_v + inspec_v + dk_v + cgsn_n + kr_n + inspec_n + dk_n + cgsn_ch + kr_ch + inspec_ch + dk_ch }}</td>  */
/*                 <td colspan="4">{{ prok_v + gal_v + cgsn_v_v }}</td>  */
/*                 <td colspan="4">{{ prok_n + gal_n + cgsn_v_n }}</td>  */
/*                 <td colspan="2">{{ prok_ch + gal_ch + cgsn_v_ch }}</td>  */
/*                 <td colspan="2">{{ prok_v + gal_v + cgsn_v_v + prok_n + gal_n + cgsn_v_n + prok_ch + gal_ch + cgsn_v_ch }}</td> */
/*             </tr>			*/
/*         </tfoot>*/
/*         */
/*     </table>*/
/* </div>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
