<?php

/* :otchet:proverka.html.twig */
class __TwigTemplate_ee7dfa899fe45ea7e4523471f58898b08d0fb99a900798c05976ae9e21e66bfe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet:proverka.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f45be0209df9c369e28d798bc1064da30cb630e453d36bd373b92c569ab5693c = $this->env->getExtension("native_profiler");
        $__internal_f45be0209df9c369e28d798bc1064da30cb630e453d36bd373b92c569ab5693c->enter($__internal_f45be0209df9c369e28d798bc1064da30cb630e453d36bd373b92c569ab5693c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet:proverka.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f45be0209df9c369e28d798bc1064da30cb630e453d36bd373b92c569ab5693c->leave($__internal_f45be0209df9c369e28d798bc1064da30cb630e453d36bd373b92c569ab5693c_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_f61320fffd827f8910842531ef216395054571503d91b0bb0ffc4ee610320c64 = $this->env->getExtension("native_profiler");
        $__internal_f61320fffd827f8910842531ef216395054571503d91b0bb0ffc4ee610320c64->enter($__internal_f61320fffd827f8910842531ef216395054571503d91b0bb0ffc4ee610320c64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/proverka_menu.html", ":otchet:proverka.html.twig", 5)->display($context);
        // line 6
        echo "
";
        
        $__internal_f61320fffd827f8910842531ef216395054571503d91b0bb0ffc4ee610320c64->leave($__internal_f61320fffd827f8910842531ef216395054571503d91b0bb0ffc4ee610320c64_prof);

    }

    // line 9
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_349b32d476cacc6fc48f9c6851f9151420f33f60166927f71e1545cfb6f81553 = $this->env->getExtension("native_profiler");
        $__internal_349b32d476cacc6fc48f9c6851f9151420f33f60166927f71e1545cfb6f81553->enter($__internal_349b32d476cacc6fc48f9c6851f9151420f33f60166927f71e1545cfb6f81553_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 10
        echo "
";
        
        $__internal_349b32d476cacc6fc48f9c6851f9151420f33f60166927f71e1545cfb6f81553->leave($__internal_349b32d476cacc6fc48f9c6851f9151420f33f60166927f71e1545cfb6f81553_prof);

    }

    public function getTemplateName()
    {
        return ":otchet:proverka.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 10,  54 => 9,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/proverka_menu.html' %}*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
