<?php

/* fkuz/showLabIssl.html.twig */
class __TwigTemplate_f1079e0e40b48470d78997bc6656464a71931c03e1611c9ff91d8ce0a9e8fba7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "fkuz/showLabIssl.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f0adf2a7200faffdc3fd7913180eabce6a7b3ca6d0591730e3ef659c9a6bb62 = $this->env->getExtension("native_profiler");
        $__internal_8f0adf2a7200faffdc3fd7913180eabce6a7b3ca6d0591730e3ef659c9a6bb62->enter($__internal_8f0adf2a7200faffdc3fd7913180eabce6a7b3ca6d0591730e3ef659c9a6bb62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "fkuz/showLabIssl.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8f0adf2a7200faffdc3fd7913180eabce6a7b3ca6d0591730e3ef659c9a6bb62->leave($__internal_8f0adf2a7200faffdc3fd7913180eabce6a7b3ca6d0591730e3ef659c9a6bb62_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_8794fe5778a000438fbf58941320fd8a9b81b078f9c93c76d1664ef8889d243f = $this->env->getExtension("native_profiler");
        $__internal_8794fe5778a000438fbf58941320fd8a9b81b078f9c93c76d1664ef8889d243f->enter($__internal_8794fe5778a000438fbf58941320fd8a9b81b078f9c93c76d1664ef8889d243f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">

    <div class=\"col-md-3\">
        <div>Выберите исследование</div>
        <select class=\"form-control\" id=\"labIssledovaniyaFkuz\">
            ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["labIssl"]) ? $context["labIssl"] : $this->getContext($context, "labIssl")));
        foreach ($context['_seq'] as $context["_key"] => $context["issl"]) {
            // line 11
            echo "            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["issl"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["issl"], "nomer", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["issl"], "date", array()), "d.m.Y"), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['issl'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "        </select>
    </div>
    
    <div class=\"col-md-3\"> 
        <div>Выберите результат</div>
        <div id=\"issledovanie\"></div>
    </div>
</div>
   
<div class=\"row\">  
    <div class=\"col-md-3\">
        <input type=\"submit\" value=\"Редактировать исследование\" class=\"btn btn-success\" id=\"showIssledovaniyaFkuz\" style=\"margin-top:30px\"/>
    </div>
</div>

";
        
        $__internal_8794fe5778a000438fbf58941320fd8a9b81b078f9c93c76d1664ef8889d243f->leave($__internal_8794fe5778a000438fbf58941320fd8a9b81b078f9c93c76d1664ef8889d243f_prof);

    }

    // line 30
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_6cc2017aacd467e0137e24aafa19ab2397635cecba4bed559858aec443bf8b98 = $this->env->getExtension("native_profiler");
        $__internal_6cc2017aacd467e0137e24aafa19ab2397635cecba4bed559858aec443bf8b98->enter($__internal_6cc2017aacd467e0137e24aafa19ab2397635cecba4bed559858aec443bf8b98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 31
        echo "
";
        
        $__internal_6cc2017aacd467e0137e24aafa19ab2397635cecba4bed559858aec443bf8b98->leave($__internal_6cc2017aacd467e0137e24aafa19ab2397635cecba4bed559858aec443bf8b98_prof);

    }

    public function getTemplateName()
    {
        return "fkuz/showLabIssl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 31,  88 => 30,  66 => 13,  53 => 11,  49 => 10,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/* */
/*     <div class="col-md-3">*/
/*         <div>Выберите исследование</div>*/
/*         <select class="form-control" id="labIssledovaniyaFkuz">*/
/*             {% for issl in labIssl %}*/
/*             <option value="{{ issl.id }}">{{ issl.nomer }}, {{issl.date|date("d.m.Y") }}</option>*/
/*             {% endfor %}*/
/*         </select>*/
/*     </div>*/
/*     */
/*     <div class="col-md-3"> */
/*         <div>Выберите результат</div>*/
/*         <div id="issledovanie"></div>*/
/*     </div>*/
/* </div>*/
/*    */
/* <div class="row">  */
/*     <div class="col-md-3">*/
/*         <input type="submit" value="Редактировать исследование" class="btn btn-success" id="showIssledovaniyaFkuz" style="margin-top:30px"/>*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
