<?php

/* :otchet:fkuz.html.twig */
class __TwigTemplate_806d40235b52e5d7fd51e0901bbde306c44871fecab959d961c42c30f5627f45 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet:fkuz.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_53f3eff4e23bf9aa2071f729fe305d862eb8c71cd0f69e076914c3431f66f042 = $this->env->getExtension("native_profiler");
        $__internal_53f3eff4e23bf9aa2071f729fe305d862eb8c71cd0f69e076914c3431f66f042->enter($__internal_53f3eff4e23bf9aa2071f729fe305d862eb8c71cd0f69e076914c3431f66f042_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet:fkuz.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_53f3eff4e23bf9aa2071f729fe305d862eb8c71cd0f69e076914c3431f66f042->leave($__internal_53f3eff4e23bf9aa2071f729fe305d862eb8c71cd0f69e076914c3431f66f042_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_f6b7a8dab6db0289f3a014c6ee02edf48000f7f096ac8c6a06940d4ecb0861a9 = $this->env->getExtension("native_profiler");
        $__internal_f6b7a8dab6db0289f3a014c6ee02edf48000f7f096ac8c6a06940d4ecb0861a9->enter($__internal_f6b7a8dab6db0289f3a014c6ee02edf48000f7f096ac8c6a06940d4ecb0861a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
    ";
        // line 5
        $this->loadTemplate("views/otchet/ajax/fkuz_menu.html", ":otchet:fkuz.html.twig", 5)->display($context);
        // line 6
        echo "
";
        
        $__internal_f6b7a8dab6db0289f3a014c6ee02edf48000f7f096ac8c6a06940d4ecb0861a9->leave($__internal_f6b7a8dab6db0289f3a014c6ee02edf48000f7f096ac8c6a06940d4ecb0861a9_prof);

    }

    // line 9
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_8066c112c3413fc0dd32d167bc741b7668ba9d21a34dc67aef8d6df01573dc2a = $this->env->getExtension("native_profiler");
        $__internal_8066c112c3413fc0dd32d167bc741b7668ba9d21a34dc67aef8d6df01573dc2a->enter($__internal_8066c112c3413fc0dd32d167bc741b7668ba9d21a34dc67aef8d6df01573dc2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 10
        echo "
";
        
        $__internal_8066c112c3413fc0dd32d167bc741b7668ba9d21a34dc67aef8d6df01573dc2a->leave($__internal_8066c112c3413fc0dd32d167bc741b7668ba9d21a34dc67aef8d6df01573dc2a_prof);

    }

    public function getTemplateName()
    {
        return ":otchet:fkuz.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 10,  54 => 9,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*     {% include 'views/otchet/ajax/fkuz_menu.html' %}*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
