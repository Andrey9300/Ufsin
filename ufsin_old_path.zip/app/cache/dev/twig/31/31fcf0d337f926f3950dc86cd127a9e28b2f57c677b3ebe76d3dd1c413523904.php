<?php

/* :otchet:dogovor.html.twig */
class __TwigTemplate_2ba256ebb23a035d0c5a85dfce0fcdc70fdb0bc6e2bb55b588994d8e1704dcd9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet:dogovor.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1f78570c45b63bd7fd4cbe4f61557fb607c4ec98941b9e1d9cd8a1126fbefab = $this->env->getExtension("native_profiler");
        $__internal_a1f78570c45b63bd7fd4cbe4f61557fb607c4ec98941b9e1d9cd8a1126fbefab->enter($__internal_a1f78570c45b63bd7fd4cbe4f61557fb607c4ec98941b9e1d9cd8a1126fbefab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet:dogovor.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a1f78570c45b63bd7fd4cbe4f61557fb607c4ec98941b9e1d9cd8a1126fbefab->leave($__internal_a1f78570c45b63bd7fd4cbe4f61557fb607c4ec98941b9e1d9cd8a1126fbefab_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_97557f9d7b1752a2bf16f346d20f927782125479f5ca3d42d89c3e5e8e71c4b8 = $this->env->getExtension("native_profiler");
        $__internal_97557f9d7b1752a2bf16f346d20f927782125479f5ca3d42d89c3e5e8e71c4b8->enter($__internal_97557f9d7b1752a2bf16f346d20f927782125479f5ca3d42d89c3e5e8e71c4b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">
    <h3>Договора в учреждениях</h3>
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetDogovor/common\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>
    </div>
</div>

<div class=\"row\">
    <table class=\"table table-hover table-bordered\" id=\"common_dogovor\">
        <thead>
            <tr>
                <td>Учреждение</td>
                ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["dogovorsType"]) ? $context["dogovorsType"] : $this->getContext($context, "dogovorsType")));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 29
            echo "                    ";
            if (($this->getAttribute($context["type"], "name", array()) != "производственный контроль")) {
                // line 30
                echo "                    <td>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["type"], "name", array()), "html", null, true);
                echo "</td>
                    ";
            }
            // line 32
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "            </tr>
        </thead>
        <tbody>
        
        ";
        // line 37
        $context["flag"] = "0";
        // line 38
        echo "
        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 40
            echo "            <tr>
                <td class=\"name\">";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                
                ";
            // line 43
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["dogovorsType"]) ? $context["dogovorsType"] : $this->getContext($context, "dogovorsType")));
            foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                // line 44
                echo "                
                    ";
                // line 45
                if (($this->getAttribute($context["type"], "name", array()) != "производственный контроль")) {
                    // line 46
                    echo "                    
                        ";
                    // line 47
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["dogovors"]) ? $context["dogovors"] : $this->getContext($context, "dogovors")));
                    foreach ($context['_seq'] as $context["_key"] => $context["dogovor"]) {
                        // line 48
                        echo "                        
                            ";
                        // line 49
                        if (($this->getAttribute($context["dogovor"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                            // line 50
                            echo "                            
                                ";
                            // line 51
                            if (($this->getAttribute($context["dogovor"], "name", array()) == $this->getAttribute($context["type"], "name", array()))) {
                                // line 52
                                echo "
                                    <td>+</td>
                                    
                                    ";
                                // line 55
                                $context["flag"] = "1";
                                // line 56
                                echo "                                    
                                ";
                            }
                            // line 58
                            echo "                                
                            ";
                        }
                        // line 60
                        echo "
                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['dogovor'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 62
                    echo "                        
                        ";
                    // line 63
                    if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                        // line 64
                        echo "                            <td></td>
                        ";
                    }
                    // line 66
                    echo "                        
                        ";
                    // line 67
                    $context["flag"] = "0";
                    // line 68
                    echo "                    
                    ";
                }
                // line 70
                echo "                    
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 72
            echo "
            </tr> 
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "        </tbody>
        <tfoot>

        </tfoot>
        
    </table>
</div>

";
        
        $__internal_97557f9d7b1752a2bf16f346d20f927782125479f5ca3d42d89c3e5e8e71c4b8->leave($__internal_97557f9d7b1752a2bf16f346d20f927782125479f5ca3d42d89c3e5e8e71c4b8_prof);

    }

    // line 85
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_7b63782ccbd4d87e940d67e1b8fd875e5921c3600bcc2b81e78b1599fdfc5b44 = $this->env->getExtension("native_profiler");
        $__internal_7b63782ccbd4d87e940d67e1b8fd875e5921c3600bcc2b81e78b1599fdfc5b44->enter($__internal_7b63782ccbd4d87e940d67e1b8fd875e5921c3600bcc2b81e78b1599fdfc5b44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 86
        echo "
";
        
        $__internal_7b63782ccbd4d87e940d67e1b8fd875e5921c3600bcc2b81e78b1599fdfc5b44->leave($__internal_7b63782ccbd4d87e940d67e1b8fd875e5921c3600bcc2b81e78b1599fdfc5b44_prof);

    }

    public function getTemplateName()
    {
        return ":otchet:dogovor.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 86,  211 => 85,  196 => 75,  188 => 72,  181 => 70,  177 => 68,  175 => 67,  172 => 66,  168 => 64,  166 => 63,  163 => 62,  156 => 60,  152 => 58,  148 => 56,  146 => 55,  141 => 52,  139 => 51,  136 => 50,  134 => 49,  131 => 48,  127 => 47,  124 => 46,  122 => 45,  119 => 44,  115 => 43,  110 => 41,  107 => 40,  103 => 39,  100 => 38,  98 => 37,  92 => 33,  86 => 32,  80 => 30,  77 => 29,  73 => 28,  56 => 14,  50 => 11,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <h3>Договора в учреждениях</h3>*/
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetDogovor/common" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>*/
/*     </div>*/
/* </div>*/
/* */
/* <div class="row">*/
/*     <table class="table table-hover table-bordered" id="common_dogovor">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td>Учреждение</td>*/
/*                 {% for type in dogovorsType %}*/
/*                     {% if type.name != "производственный контроль" %}*/
/*                     <td>{{ type.name }}</td>*/
/*                     {% endif %}*/
/*                 {% endfor %}*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         */
/*         {% set flag = "0" %}*/
/* */
/*         {% for organization in organizations %}*/
/*             <tr>*/
/*                 <td class="name">{{organization.nameShort}}</td>*/
/*                 */
/*                 {% for type in dogovorsType %}*/
/*                 */
/*                     {% if type.name != "производственный контроль" %}*/
/*                     */
/*                         {% for dogovor in dogovors %}*/
/*                         */
/*                             {% if dogovor.name_full == organization.nameFull %}*/
/*                             */
/*                                 {% if dogovor.name == type.name %}*/
/* */
/*                                     <td>+</td>*/
/*                                     */
/*                                     {% set flag = "1" %}*/
/*                                     */
/*                                 {% endif %}*/
/*                                 */
/*                             {% endif %}*/
/* */
/*                         {% endfor %}*/
/*                         */
/*                         {% if flag == "0" %}*/
/*                             <td></td>*/
/*                         {% endif %}*/
/*                         */
/*                         {% set flag = "0" %}*/
/*                     */
/*                     {% endif %}*/
/*                     */
/*                 {% endfor %}*/
/* */
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/* */
/*         </tfoot>*/
/*         */
/*     </table>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
