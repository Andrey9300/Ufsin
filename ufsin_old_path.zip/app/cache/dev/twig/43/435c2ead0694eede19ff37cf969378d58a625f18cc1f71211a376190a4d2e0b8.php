<?php

/* TwigBundle:Exception:error404.html.twig */
class __TwigTemplate_2f054f9ab69e9fca08b5cdfd2e4802b4284452c6ad82245bf8e879318ac18e35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error404.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_32b28e3801eb26690eebb295c33227066a73e12a1394ba44542e99ea6344fdeb = $this->env->getExtension("native_profiler");
        $__internal_32b28e3801eb26690eebb295c33227066a73e12a1394ba44542e99ea6344fdeb->enter($__internal_32b28e3801eb26690eebb295c33227066a73e12a1394ba44542e99ea6344fdeb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error404.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_32b28e3801eb26690eebb295c33227066a73e12a1394ba44542e99ea6344fdeb->leave($__internal_32b28e3801eb26690eebb295c33227066a73e12a1394ba44542e99ea6344fdeb_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_16bf8a7350457940ebb03665005fd63f62f23f218a7eaf5672661d4a724c1ae9 = $this->env->getExtension("native_profiler");
        $__internal_16bf8a7350457940ebb03665005fd63f62f23f218a7eaf5672661d4a724c1ae9->enter($__internal_16bf8a7350457940ebb03665005fd63f62f23f218a7eaf5672661d4a724c1ae9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_16bf8a7350457940ebb03665005fd63f62f23f218a7eaf5672661d4a724c1ae9->leave($__internal_16bf8a7350457940ebb03665005fd63f62f23f218a7eaf5672661d4a724c1ae9_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_9320555a7e0caea2c3b5584d63914c14cfd247123e39b4af38cd3819f000eeb2 = $this->env->getExtension("native_profiler");
        $__internal_9320555a7e0caea2c3b5584d63914c14cfd247123e39b4af38cd3819f000eeb2->enter($__internal_9320555a7e0caea2c3b5584d63914c14cfd247123e39b4af38cd3819f000eeb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1 class=\"text-danger\">Страница не найдена</h1>

    <p class=\"lead\">
        Пожалуйста, вернитесь <a href=\"#\" id=\"back_page\">на предыдущую страницу</a> или перейдите <a href=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("main_index");
        echo "\">на главную страницу</a>.
    </p>
";
        
        $__internal_9320555a7e0caea2c3b5584d63914c14cfd247123e39b4af38cd3819f000eeb2->leave($__internal_9320555a7e0caea2c3b5584d63914c14cfd247123e39b4af38cd3819f000eeb2_prof);

    }

    // line 13
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_f27836454953da7f058a0409daa9de4aa5bbe9fc0b34c837e333a36567beb29c = $this->env->getExtension("native_profiler");
        $__internal_f27836454953da7f058a0409daa9de4aa5bbe9fc0b34c837e333a36567beb29c->enter($__internal_f27836454953da7f058a0409daa9de4aa5bbe9fc0b34c837e333a36567beb29c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 14
        echo "
";
        
        $__internal_f27836454953da7f058a0409daa9de4aa5bbe9fc0b34c837e333a36567beb29c->leave($__internal_f27836454953da7f058a0409daa9de4aa5bbe9fc0b34c837e333a36567beb29c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 14,  69 => 13,  59 => 9,  54 => 6,  48 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'error' %}*/
/* */
/* {% block main %}*/
/*     <h1 class="text-danger">Страница не найдена</h1>*/
/* */
/*     <p class="lead">*/
/*         Пожалуйста, вернитесь <a href="#" id="back_page">на предыдущую страницу</a> или перейдите <a href="{{ path('main_index') }}">на главную страницу</a>.*/
/*     </p>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
