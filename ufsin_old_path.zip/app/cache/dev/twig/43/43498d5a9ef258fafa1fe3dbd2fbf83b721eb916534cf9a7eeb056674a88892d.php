<?php

/* views/otchet/ajax/fkuz_menu.html */
class __TwigTemplate_02d9e8478693865d3bf44658f40660d88df1ef6ac0335fb678df16d4abd34636 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0d9e9ad0159c16523a44dc3488a1e875254d0f2eedbc46faeaa9348edadd0914 = $this->env->getExtension("native_profiler");
        $__internal_0d9e9ad0159c16523a44dc3488a1e875254d0f2eedbc46faeaa9348edadd0914->enter($__internal_0d9e9ad0159c16523a44dc3488a1e875254d0f2eedbc46faeaa9348edadd0914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "views/otchet/ajax/fkuz_menu.html"));

        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetFkuz/nakazaniya\">Наказания</a></li>
        <li><a href=\"/otchetFkuz/type\">Исследования</a></li>
    </ul>
</div>";
        
        $__internal_0d9e9ad0159c16523a44dc3488a1e875254d0f2eedbc46faeaa9348edadd0914->leave($__internal_0d9e9ad0159c16523a44dc3488a1e875254d0f2eedbc46faeaa9348edadd0914_prof);

    }

    public function getTemplateName()
    {
        return "views/otchet/ajax/fkuz_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetFkuz/nakazaniya">Наказания</a></li>*/
/*         <li><a href="/otchetFkuz/type">Исследования</a></li>*/
/*     </ul>*/
/* </div>*/
