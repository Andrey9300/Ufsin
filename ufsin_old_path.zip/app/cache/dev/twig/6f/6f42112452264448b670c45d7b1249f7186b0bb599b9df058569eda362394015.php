<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_1931c15d967ed0791c39f4dcc9014c273e0889779ab575a94b7b4942124d5138 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8f39663b9004a92347ae414e9d2b9fd7935d677458980f69176d7623f0c644f = $this->env->getExtension("native_profiler");
        $__internal_b8f39663b9004a92347ae414e9d2b9fd7935d677458980f69176d7623f0c644f->enter($__internal_b8f39663b9004a92347ae414e9d2b9fd7935d677458980f69176d7623f0c644f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_b8f39663b9004a92347ae414e9d2b9fd7935d677458980f69176d7623f0c644f->leave($__internal_b8f39663b9004a92347ae414e9d2b9fd7935d677458980f69176d7623f0c644f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
