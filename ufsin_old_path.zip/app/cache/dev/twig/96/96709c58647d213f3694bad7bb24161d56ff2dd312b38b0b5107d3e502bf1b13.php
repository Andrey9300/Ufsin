<?php

/* otchet/proverka.html.twig */
class __TwigTemplate_bbadfff407134f2d396bfaefd4f09b0e313c237a13b4ba2991cfc2799dc0ba27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "otchet/proverka.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1430e61475e14b84a81f7a1ef9699ffffe023e9013af01953cf4cd92a1275694 = $this->env->getExtension("native_profiler");
        $__internal_1430e61475e14b84a81f7a1ef9699ffffe023e9013af01953cf4cd92a1275694->enter($__internal_1430e61475e14b84a81f7a1ef9699ffffe023e9013af01953cf4cd92a1275694_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/proverka.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1430e61475e14b84a81f7a1ef9699ffffe023e9013af01953cf4cd92a1275694->leave($__internal_1430e61475e14b84a81f7a1ef9699ffffe023e9013af01953cf4cd92a1275694_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_242aa5f3ea6c5969dd15f899d86d648b935ee87f66a1f1e4302f2e82bf012565 = $this->env->getExtension("native_profiler");
        $__internal_242aa5f3ea6c5969dd15f899d86d648b935ee87f66a1f1e4302f2e82bf012565->enter($__internal_242aa5f3ea6c5969dd15f899d86d648b935ee87f66a1f1e4302f2e82bf012565_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/proverka_menu.html", "otchet/proverka.html.twig", 5)->display($context);
        // line 6
        echo "
";
        
        $__internal_242aa5f3ea6c5969dd15f899d86d648b935ee87f66a1f1e4302f2e82bf012565->leave($__internal_242aa5f3ea6c5969dd15f899d86d648b935ee87f66a1f1e4302f2e82bf012565_prof);

    }

    // line 9
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_d358c3572803d40a576b956a66b378c32b4c03f76f70bf9d43d2e09930da0a63 = $this->env->getExtension("native_profiler");
        $__internal_d358c3572803d40a576b956a66b378c32b4c03f76f70bf9d43d2e09930da0a63->enter($__internal_d358c3572803d40a576b956a66b378c32b4c03f76f70bf9d43d2e09930da0a63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 10
        echo "
";
        
        $__internal_d358c3572803d40a576b956a66b378c32b4c03f76f70bf9d43d2e09930da0a63->leave($__internal_d358c3572803d40a576b956a66b378c32b4c03f76f70bf9d43d2e09930da0a63_prof);

    }

    public function getTemplateName()
    {
        return "otchet/proverka.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 10,  54 => 9,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/proverka_menu.html' %}*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
