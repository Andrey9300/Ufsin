<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_0ffdf0bb18edfe307d5452034d947bcc1226b3be599744b401eed59c706c37b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d63b3edc21aad29142a4d1c16621ab0761056717533d016ee2abd2b5173eb697 = $this->env->getExtension("native_profiler");
        $__internal_d63b3edc21aad29142a4d1c16621ab0761056717533d016ee2abd2b5173eb697->enter($__internal_d63b3edc21aad29142a4d1c16621ab0761056717533d016ee2abd2b5173eb697_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_d63b3edc21aad29142a4d1c16621ab0761056717533d016ee2abd2b5173eb697->leave($__internal_d63b3edc21aad29142a4d1c16621ab0761056717533d016ee2abd2b5173eb697_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
