<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_af7279592359dcf87ecb65f25e732cfba7757507c3bbb728cb4dda5b92578666 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_641bfc7d8d11895415827e07528928183b0c82429766b94bd9966fedc9f448a3 = $this->env->getExtension("native_profiler");
        $__internal_641bfc7d8d11895415827e07528928183b0c82429766b94bd9966fedc9f448a3->enter($__internal_641bfc7d8d11895415827e07528928183b0c82429766b94bd9966fedc9f448a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_641bfc7d8d11895415827e07528928183b0c82429766b94bd9966fedc9f448a3->leave($__internal_641bfc7d8d11895415827e07528928183b0c82429766b94bd9966fedc9f448a3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
