<?php

/* issledovanie/showLabIssl.html.twig */
class __TwigTemplate_02da593945e7ee54262f1a5157a510ba078ab116991057bf1b257910c2b5f4a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "issledovanie/showLabIssl.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e464167420a35a0c4b48ed42add7689a48b95d59795216322f4d9089e967a179 = $this->env->getExtension("native_profiler");
        $__internal_e464167420a35a0c4b48ed42add7689a48b95d59795216322f4d9089e967a179->enter($__internal_e464167420a35a0c4b48ed42add7689a48b95d59795216322f4d9089e967a179_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "issledovanie/showLabIssl.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e464167420a35a0c4b48ed42add7689a48b95d59795216322f4d9089e967a179->leave($__internal_e464167420a35a0c4b48ed42add7689a48b95d59795216322f4d9089e967a179_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_df44bd2046c355291df50ffef16c6848ffbb125ed7e384accf5bf0cb8cdcf911 = $this->env->getExtension("native_profiler");
        $__internal_df44bd2046c355291df50ffef16c6848ffbb125ed7e384accf5bf0cb8cdcf911->enter($__internal_df44bd2046c355291df50ffef16c6848ffbb125ed7e384accf5bf0cb8cdcf911_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">

    <div class=\"col-md-3\">
        <div>Выберите исследование</div>
        <select class=\"form-control\" id=\"labIssledovaniya\">
            ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["labIssl"]) ? $context["labIssl"] : $this->getContext($context, "labIssl")));
        foreach ($context['_seq'] as $context["_key"] => $context["issl"]) {
            // line 11
            echo "            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["issl"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["issl"], "nomer", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["issl"], "date", array()), "d.m.Y"), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['issl'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "        </select>
    </div>
    
    <div class=\"col-md-3\"> 
        <div>Выберите результат</div>
        <div id=\"issledovanie\"></div>
    </div>
</div>
   
<div class=\"row\">  
    <div class=\"col-md-3\">
        <input type=\"submit\" value=\"Редактировать исследование\" class=\"btn btn-success\" id=\"showIssledovaniya\" style=\"margin-top:30px\"/>
    </div>
</div>

";
        
        $__internal_df44bd2046c355291df50ffef16c6848ffbb125ed7e384accf5bf0cb8cdcf911->leave($__internal_df44bd2046c355291df50ffef16c6848ffbb125ed7e384accf5bf0cb8cdcf911_prof);

    }

    // line 30
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_40a2c92e5fd7681ded9d6cec7e9eae0a562a488e64b79defc2f5b5a1f4f7a1f0 = $this->env->getExtension("native_profiler");
        $__internal_40a2c92e5fd7681ded9d6cec7e9eae0a562a488e64b79defc2f5b5a1f4f7a1f0->enter($__internal_40a2c92e5fd7681ded9d6cec7e9eae0a562a488e64b79defc2f5b5a1f4f7a1f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 31
        echo "
";
        
        $__internal_40a2c92e5fd7681ded9d6cec7e9eae0a562a488e64b79defc2f5b5a1f4f7a1f0->leave($__internal_40a2c92e5fd7681ded9d6cec7e9eae0a562a488e64b79defc2f5b5a1f4f7a1f0_prof);

    }

    public function getTemplateName()
    {
        return "issledovanie/showLabIssl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 31,  88 => 30,  66 => 13,  53 => 11,  49 => 10,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/* */
/*     <div class="col-md-3">*/
/*         <div>Выберите исследование</div>*/
/*         <select class="form-control" id="labIssledovaniya">*/
/*             {% for issl in labIssl %}*/
/*             <option value="{{ issl.id }}">{{ issl.nomer }}, {{issl.date|date("d.m.Y") }}</option>*/
/*             {% endfor %}*/
/*         </select>*/
/*     </div>*/
/*     */
/*     <div class="col-md-3"> */
/*         <div>Выберите результат</div>*/
/*         <div id="issledovanie"></div>*/
/*     </div>*/
/* </div>*/
/*    */
/* <div class="row">  */
/*     <div class="col-md-3">*/
/*         <input type="submit" value="Редактировать исследование" class="btn btn-success" id="showIssledovaniya" style="margin-top:30px"/>*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
