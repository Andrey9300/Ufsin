<?php

/* :otchet:issledovanie.html.twig */
class __TwigTemplate_5ff8714ac9fe6ed2be69875c4c2d68b530ef24674aedf70b960efbebd8ef5515 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet:issledovanie.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2be61506ee2892f4fbf2dcf257e24b3a6648149d2c63da4e8557bb9f94201052 = $this->env->getExtension("native_profiler");
        $__internal_2be61506ee2892f4fbf2dcf257e24b3a6648149d2c63da4e8557bb9f94201052->enter($__internal_2be61506ee2892f4fbf2dcf257e24b3a6648149d2c63da4e8557bb9f94201052_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet:issledovanie.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2be61506ee2892f4fbf2dcf257e24b3a6648149d2c63da4e8557bb9f94201052->leave($__internal_2be61506ee2892f4fbf2dcf257e24b3a6648149d2c63da4e8557bb9f94201052_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_ccd1b121a857a11f87d7a56d9612790aaa24ea638729504e92fa1af5e4a4b5c3 = $this->env->getExtension("native_profiler");
        $__internal_ccd1b121a857a11f87d7a56d9612790aaa24ea638729504e92fa1af5e4a4b5c3->enter($__internal_ccd1b121a857a11f87d7a56d9612790aaa24ea638729504e92fa1af5e4a4b5c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/issledovanie_menu.html", ":otchet:issledovanie.html.twig", 5)->display($context);
        // line 6
        echo "
";
        
        $__internal_ccd1b121a857a11f87d7a56d9612790aaa24ea638729504e92fa1af5e4a4b5c3->leave($__internal_ccd1b121a857a11f87d7a56d9612790aaa24ea638729504e92fa1af5e4a4b5c3_prof);

    }

    // line 9
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_3b30f51bb8d72ed5df59f560b8eac0cc41bcc2c3b044777ce538ca3d5ff250e2 = $this->env->getExtension("native_profiler");
        $__internal_3b30f51bb8d72ed5df59f560b8eac0cc41bcc2c3b044777ce538ca3d5ff250e2->enter($__internal_3b30f51bb8d72ed5df59f560b8eac0cc41bcc2c3b044777ce538ca3d5ff250e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 10
        echo "
";
        
        $__internal_3b30f51bb8d72ed5df59f560b8eac0cc41bcc2c3b044777ce538ca3d5ff250e2->leave($__internal_3b30f51bb8d72ed5df59f560b8eac0cc41bcc2c3b044777ce538ca3d5ff250e2_prof);

    }

    public function getTemplateName()
    {
        return ":otchet:issledovanie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 10,  54 => 9,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/issledovanie_menu.html' %}*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
