<?php

/* otchet/ajax/zabolevanie_menu.html */
class __TwigTemplate_8a7bc23675cb8fdd3e3c651db7b1286346815647e78dc81eda16a3a874c739b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f097bfeb3dec7a41a9be744f14ab3dcf85870bfdb1a93a2bb7629c636d817b23 = $this->env->getExtension("native_profiler");
        $__internal_f097bfeb3dec7a41a9be744f14ab3dcf85870bfdb1a93a2bb7629c636d817b23->enter($__internal_f097bfeb3dec7a41a9be744f14ab3dcf85870bfdb1a93a2bb7629c636d817b23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/ajax/zabolevanie_menu.html"));

        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetZabolevaniya/\">Общее</a></li>
        <li><a href=\"/otchetZabolevaniya/kontaktnye\">Общее (Контактные)</a></li>
        <li><a href=\"/otchetZabolevaniya/otryad\">Отряды</a></li>
        <li><a href=\"/otchetZabolevaniya/otryadKontakt\">Отряды (Контактные)</a></li>
        <li><a href=\"/otchetZabolevaniya/mbt\">МБТ</a></li>
        <li><a href=\"/otchetZabolevaniya/viyavlenie\">Выявление</a></li>
        <li><a href=\"/otchetZabolevaniya/recidiv\">Заболеваемость</a></li>
        <li><a href=\"/otchetZabolevaniya/postupilIs\">Поступление</a></li>
        <li><a href=\"/otchetZabolevaniya/addressCommon\">Адрес общий</a></li>
        <li><a href=\"/otchetZabolevaniya/ochag\">Очаг</a></li>
        <li><a href=\"/otchetZabolevaniya/patologiya\">Сопутствующая патология</a></li>
        <li><a href=\"/otchetZabolevaniya/povtorno\">Повторно заболевшие</a></li>
        <li><a href=\"/otchetZabolevaniya/izKontaktnyh\">Заболевшие из IV ГДУ</a></li>
    </ul>
</div>";
        
        $__internal_f097bfeb3dec7a41a9be744f14ab3dcf85870bfdb1a93a2bb7629c636d817b23->leave($__internal_f097bfeb3dec7a41a9be744f14ab3dcf85870bfdb1a93a2bb7629c636d817b23_prof);

    }

    public function getTemplateName()
    {
        return "otchet/ajax/zabolevanie_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetZabolevaniya/">Общее</a></li>*/
/*         <li><a href="/otchetZabolevaniya/kontaktnye">Общее (Контактные)</a></li>*/
/*         <li><a href="/otchetZabolevaniya/otryad">Отряды</a></li>*/
/*         <li><a href="/otchetZabolevaniya/otryadKontakt">Отряды (Контактные)</a></li>*/
/*         <li><a href="/otchetZabolevaniya/mbt">МБТ</a></li>*/
/*         <li><a href="/otchetZabolevaniya/viyavlenie">Выявление</a></li>*/
/*         <li><a href="/otchetZabolevaniya/recidiv">Заболеваемость</a></li>*/
/*         <li><a href="/otchetZabolevaniya/postupilIs">Поступление</a></li>*/
/*         <li><a href="/otchetZabolevaniya/addressCommon">Адрес общий</a></li>*/
/*         <li><a href="/otchetZabolevaniya/ochag">Очаг</a></li>*/
/*         <li><a href="/otchetZabolevaniya/patologiya">Сопутствующая патология</a></li>*/
/*         <li><a href="/otchetZabolevaniya/povtorno">Повторно заболевшие</a></li>*/
/*         <li><a href="/otchetZabolevaniya/izKontaktnyh">Заболевшие из IV ГДУ</a></li>*/
/*     </ul>*/
/* </div>*/
