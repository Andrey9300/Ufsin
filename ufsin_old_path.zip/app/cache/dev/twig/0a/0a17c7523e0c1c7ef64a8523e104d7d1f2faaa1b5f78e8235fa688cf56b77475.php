<?php

/* views/otchet/ajax/proverka_menu.html */
class __TwigTemplate_54ef710999c8e23e67e55bf085911a048904590256dae8ef61e40ee9a64983bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d4b38a2a70e9e236b043e6fa054450d4e000f7e555f703e081163c31fc303194 = $this->env->getExtension("native_profiler");
        $__internal_d4b38a2a70e9e236b043e6fa054450d4e000f7e555f703e081163c31fc303194->enter($__internal_d4b38a2a70e9e236b043e6fa054450d4e000f7e555f703e081163c31fc303194_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "views/otchet/ajax/proverka_menu.html"));

        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetProverka/common\">Общее число проверок</a></li>
        <li><a href=\"/otchetProverka/narusheniya\">Нарушения по проверкам</a></li>
        <li><a href=\"/otchetProverka/narusheniyaObj\">Нарушения по объектам</a></li>
        <li><a href=\"/otchetProverka/nakazaniya\">Наказаниям</a></li>      
        <li><a href=\"/otchetProverka/narusheniyaAll\">Нарушения по всем учреждениям</a></li>      
        <li><a href=\"/otchetProverka/proverkaNakazaniya\">Сотрудники привлеченные к назазанию</a></li>
        <li><a href=\"/otchetProverka/proverkaNevyp\">Невыполненные нарушения</a></li>
        <li><a href=\"/otchetProverka/proverkaNarusheniyaVnimanie\">Нарушения требующие особого внимания</a></li>
    </ul>
</div>";
        
        $__internal_d4b38a2a70e9e236b043e6fa054450d4e000f7e555f703e081163c31fc303194->leave($__internal_d4b38a2a70e9e236b043e6fa054450d4e000f7e555f703e081163c31fc303194_prof);

    }

    public function getTemplateName()
    {
        return "views/otchet/ajax/proverka_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetProverka/common">Общее число проверок</a></li>*/
/*         <li><a href="/otchetProverka/narusheniya">Нарушения по проверкам</a></li>*/
/*         <li><a href="/otchetProverka/narusheniyaObj">Нарушения по объектам</a></li>*/
/*         <li><a href="/otchetProverka/nakazaniya">Наказаниям</a></li>      */
/*         <li><a href="/otchetProverka/narusheniyaAll">Нарушения по всем учреждениям</a></li>      */
/*         <li><a href="/otchetProverka/proverkaNakazaniya">Сотрудники привлеченные к назазанию</a></li>*/
/*         <li><a href="/otchetProverka/proverkaNevyp">Невыполненные нарушения</a></li>*/
/*         <li><a href="/otchetProverka/proverkaNarusheniyaVnimanie">Нарушения требующие особого внимания</a></li>*/
/*     </ul>*/
/* </div>*/
