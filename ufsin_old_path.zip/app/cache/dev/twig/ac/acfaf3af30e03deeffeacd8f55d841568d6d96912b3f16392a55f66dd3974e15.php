<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_76257bf8ca3197a9d342e160b01794e9a49945d8da59e9c1f732d1afad8b0913 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec3c3ca4c84b2ff48a60f449af85f2f2348d789e43fec2bf82fbc974b328a0e1 = $this->env->getExtension("native_profiler");
        $__internal_ec3c3ca4c84b2ff48a60f449af85f2f2348d789e43fec2bf82fbc974b328a0e1->enter($__internal_ec3c3ca4c84b2ff48a60f449af85f2f2348d789e43fec2bf82fbc974b328a0e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_ec3c3ca4c84b2ff48a60f449af85f2f2348d789e43fec2bf82fbc974b328a0e1->leave($__internal_ec3c3ca4c84b2ff48a60f449af85f2f2348d789e43fec2bf82fbc974b328a0e1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
