<?php

/* :otchet:index.html.twig */
class __TwigTemplate_e1a27791d50a6718b17ce861403d5791a9952e1ed4b88e971e0eff530d456674 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet:index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8f781537222fb412572a2857f90b2621118abf8ac3a8c6a46f398c1c9905498 = $this->env->getExtension("native_profiler");
        $__internal_b8f781537222fb412572a2857f90b2621118abf8ac3a8c6a46f398c1c9905498->enter($__internal_b8f781537222fb412572a2857f90b2621118abf8ac3a8c6a46f398c1c9905498_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b8f781537222fb412572a2857f90b2621118abf8ac3a8c6a46f398c1c9905498->leave($__internal_b8f781537222fb412572a2857f90b2621118abf8ac3a8c6a46f398c1c9905498_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_d7941e67871db977697923715fb8cb6f9fad58015f37aca6e0a07e720069398a = $this->env->getExtension("native_profiler");
        $__internal_d7941e67871db977697923715fb8cb6f9fad58015f37aca6e0a07e720069398a->enter($__internal_d7941e67871db977697923715fb8cb6f9fad58015f37aca6e0a07e720069398a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">
    <div id=\"main\" class=\"col-sm-9\">
        <h1>Все отчеты</h1>
    </div>
</div>

";
        
        $__internal_d7941e67871db977697923715fb8cb6f9fad58015f37aca6e0a07e720069398a->leave($__internal_d7941e67871db977697923715fb8cb6f9fad58015f37aca6e0a07e720069398a_prof);

    }

    // line 13
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_e89f6baa240b72e1adfa14761c5c31d63829f3d7111813224605f0c1cb659db6 = $this->env->getExtension("native_profiler");
        $__internal_e89f6baa240b72e1adfa14761c5c31d63829f3d7111813224605f0c1cb659db6->enter($__internal_e89f6baa240b72e1adfa14761c5c31d63829f3d7111813224605f0c1cb659db6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 14
        echo "
";
        
        $__internal_e89f6baa240b72e1adfa14761c5c31d63829f3d7111813224605f0c1cb659db6->leave($__internal_e89f6baa240b72e1adfa14761c5c31d63829f3d7111813224605f0c1cb659db6_prof);

    }

    public function getTemplateName()
    {
        return ":otchet:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 14,  55 => 13,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <div id="main" class="col-sm-9">*/
/*         <h1>Все отчеты</h1>*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
