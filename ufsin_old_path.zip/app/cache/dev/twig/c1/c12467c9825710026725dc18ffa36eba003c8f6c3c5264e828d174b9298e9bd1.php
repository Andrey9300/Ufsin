<?php

/* otchet/ajax/issledovanie_menu.html */
class __TwigTemplate_ce3f2be1e01db8b80adf8ea4ffdae9cc47ba30a226d29625c4859c6f9e4607b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e8ec8e1157a728759c72bd97230f7e8cdb385adafe301d9f3b4cf36017d5977 = $this->env->getExtension("native_profiler");
        $__internal_7e8ec8e1157a728759c72bd97230f7e8cdb385adafe301d9f3b4cf36017d5977->enter($__internal_7e8ec8e1157a728759c72bd97230f7e8cdb385adafe301d9f3b4cf36017d5977_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/ajax/issledovanie_menu.html"));

        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetIssledovaniya/type\">Статистика исследований по типу</a></li>
    </ul>
</div>";
        
        $__internal_7e8ec8e1157a728759c72bd97230f7e8cdb385adafe301d9f3b4cf36017d5977->leave($__internal_7e8ec8e1157a728759c72bd97230f7e8cdb385adafe301d9f3b4cf36017d5977_prof);

    }

    public function getTemplateName()
    {
        return "otchet/ajax/issledovanie_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetIssledovaniya/type">Статистика исследований по типу</a></li>*/
/*     </ul>*/
/* </div>*/
