<?php

/* :organization:allNameOrganizaions.html.twig */
class __TwigTemplate_3204153bb07181ec541262ebf065d6fff7f64de5c8c9ce30855b09351d710136 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f6f4a4fea5fea78a473e22a901486ba09429b654310b5bcb1b42b1e1401bc2c = $this->env->getExtension("native_profiler");
        $__internal_2f6f4a4fea5fea78a473e22a901486ba09429b654310b5bcb1b42b1e1401bc2c->enter($__internal_2f6f4a4fea5fea78a473e22a901486ba09429b654310b5bcb1b42b1e1401bc2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":organization:allNameOrganizaions.html.twig"));

        // line 1
        echo "<ul class=\"dropdown-menu\"><li>111</li>
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["org"]) {
            // line 3
            echo "        <li><a href=\"/organization/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["org"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["org"], "name", array()), "html", null, true);
            echo "</a></li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['org'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 5
        echo "</ul>";
        
        $__internal_2f6f4a4fea5fea78a473e22a901486ba09429b654310b5bcb1b42b1e1401bc2c->leave($__internal_2f6f4a4fea5fea78a473e22a901486ba09429b654310b5bcb1b42b1e1401bc2c_prof);

    }

    public function getTemplateName()
    {
        return ":organization:allNameOrganizaions.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 5,  29 => 3,  25 => 2,  22 => 1,);
    }
}
/* <ul class="dropdown-menu"><li>111</li>*/
/*     {% for org in organizations %}*/
/*         <li><a href="/organization/{{org.id}}">{{org.name}}</a></li>*/
/*     {% endfor %}*/
/* </ul>*/
