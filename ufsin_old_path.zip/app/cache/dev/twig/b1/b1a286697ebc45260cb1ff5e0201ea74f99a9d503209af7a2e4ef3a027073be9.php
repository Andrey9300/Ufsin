<?php

/* organization/newRukZamTest.html.twig */
class __TwigTemplate_9d3eae836e19666a948993ed47f6f8dacc77a08ae292d4b3eb6bbff7dc1c74c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "organization/newRukZamTest.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35b2cf83e54c6351e38b88d5f7219757b11178f888ab1a569a536303345a1e4d = $this->env->getExtension("native_profiler");
        $__internal_35b2cf83e54c6351e38b88d5f7219757b11178f888ab1a569a536303345a1e4d->enter($__internal_35b2cf83e54c6351e38b88d5f7219757b11178f888ab1a569a536303345a1e4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "organization/newRukZamTest.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_35b2cf83e54c6351e38b88d5f7219757b11178f888ab1a569a536303345a1e4d->leave($__internal_35b2cf83e54c6351e38b88d5f7219757b11178f888ab1a569a536303345a1e4d_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_3993032307f1ad51ea0d0b804f263d6f65e3ad84ef59ff857f448f84831bca58 = $this->env->getExtension("native_profiler");
        $__internal_3993032307f1ad51ea0d0b804f263d6f65e3ad84ef59ff857f448f84831bca58->enter($__internal_3993032307f1ad51ea0d0b804f263d6f65e3ad84ef59ff857f448f84831bca58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
   ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 6
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fio", array()), 'row');
        echo "
    ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "zvanie", array()), 'row');
        echo "

    <ul class=\"tags\" data-prototype=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "rukovoditel_zamestitel", array()), "vars", array()), "prototype", array()), 'widget'));
        echo "\">

    </ul>

    
    <div class=\"form-group\">
        <button type=\"button\" class=\"btn btn-sm btn-primary\" id=\"addRukovoditel\">Добавить руководителя</button>
    </div>
    <div class=\"form-group\">
        <button type=\"button\" class=\"btn btn-sm btn-primary\" id=\"addZamestitel\" style=\"display:none\">Добавить заместителя</button>
    </div>    

    <input type=\"submit\" value=\"Добавить организацию\" class=\"btn btn-success\" />

";
        
        $__internal_3993032307f1ad51ea0d0b804f263d6f65e3ad84ef59ff857f448f84831bca58->leave($__internal_3993032307f1ad51ea0d0b804f263d6f65e3ad84ef59ff857f448f84831bca58_prof);

    }

    // line 25
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_10f1ccb6d8c8811bacb422794b8992821411fcc007e2eac7c2e0eaafd8dd62c4 = $this->env->getExtension("native_profiler");
        $__internal_10f1ccb6d8c8811bacb422794b8992821411fcc007e2eac7c2e0eaafd8dd62c4->enter($__internal_10f1ccb6d8c8811bacb422794b8992821411fcc007e2eac7c2e0eaafd8dd62c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 26
        echo "
";
        
        $__internal_10f1ccb6d8c8811bacb422794b8992821411fcc007e2eac7c2e0eaafd8dd62c4->leave($__internal_10f1ccb6d8c8811bacb422794b8992821411fcc007e2eac7c2e0eaafd8dd62c4_prof);

    }

    public function getTemplateName()
    {
        return "organization/newRukZamTest.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 26,  79 => 25,  57 => 9,  52 => 7,  48 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*    {{ form_start(form) }}*/
/*     {{ form_row(form.fio) }}*/
/*     {{ form_row(form.zvanie) }}*/
/* */
/*     <ul class="tags" data-prototype="{{ form_widget(form.rukovoditel_zamestitel.vars.prototype)|e }}">*/
/* */
/*     </ul>*/
/* */
/*     */
/*     <div class="form-group">*/
/*         <button type="button" class="btn btn-sm btn-primary" id="addRukovoditel">Добавить руководителя</button>*/
/*     </div>*/
/*     <div class="form-group">*/
/*         <button type="button" class="btn btn-sm btn-primary" id="addZamestitel" style="display:none">Добавить заместителя</button>*/
/*     </div>    */
/* */
/*     <input type="submit" value="Добавить организацию" class="btn btn-success" />*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
