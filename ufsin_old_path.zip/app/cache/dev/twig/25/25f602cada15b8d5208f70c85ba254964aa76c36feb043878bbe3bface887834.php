<?php

/* :otchet/ajax:zabolevaniya_kontaktnye_otryad.html.twig */
class __TwigTemplate_5c7aa4c172918b492f677425337e460fddc722b64d53e12a776823d8f6e61a2a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet/ajax:zabolevaniya_kontaktnye_otryad.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b079f203281aeef2c35c52d1930ed7f3a38951e8c4fc1f2c9eee54ba0e635506 = $this->env->getExtension("native_profiler");
        $__internal_b079f203281aeef2c35c52d1930ed7f3a38951e8c4fc1f2c9eee54ba0e635506->enter($__internal_b079f203281aeef2c35c52d1930ed7f3a38951e8c4fc1f2c9eee54ba0e635506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:zabolevaniya_kontaktnye_otryad.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b079f203281aeef2c35c52d1930ed7f3a38951e8c4fc1f2c9eee54ba0e635506->leave($__internal_b079f203281aeef2c35c52d1930ed7f3a38951e8c4fc1f2c9eee54ba0e635506_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_52d6d8058ab47b06bc64bf1397bdcdda34dcb30310407b8b29b49dd46b9cfe38 = $this->env->getExtension("native_profiler");
        $__internal_52d6d8058ab47b06bc64bf1397bdcdda34dcb30310407b8b29b49dd46b9cfe38->enter($__internal_52d6d8058ab47b06bc64bf1397bdcdda34dcb30310407b8b29b49dd46b9cfe38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/zabolevanie_menu.html", ":otchet/ajax:zabolevaniya_kontaktnye_otryad.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Статистика заболевших осужденных по отрядам (контактные)</h3>
        
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetZabolevaniya/otryadKontakt\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>
    
    ";
        // line 25
        $context["place_progivaniya"] = array(0 => "1 отряд", 1 => "2 отряд", 2 => "3 отряд", 3 => "4 отряд", 4 => "5 отряд", 5 => "6 отряд", 6 => "7 отряд", 7 => "8 отряд", 8 => "9 отряд", 9 => "10 отряд", 10 => "11 отряд", 11 => "12 отряд", 12 => "ПКТ", 13 => "ЕПКТ", 14 => "ОСУОН", 15 => "ШИЗО", 16 => "Карантинное отделение");
        // line 26
        echo "    
    <table class=\"table table-hover table-bordered numbers\">
        <thead>
            <tr>
                <td>Учреждение</td>
                ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["place_progivaniya"]) ? $context["place_progivaniya"] : $this->getContext($context, "place_progivaniya")));
        foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
            // line 32
            echo "                    <td>";
            echo twig_escape_filter($this->env, twig_slice($this->env, $context["place"], 0, 5), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "                <td>Итог</td>
            </tr>
        </thead>
        <tbody>

        ";
        // line 39
        $context["flag"] = "0";
        // line 40
        echo "
        ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 42
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                
                ";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["place_progivaniya"]) ? $context["place_progivaniya"] : $this->getContext($context, "place_progivaniya")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
                // line 46
                echo "                    
                        ";
                // line 47
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["orgKontaktnyeProgivaniya"]) ? $context["orgKontaktnyeProgivaniya"] : $this->getContext($context, "orgKontaktnyeProgivaniya")));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["osug"]) {
                    // line 48
                    echo "                        
                            ";
                    // line 49
                    if (($this->getAttribute($context["osug"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                        // line 50
                        echo "                            
                                ";
                        // line 51
                        if (($this->getAttribute($context["osug"], "place_progivaniya", array()) == $context["place"])) {
                            // line 52
                            echo "
                                    <td class=\"pokazatel";
                            // line 53
                            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                            echo "\">";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["osug"], 1, array(), "array"), "html", null, true);
                            echo "</td>
                                    
                                    ";
                            // line 55
                            $context["flag"] = "1";
                            // line 56
                            echo "                                    
                                ";
                        }
                        // line 58
                        echo "                                
                            ";
                    }
                    // line 60
                    echo "
                        ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['osug'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 62
                echo "                        
                        ";
                // line 63
                if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                    // line 64
                    echo "                            <td></td>
                        ";
                }
                // line 66
                echo "                        
                        ";
                // line 67
                $context["flag"] = "0";
                // line 68
                echo "
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 70
            echo "                <td></td>
            </tr> 
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "        </tbody>
        <tfoot>
            <tr>
                <td>Всего</td>
                ";
        // line 77
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["place_progivaniya"]) ? $context["place_progivaniya"] : $this->getContext($context, "place_progivaniya")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
            // line 78
            echo "                    <td id=\"result";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\"></td>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 80
        echo "                <td id=\"vsego\"></td>
            </tr>
        </tfoot>
    </table>
</div>

";
        
        $__internal_52d6d8058ab47b06bc64bf1397bdcdda34dcb30310407b8b29b49dd46b9cfe38->leave($__internal_52d6d8058ab47b06bc64bf1397bdcdda34dcb30310407b8b29b49dd46b9cfe38_prof);

    }

    // line 88
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_1d9ace99c8f9b3cac9fa026b10102783babbb88481b0ca47a9442f0479098221 = $this->env->getExtension("native_profiler");
        $__internal_1d9ace99c8f9b3cac9fa026b10102783babbb88481b0ca47a9442f0479098221->enter($__internal_1d9ace99c8f9b3cac9fa026b10102783babbb88481b0ca47a9442f0479098221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 89
        echo "
";
        
        $__internal_1d9ace99c8f9b3cac9fa026b10102783babbb88481b0ca47a9442f0479098221->leave($__internal_1d9ace99c8f9b3cac9fa026b10102783babbb88481b0ca47a9442f0479098221_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:zabolevaniya_kontaktnye_otryad.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  320 => 89,  314 => 88,  301 => 80,  284 => 78,  267 => 77,  261 => 73,  245 => 70,  230 => 68,  228 => 67,  225 => 66,  221 => 64,  219 => 63,  216 => 62,  201 => 60,  197 => 58,  193 => 56,  191 => 55,  184 => 53,  181 => 52,  179 => 51,  176 => 50,  174 => 49,  171 => 48,  154 => 47,  151 => 46,  134 => 45,  129 => 43,  124 => 42,  107 => 41,  104 => 40,  102 => 39,  95 => 34,  86 => 32,  82 => 31,  75 => 26,  73 => 25,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/zabolevanie_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Статистика заболевших осужденных по отрядам (контактные)</h3>*/
/*         */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetZabolevaniya/otryadKontakt" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/*     */
/*     {% set place_progivaniya = ["1 отряд", "2 отряд", "3 отряд", "4 отряд", "5 отряд", "6 отряд", "7 отряд", "8 отряд", "9 отряд", "10 отряд", "11 отряд", "12 отряд", "ПКТ", "ЕПКТ", "ОСУОН", "ШИЗО", "Карантинное отделение"] %}*/
/*     */
/*     <table class="table table-hover table-bordered numbers">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td>Учреждение</td>*/
/*                 {% for place in place_progivaniya %}*/
/*                     <td>{{ place|slice(0,5) }}</td>*/
/*                 {% endfor %}*/
/*                 <td>Итог</td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/* */
/*         {% set flag = "0" %}*/
/* */
/*         {% for organization in organizations %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{organization.nameShort}}</td>*/
/*                 */
/*                 {% for place in place_progivaniya %}*/
/*                     */
/*                         {% for osug in orgKontaktnyeProgivaniya %}*/
/*                         */
/*                             {% if osug.name_full == organization.nameFull %}*/
/*                             */
/*                                 {% if osug.place_progivaniya == place %}*/
/* */
/*                                     <td class="pokazatel{{loop.parent.loop.index}}">{{ osug[1] }}</td>*/
/*                                     */
/*                                     {% set flag = "1" %}*/
/*                                     */
/*                                 {% endif %}*/
/*                                 */
/*                             {% endif %}*/
/* */
/*                         {% endfor %}*/
/*                         */
/*                         {% if flag == "0" %}*/
/*                             <td></td>*/
/*                         {% endif %}*/
/*                         */
/*                         {% set flag = "0" %}*/
/* */
/*                 {% endfor %}*/
/*                 <td></td>*/
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*             <tr>*/
/*                 <td>Всего</td>*/
/*                 {% for place in place_progivaniya %}*/
/*                     <td id="result{{loop.index}}"></td>*/
/*                 {% endfor %}*/
/*                 <td id="vsego"></td>*/
/*             </tr>*/
/*         </tfoot>*/
/*     </table>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
