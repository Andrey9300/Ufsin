<?php

/* :otchet/ajax:zabolevaniya_viyavlenie.html.twig */
class __TwigTemplate_5b180c7b67542056500d53637df810af129c7e6471bf8c0c484ab6ff1bba8395 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet/ajax:zabolevaniya_viyavlenie.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_039eb18cd0ac52e96a7b1d8437fc8666892a2413dcb8fd58cfba89b6ec3399a0 = $this->env->getExtension("native_profiler");
        $__internal_039eb18cd0ac52e96a7b1d8437fc8666892a2413dcb8fd58cfba89b6ec3399a0->enter($__internal_039eb18cd0ac52e96a7b1d8437fc8666892a2413dcb8fd58cfba89b6ec3399a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:zabolevaniya_viyavlenie.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_039eb18cd0ac52e96a7b1d8437fc8666892a2413dcb8fd58cfba89b6ec3399a0->leave($__internal_039eb18cd0ac52e96a7b1d8437fc8666892a2413dcb8fd58cfba89b6ec3399a0_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_febdba307d87e4baa6edf32667617dd769439f358c2e8c56f1bc541bd5480818 = $this->env->getExtension("native_profiler");
        $__internal_febdba307d87e4baa6edf32667617dd769439f358c2e8c56f1bc541bd5480818->enter($__internal_febdba307d87e4baa6edf32667617dd769439f358c2e8c56f1bc541bd5480818_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/zabolevanie_menu.html", ":otchet/ajax:zabolevaniya_viyavlenie.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Статистика заболевших осужденных по выявлению</h3>
                
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetZabolevaniya/viyavlenie\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>
    
    <table class=\"table table-hover table-bordered numbers\">
        <thead>
            <tr>
                <td>Учреждение</td>
                ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 30
            echo "                    <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                <td>Итог</td>
            </tr>
        </thead>
        <tbody>

        ";
        // line 37
        $context["flag"] = "0";
        // line 38
        echo "
        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(array(0 => "При профосмотре", 1 => "При обращении в МЧ"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["viyavlen"]) {
            // line 40
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 41
            echo twig_escape_filter($this->env, $context["viyavlen"], "html", null, true);
            echo "</td>
                
                ";
            // line 43
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
                // line 44
                echo "                
                    ";
                // line 45
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["osugdeniy"]) ? $context["osugdeniy"] : $this->getContext($context, "osugdeniy")));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["quantity"]) {
                    // line 46
                    echo "                    
                        ";
                    // line 47
                    if (($this->getAttribute($context["quantity"], "viyavlen", array()) == $context["viyavlen"])) {
                        // line 48
                        echo "                        
                            ";
                        // line 49
                        if (($this->getAttribute($context["quantity"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                            // line 50
                            echo "                                <td class=\"pokazatel";
                            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                            echo "\">";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["quantity"], 1, array(), "array"), "html", null, true);
                            echo "</td>
                                ";
                            // line 51
                            $context["flag"] = "1";
                            // line 52
                            echo "                            ";
                        }
                        // line 53
                        echo "                            
                        ";
                    }
                    // line 55
                    echo "
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quantity'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 57
                echo "                    
                    ";
                // line 58
                if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                    // line 59
                    echo "                        <td></td>
                    ";
                }
                // line 61
                echo "                    ";
                $context["flag"] = "0";
                // line 62
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 63
            echo "                <td></td>
            </tr> 
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['viyavlen'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "        </tbody>
        <tfoot>
            <tr>
                <td>Всего</td>
                ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 71
            echo "                    <td id=\"result";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\"></td>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "                <td id=\"vsego\"></td>
            </tr>
        </tfoot>
    </table>
</div>

";
        
        $__internal_febdba307d87e4baa6edf32667617dd769439f358c2e8c56f1bc541bd5480818->leave($__internal_febdba307d87e4baa6edf32667617dd769439f358c2e8c56f1bc541bd5480818_prof);

    }

    // line 81
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_1f99cbf6a73b4aa46c9f5dd9ca9168d57f3ae76746f5d21117b8eb0f5ec99485 = $this->env->getExtension("native_profiler");
        $__internal_1f99cbf6a73b4aa46c9f5dd9ca9168d57f3ae76746f5d21117b8eb0f5ec99485->enter($__internal_1f99cbf6a73b4aa46c9f5dd9ca9168d57f3ae76746f5d21117b8eb0f5ec99485_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 82
        echo "
";
        
        $__internal_1f99cbf6a73b4aa46c9f5dd9ca9168d57f3ae76746f5d21117b8eb0f5ec99485->leave($__internal_1f99cbf6a73b4aa46c9f5dd9ca9168d57f3ae76746f5d21117b8eb0f5ec99485_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:zabolevaniya_viyavlenie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  308 => 82,  302 => 81,  289 => 73,  272 => 71,  255 => 70,  249 => 66,  233 => 63,  219 => 62,  216 => 61,  212 => 59,  210 => 58,  207 => 57,  192 => 55,  188 => 53,  185 => 52,  183 => 51,  176 => 50,  174 => 49,  171 => 48,  169 => 47,  166 => 46,  149 => 45,  146 => 44,  129 => 43,  124 => 41,  119 => 40,  102 => 39,  99 => 38,  97 => 37,  90 => 32,  81 => 30,  77 => 29,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/zabolevanie_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Статистика заболевших осужденных по выявлению</h3>*/
/*                 */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetZabolevaniya/viyavlenie" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/*     */
/*     <table class="table table-hover table-bordered numbers">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td>Учреждение</td>*/
/*                 {% for organization in organizations %}*/
/*                     <td>{{ organization.nameShort }}</td>*/
/*                 {% endfor %}*/
/*                 <td>Итог</td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/* */
/*         {% set flag = "0" %}*/
/* */
/*         {% for viyavlen in ["При профосмотре", "При обращении в МЧ"] %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{ viyavlen }}</td>*/
/*                 */
/*                 {% for organization in organizations %}*/
/*                 */
/*                     {% for quantity in osugdeniy %}*/
/*                     */
/*                         {% if quantity.viyavlen == viyavlen %}*/
/*                         */
/*                             {% if quantity.name_full == organization.nameFull %}*/
/*                                 <td class="pokazatel{{loop.parent.loop.index}}">{{quantity[1]}}</td>*/
/*                                 {% set flag = "1" %}*/
/*                             {% endif %}*/
/*                             */
/*                         {% endif %}*/
/* */
/*                     {% endfor %}*/
/*                     */
/*                     {% if flag == "0" %}*/
/*                         <td></td>*/
/*                     {% endif %}*/
/*                     {% set flag = "0" %}*/
/*                 {% endfor %}*/
/*                 <td></td>*/
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*             <tr>*/
/*                 <td>Всего</td>*/
/*                 {% for organization in organizations %}*/
/*                     <td id="result{{loop.index}}"></td>*/
/*                 {% endfor %}*/
/*                 <td id="vsego"></td>*/
/*             </tr>*/
/*         </tfoot>*/
/*     </table>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
