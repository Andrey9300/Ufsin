<?php

/* TwigBundle:Exception:error403.html.twig */
class __TwigTemplate_ff6df60024859c4581f64f95000c890811143eaf52291cdbd718994b78195dbf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error403.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a63e9ae7605c5c98037493ff99a81c5fbc6f7e97fd9a71d1c1ffc6d967f42ac7 = $this->env->getExtension("native_profiler");
        $__internal_a63e9ae7605c5c98037493ff99a81c5fbc6f7e97fd9a71d1c1ffc6d967f42ac7->enter($__internal_a63e9ae7605c5c98037493ff99a81c5fbc6f7e97fd9a71d1c1ffc6d967f42ac7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a63e9ae7605c5c98037493ff99a81c5fbc6f7e97fd9a71d1c1ffc6d967f42ac7->leave($__internal_a63e9ae7605c5c98037493ff99a81c5fbc6f7e97fd9a71d1c1ffc6d967f42ac7_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_2742441207cdaf2d6f0101bdf0cbf0a03a5aa5f5ae6e5264dff62b118d7d0002 = $this->env->getExtension("native_profiler");
        $__internal_2742441207cdaf2d6f0101bdf0cbf0a03a5aa5f5ae6e5264dff62b118d7d0002->enter($__internal_2742441207cdaf2d6f0101bdf0cbf0a03a5aa5f5ae6e5264dff62b118d7d0002_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_2742441207cdaf2d6f0101bdf0cbf0a03a5aa5f5ae6e5264dff62b118d7d0002->leave($__internal_2742441207cdaf2d6f0101bdf0cbf0a03a5aa5f5ae6e5264dff62b118d7d0002_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_04ec388d55bd15a7a6d0280b967a5deb8782a5dc4b50b1cc0a2c6a204745ade4 = $this->env->getExtension("native_profiler");
        $__internal_04ec388d55bd15a7a6d0280b967a5deb8782a5dc4b50b1cc0a2c6a204745ade4->enter($__internal_04ec388d55bd15a7a6d0280b967a5deb8782a5dc4b50b1cc0a2c6a204745ade4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1 class=\"text-danger\">Ошибка доступа</h1>

    <p class=\"lead\">
        У вас нет прав на посещение данного ресурса.
    </p>
    <p>
        Обратитесь к вашему администратору или начальнику.
    </p>
";
        
        $__internal_04ec388d55bd15a7a6d0280b967a5deb8782a5dc4b50b1cc0a2c6a204745ade4->leave($__internal_04ec388d55bd15a7a6d0280b967a5deb8782a5dc4b50b1cc0a2c6a204745ade4_prof);

    }

    // line 16
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_811cf694444e6145ab971873089bad4c0bd37595d573ab7d0ad73baaec0e85d8 = $this->env->getExtension("native_profiler");
        $__internal_811cf694444e6145ab971873089bad4c0bd37595d573ab7d0ad73baaec0e85d8->enter($__internal_811cf694444e6145ab971873089bad4c0bd37595d573ab7d0ad73baaec0e85d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 17
        echo "
";
        
        $__internal_811cf694444e6145ab971873089bad4c0bd37595d573ab7d0ad73baaec0e85d8->leave($__internal_811cf694444e6145ab971873089bad4c0bd37595d573ab7d0ad73baaec0e85d8_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 17,  69 => 16,  54 => 6,  48 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'error' %}*/
/* */
/* {% block main %}*/
/*     <h1 class="text-danger">Ошибка доступа</h1>*/
/* */
/*     <p class="lead">*/
/*         У вас нет прав на посещение данного ресурса.*/
/*     </p>*/
/*     <p>*/
/*         Обратитесь к вашему администратору или начальнику.*/
/*     </p>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
/* */
