<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_1ddba45aff4ad6928a345f38342dbaa6d56e2c5fe1daf0100097dc33a59e25f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca4d68d4dc77b320630bf672f6fff9488067f2dfc983c4aa09153ba8da8786ce = $this->env->getExtension("native_profiler");
        $__internal_ca4d68d4dc77b320630bf672f6fff9488067f2dfc983c4aa09153ba8da8786ce->enter($__internal_ca4d68d4dc77b320630bf672f6fff9488067f2dfc983c4aa09153ba8da8786ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_ca4d68d4dc77b320630bf672f6fff9488067f2dfc983c4aa09153ba8da8786ce->leave($__internal_ca4d68d4dc77b320630bf672f6fff9488067f2dfc983c4aa09153ba8da8786ce_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
