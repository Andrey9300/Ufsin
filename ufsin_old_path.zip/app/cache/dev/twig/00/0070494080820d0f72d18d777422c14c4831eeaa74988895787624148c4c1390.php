<?php

/* :organization:newRukZamTest.html.twig */
class __TwigTemplate_8cc0b9c7d32a55eccbf40f8d94be6d11902212471974cc9c97085ae9382c40ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":organization:newRukZamTest.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c1d7405bd6a8f234f6e3fdfee0acde33a6be3e7aca635d8703c015adb4c8947 = $this->env->getExtension("native_profiler");
        $__internal_9c1d7405bd6a8f234f6e3fdfee0acde33a6be3e7aca635d8703c015adb4c8947->enter($__internal_9c1d7405bd6a8f234f6e3fdfee0acde33a6be3e7aca635d8703c015adb4c8947_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":organization:newRukZamTest.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c1d7405bd6a8f234f6e3fdfee0acde33a6be3e7aca635d8703c015adb4c8947->leave($__internal_9c1d7405bd6a8f234f6e3fdfee0acde33a6be3e7aca635d8703c015adb4c8947_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_e9e26a10ccaa4282eeeb4f55a6a3cee8b83b40dbb735f2d3d3d36b2d96b6c33d = $this->env->getExtension("native_profiler");
        $__internal_e9e26a10ccaa4282eeeb4f55a6a3cee8b83b40dbb735f2d3d3d36b2d96b6c33d->enter($__internal_e9e26a10ccaa4282eeeb4f55a6a3cee8b83b40dbb735f2d3d3d36b2d96b6c33d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
   ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 6
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fio", array()), 'row');
        echo "
    ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "zvanie", array()), 'row');
        echo "

    <ul class=\"tags\" data-prototype=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "rukovoditel_zamestitel", array()), "vars", array()), "prototype", array()), 'widget'));
        echo "\">

    </ul>

    
    <div class=\"form-group\">
        <button type=\"button\" class=\"btn btn-sm btn-primary\" id=\"addRukovoditel\">Добавить руководителя</button>
    </div>
    <div class=\"form-group\">
        <button type=\"button\" class=\"btn btn-sm btn-primary\" id=\"addZamestitel\" style=\"display:none\">Добавить заместителя</button>
    </div>    

    <input type=\"submit\" value=\"Добавить организацию\" class=\"btn btn-success\" />

";
        
        $__internal_e9e26a10ccaa4282eeeb4f55a6a3cee8b83b40dbb735f2d3d3d36b2d96b6c33d->leave($__internal_e9e26a10ccaa4282eeeb4f55a6a3cee8b83b40dbb735f2d3d3d36b2d96b6c33d_prof);

    }

    // line 25
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_c3e25ec6ec5fc61d41d00a8786089418d327e12d2305fae8d157e35ab57079ff = $this->env->getExtension("native_profiler");
        $__internal_c3e25ec6ec5fc61d41d00a8786089418d327e12d2305fae8d157e35ab57079ff->enter($__internal_c3e25ec6ec5fc61d41d00a8786089418d327e12d2305fae8d157e35ab57079ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 26
        echo "
";
        
        $__internal_c3e25ec6ec5fc61d41d00a8786089418d327e12d2305fae8d157e35ab57079ff->leave($__internal_c3e25ec6ec5fc61d41d00a8786089418d327e12d2305fae8d157e35ab57079ff_prof);

    }

    public function getTemplateName()
    {
        return ":organization:newRukZamTest.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 26,  79 => 25,  57 => 9,  52 => 7,  48 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*    {{ form_start(form) }}*/
/*     {{ form_row(form.fio) }}*/
/*     {{ form_row(form.zvanie) }}*/
/* */
/*     <ul class="tags" data-prototype="{{ form_widget(form.rukovoditel_zamestitel.vars.prototype)|e }}">*/
/* */
/*     </ul>*/
/* */
/*     */
/*     <div class="form-group">*/
/*         <button type="button" class="btn btn-sm btn-primary" id="addRukovoditel">Добавить руководителя</button>*/
/*     </div>*/
/*     <div class="form-group">*/
/*         <button type="button" class="btn btn-sm btn-primary" id="addZamestitel" style="display:none">Добавить заместителя</button>*/
/*     </div>    */
/* */
/*     <input type="submit" value="Добавить организацию" class="btn btn-success" />*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
