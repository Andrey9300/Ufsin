<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_6f7dffa470b8fd22f0b004be351b07cefce410c421cc7590354c95c587b3800c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf166cbbd1b9fdb1a1d21386a93351aa667a37ebebfbf1b0b3a2fa2ca926e708 = $this->env->getExtension("native_profiler");
        $__internal_cf166cbbd1b9fdb1a1d21386a93351aa667a37ebebfbf1b0b3a2fa2ca926e708->enter($__internal_cf166cbbd1b9fdb1a1d21386a93351aa667a37ebebfbf1b0b3a2fa2ca926e708_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_cf166cbbd1b9fdb1a1d21386a93351aa667a37ebebfbf1b0b3a2fa2ca926e708->leave($__internal_cf166cbbd1b9fdb1a1d21386a93351aa667a37ebebfbf1b0b3a2fa2ca926e708_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
