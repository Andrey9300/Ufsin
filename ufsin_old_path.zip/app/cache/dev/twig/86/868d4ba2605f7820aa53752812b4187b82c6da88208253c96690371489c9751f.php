<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_e15145c55b28ca4ca6c8e731c12b3ba17292f7c12532368cdaedcd3edcaf422a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_805f1f737b296627f0cb8d57fbbbf2919157fdc540499e94a1b5fa8bc8575def = $this->env->getExtension("native_profiler");
        $__internal_805f1f737b296627f0cb8d57fbbbf2919157fdc540499e94a1b5fa8bc8575def->enter($__internal_805f1f737b296627f0cb8d57fbbbf2919157fdc540499e94a1b5fa8bc8575def_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_805f1f737b296627f0cb8d57fbbbf2919157fdc540499e94a1b5fa8bc8575def->leave($__internal_805f1f737b296627f0cb8d57fbbbf2919157fdc540499e94a1b5fa8bc8575def_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
