<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_3cddc62b453a6c45bdda7292466fe46bbaea79aec3a3152a5e0dfa1bfe4c38f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10ebf91048ebafbd06feaf2d2d1dd31f91e14b30be34fa5e370fc494e945cd83 = $this->env->getExtension("native_profiler");
        $__internal_10ebf91048ebafbd06feaf2d2d1dd31f91e14b30be34fa5e370fc494e945cd83->enter($__internal_10ebf91048ebafbd06feaf2d2d1dd31f91e14b30be34fa5e370fc494e945cd83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_10ebf91048ebafbd06feaf2d2d1dd31f91e14b30be34fa5e370fc494e945cd83->leave($__internal_10ebf91048ebafbd06feaf2d2d1dd31f91e14b30be34fa5e370fc494e945cd83_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
