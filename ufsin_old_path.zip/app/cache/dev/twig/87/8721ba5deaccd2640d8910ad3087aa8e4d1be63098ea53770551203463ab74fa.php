<?php

/* :otchet/ajax:proverka_narusheniya_obj.html.twig */
class __TwigTemplate_aed1b7fffd2497bb35848fa8335f2712b891ed268c596c832dfbfc7ff7140311 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet/ajax:proverka_narusheniya_obj.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed5a5d347506ff88764061dcda58d494758a8a87ec8f97f754205c2ff8e3b3f2 = $this->env->getExtension("native_profiler");
        $__internal_ed5a5d347506ff88764061dcda58d494758a8a87ec8f97f754205c2ff8e3b3f2->enter($__internal_ed5a5d347506ff88764061dcda58d494758a8a87ec8f97f754205c2ff8e3b3f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:proverka_narusheniya_obj.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ed5a5d347506ff88764061dcda58d494758a8a87ec8f97f754205c2ff8e3b3f2->leave($__internal_ed5a5d347506ff88764061dcda58d494758a8a87ec8f97f754205c2ff8e3b3f2_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_a5717240aa54b4b964680a0f20799c450b62bd6338d83ee33ef127d5c285b28e = $this->env->getExtension("native_profiler");
        $__internal_a5717240aa54b4b964680a0f20799c450b62bd6338d83ee33ef127d5c285b28e->enter($__internal_a5717240aa54b4b964680a0f20799c450b62bd6338d83ee33ef127d5c285b28e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/proverka_menu.html", ":otchet/ajax:proverka_narusheniya_obj.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Статистика нарушений по учреждениям и объектам</h3>
            
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetProverka/narusheniyaObj\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>
    
    <table class=\"table table-hover table-bordered numbers\">
        <thead>
            <tr>
                <td></td>
                ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 30
            echo "                    <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                <td>Итого</td>
            </tr>
        </thead>
        <tbody>
  
        ";
        // line 37
        $context["flag"] = "0";
        // line 38
        echo "
        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["objects"]) ? $context["objects"] : $this->getContext($context, "objects")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["obj"]) {
            // line 40
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["obj"], "name", array()), "html", null, true);
            echo "</td>
                
                ";
            // line 43
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
                // line 44
                echo "                
                    ";
                // line 45
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaObj"]) ? $context["narusheniyaObj"] : $this->getContext($context, "narusheniyaObj")));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["quantity"]) {
                    // line 46
                    echo "                    
                        ";
                    // line 47
                    if (($this->getAttribute($context["quantity"], "name", array()) == $this->getAttribute($context["obj"], "name", array()))) {
                        // line 48
                        echo "                        
                            ";
                        // line 49
                        if (($this->getAttribute($context["quantity"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                            // line 50
                            echo "                                <td class=\"pokazatel";
                            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                            echo "\">";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["quantity"], 1, array(), "array"), "html", null, true);
                            echo "</td>
                                ";
                            // line 51
                            $context["flag"] = "1";
                            // line 52
                            echo "                            ";
                        }
                        // line 53
                        echo "                            
                        ";
                    }
                    // line 55
                    echo "
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quantity'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 57
                echo "                    
                    ";
                // line 58
                if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                    // line 59
                    echo "                        <td></td>
                    ";
                }
                // line 61
                echo "                    ";
                $context["flag"] = "0";
                // line 62
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 63
            echo "                <td></td>
            </tr> 
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['obj'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "        </tbody>
        <tfoot>
            <tr>
                <td>Всего</td>
                ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 71
            echo "                    <td id=\"result";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\"></td>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "                <td id=\"vsego\"></td>
            </tr>
            <tr>
                <td></td>
                ";
        // line 77
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 78
            echo "                    <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 80
        echo "                <td></td>
            </tr>
        </tfoot>
    </table>
</div>
";
        
        $__internal_a5717240aa54b4b964680a0f20799c450b62bd6338d83ee33ef127d5c285b28e->leave($__internal_a5717240aa54b4b964680a0f20799c450b62bd6338d83ee33ef127d5c285b28e_prof);

    }

    // line 87
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_6686451f71d191947b5968f7e65285adbe5a039dccc94eabad185a04025f3fd1 = $this->env->getExtension("native_profiler");
        $__internal_6686451f71d191947b5968f7e65285adbe5a039dccc94eabad185a04025f3fd1->enter($__internal_6686451f71d191947b5968f7e65285adbe5a039dccc94eabad185a04025f3fd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 88
        echo "
";
        
        $__internal_6686451f71d191947b5968f7e65285adbe5a039dccc94eabad185a04025f3fd1->leave($__internal_6686451f71d191947b5968f7e65285adbe5a039dccc94eabad185a04025f3fd1_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:proverka_narusheniya_obj.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  326 => 88,  320 => 87,  308 => 80,  299 => 78,  295 => 77,  289 => 73,  272 => 71,  255 => 70,  249 => 66,  233 => 63,  219 => 62,  216 => 61,  212 => 59,  210 => 58,  207 => 57,  192 => 55,  188 => 53,  185 => 52,  183 => 51,  176 => 50,  174 => 49,  171 => 48,  169 => 47,  166 => 46,  149 => 45,  146 => 44,  129 => 43,  124 => 41,  119 => 40,  102 => 39,  99 => 38,  97 => 37,  90 => 32,  81 => 30,  77 => 29,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/proverka_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Статистика нарушений по учреждениям и объектам</h3>*/
/*             */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetProverka/narusheniyaObj" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/*     */
/*     <table class="table table-hover table-bordered numbers">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 {% for organization in organizations %}*/
/*                     <td>{{organization.nameShort}}</td>*/
/*                 {% endfor %}*/
/*                 <td>Итого</td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*   */
/*         {% set flag = "0" %}*/
/* */
/*         {% for obj in objects %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{obj.name}}</td>*/
/*                 */
/*                 {% for organization in organizations %}*/
/*                 */
/*                     {% for quantity in narusheniyaObj %}*/
/*                     */
/*                         {% if quantity.name == obj.name %}*/
/*                         */
/*                             {% if quantity.name_full == organization.nameFull %}*/
/*                                 <td class="pokazatel{{loop.parent.loop.index}}">{{quantity[1]}}</td>*/
/*                                 {% set flag = "1" %}*/
/*                             {% endif %}*/
/*                             */
/*                         {% endif %}*/
/* */
/*                     {% endfor %}*/
/*                     */
/*                     {% if flag == "0" %}*/
/*                         <td></td>*/
/*                     {% endif %}*/
/*                     {% set flag = "0" %}*/
/*                 {% endfor %}*/
/*                 <td></td>*/
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*             <tr>*/
/*                 <td>Всего</td>*/
/*                 {% for organization in organizations %}*/
/*                     <td id="result{{loop.index}}"></td>*/
/*                 {% endfor %}*/
/*                 <td id="vsego"></td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 {% for organization in organizations %}*/
/*                     <td>{{organization.nameShort}}</td>*/
/*                 {% endfor %}*/
/*                 <td></td>*/
/*             </tr>*/
/*         </tfoot>*/
/*     </table>*/
/* </div>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
