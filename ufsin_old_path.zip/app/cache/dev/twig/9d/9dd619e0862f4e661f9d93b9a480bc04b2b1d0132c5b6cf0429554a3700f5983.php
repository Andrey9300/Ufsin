<?php

/* :otchet:proverkaNevypAll.html.twig */
class __TwigTemplate_bb7e2e69f08ec65cdca747c47eb2bab07a0b838dd7db6df5fc511fbd9aeb6ced extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet:proverkaNevypAll.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_81cf23681fd135ca029cf60edc811c7d6a458549da01e10f393d13c609ed3bb6 = $this->env->getExtension("native_profiler");
        $__internal_81cf23681fd135ca029cf60edc811c7d6a458549da01e10f393d13c609ed3bb6->enter($__internal_81cf23681fd135ca029cf60edc811c7d6a458549da01e10f393d13c609ed3bb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet:proverkaNevypAll.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_81cf23681fd135ca029cf60edc811c7d6a458549da01e10f393d13c609ed3bb6->leave($__internal_81cf23681fd135ca029cf60edc811c7d6a458549da01e10f393d13c609ed3bb6_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_4d3f0aad88d31677955b73f8626ab15d829f22bc70704eb2d145aa2b94ab05c1 = $this->env->getExtension("native_profiler");
        $__internal_4d3f0aad88d31677955b73f8626ab15d829f22bc70704eb2d145aa2b94ab05c1->enter($__internal_4d3f0aad88d31677955b73f8626ab15d829f22bc70704eb2d145aa2b94ab05c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/proverka_menu.html", ":otchet:proverkaNevypAll.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Невыполненные нарушения</h3>
        
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetProverka/proverkaNevyp\">
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>
    
    <table class=\"table table-hover main narusheniyaOrganization\">
        <thead>
            <tr>
                <td>УК</td>
                <td>Объект</td>
                <td>Описание</td>
                <td>Дата устранения</td>
                <td>Затраты</td>
                <td>Отметка устранения</td>
            </tr>
        </thead>
        <tbody>
            ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverkaNevypAll"]) ? $context["proverkaNevypAll"] : $this->getContext($context, "proverkaNevypAll")));
        foreach ($context['_seq'] as $context["_key"] => $context["proverka"]) {
            // line 38
            echo "                <tr>
                    <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "name_short", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "name", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "description", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 42
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["proverka"], "date_ustraneniya", array()), "d.m.Y"), "html", null, true);
            echo "</td>
                    <td>";
            // line 43
            if (($this->getAttribute($context["proverka"], "zatraty", array()) == "1")) {
                // line 44
                echo "                        Требует больших затрат
                        ";
            } elseif (($this->getAttribute(            // line 45
$context["proverka"], "zatraty", array()) == "0")) {
                // line 46
                echo "                        Требует затрат
                        ";
            } elseif (($this->getAttribute(            // line 47
$context["proverka"], "zatraty", array()) == "-1")) {
                // line 48
                echo "                        Не требует затрат
                        ";
            }
            // line 50
            echo "                    </td>
                    <td>
                        <select class=\"form-control otmetka\">
                            ";
            // line 53
            if (($this->getAttribute($context["proverka"], "otmetka_ustraneniya", array()) == "0")) {
                // line 54
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                                <option id=\"";
                // line 55
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 56
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 57
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                            ";
            } elseif (($this->getAttribute(            // line 58
$context["proverka"], "otmetka_ustraneniya", array()) == "-1")) {
                // line 59
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                                <option id=\"";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 62
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                            ";
            } elseif (($this->getAttribute(            // line 63
$context["proverka"], "otmetka_ustraneniya", array()) == "1")) {
                // line 64
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                                <option id=\"";
                // line 67
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                            ";
            } elseif (($this->getAttribute(            // line 68
$context["proverka"], "otmetka_ustraneniya", array()) == "2")) {
                // line 69
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                                <option id=\"";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                            ";
            }
            // line 74
            echo "                        </select>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['proverka'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 78
        echo "        </tbody>
    </table>
</div>
        
";
        
        $__internal_4d3f0aad88d31677955b73f8626ab15d829f22bc70704eb2d145aa2b94ab05c1->leave($__internal_4d3f0aad88d31677955b73f8626ab15d829f22bc70704eb2d145aa2b94ab05c1_prof);

    }

    // line 84
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_c32e82f687515eeb76cd8cdab58239cb9d5cacb9a61e4ab7389daa2ab96f001d = $this->env->getExtension("native_profiler");
        $__internal_c32e82f687515eeb76cd8cdab58239cb9d5cacb9a61e4ab7389daa2ab96f001d->enter($__internal_c32e82f687515eeb76cd8cdab58239cb9d5cacb9a61e4ab7389daa2ab96f001d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 85
        echo "
";
        
        $__internal_c32e82f687515eeb76cd8cdab58239cb9d5cacb9a61e4ab7389daa2ab96f001d->leave($__internal_c32e82f687515eeb76cd8cdab58239cb9d5cacb9a61e4ab7389daa2ab96f001d_prof);

    }

    public function getTemplateName()
    {
        return ":otchet:proverkaNevypAll.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  232 => 85,  226 => 84,  215 => 78,  206 => 74,  201 => 72,  197 => 71,  193 => 70,  188 => 69,  186 => 68,  182 => 67,  178 => 66,  174 => 65,  169 => 64,  167 => 63,  163 => 62,  159 => 61,  155 => 60,  150 => 59,  148 => 58,  144 => 57,  140 => 56,  136 => 55,  131 => 54,  129 => 53,  124 => 50,  120 => 48,  118 => 47,  115 => 46,  113 => 45,  110 => 44,  108 => 43,  104 => 42,  100 => 41,  96 => 40,  92 => 39,  89 => 38,  85 => 37,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/proverka_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Невыполненные нарушения</h3>*/
/*         */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetProverka/proverkaNevyp">*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/*     */
/*     <table class="table table-hover main narusheniyaOrganization">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td>УК</td>*/
/*                 <td>Объект</td>*/
/*                 <td>Описание</td>*/
/*                 <td>Дата устранения</td>*/
/*                 <td>Затраты</td>*/
/*                 <td>Отметка устранения</td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*             {% for proverka in proverkaNevypAll %}*/
/*                 <tr>*/
/*                     <td>{{ proverka.name_short }}</td>*/
/*                     <td>{{ proverka.name }}</td>*/
/*                     <td>{{ proverka.description }}</td>*/
/*                     <td>{{ proverka.date_ustraneniya|date("d.m.Y") }}</td>*/
/*                     <td>{% if proverka.zatraty == "1" %}*/
/*                         Требует больших затрат*/
/*                         {% elseif proverka.zatraty == "0" %}*/
/*                         Требует затрат*/
/*                         {% elseif proverka.zatraty == "-1" %}*/
/*                         Не требует затрат*/
/*                         {% endif %}*/
/*                     </td>*/
/*                     <td>*/
/*                         <select class="form-control otmetka">*/
/*                             {% if proverka.otmetka_ustraneniya == "0" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                             {% elseif proverka.otmetka_ustraneniya == "-1" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                             {% elseif proverka.otmetka_ustraneniya == "1" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                             {% elseif proverka.otmetka_ustraneniya == "2" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                             {% endif %}*/
/*                         </select>*/
/*                     </td>*/
/*                 </tr>*/
/*             {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* </div>*/
/*         */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
