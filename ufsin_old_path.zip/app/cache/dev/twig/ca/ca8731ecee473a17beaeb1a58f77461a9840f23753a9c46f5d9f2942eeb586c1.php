<?php

/* :otchet/ajax:proverka_nakazanie_type.html.twig */
class __TwigTemplate_5e0a62d0ca33ef99333643f033420ddc62dc59598d912371728a90c86e07f8f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13855fbcd691f6e2b72a565b8c1cb42642f4805e706d2cd15a52149290cc56a2 = $this->env->getExtension("native_profiler");
        $__internal_13855fbcd691f6e2b72a565b8c1cb42642f4805e706d2cd15a52149290cc56a2->enter($__internal_13855fbcd691f6e2b72a565b8c1cb42642f4805e706d2cd15a52149290cc56a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:proverka_nakazanie_type.html.twig"));

        // line 1
        echo "<div class=\"row\">
    <table class=\"table table-hover table-bordered numbers\">
        <thead>
        <tr>
            <td></td>
            <td style=\"font-size:12px\">Неполное служебное</td>
            <td style=\"font-size:12px\">Строгий выговор</td>
            <td style=\"font-size:12px\">Выговор</td>
            <td style=\"font-size:12px\">Замечание</td>
            <td style=\"font-size:12px\">Ораничиться ранее</td>
            <td style=\"font-size:12px\">Строго предупредить</td>
            <td style=\"font-size:12px\">Итог</td>
        </tr>
        </thead>
        <tbody>

        ";
        // line 17
        $context["flag1"] = "0";
        // line 18
        echo "        ";
        $context["flag2"] = "0";
        // line 19
        echo "        ";
        $context["flag3"] = "0";
        // line 20
        echo "        ";
        $context["flag4"] = "0";
        // line 21
        echo "        ";
        $context["flag5"] = "0";
        // line 22
        echo "        ";
        $context["flag6"] = "0";
        // line 23
        echo "
        ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 25
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 26
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["organization"], "nameShort", array()), 3, 7), "html", null, true);
            echo "</td>

                ";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaType1"]) ? $context["narusheniyaType1"] : $this->getContext($context, "narusheniyaType1")));
            foreach ($context['_seq'] as $context["_key"] => $context["narush"]) {
                // line 29
                echo "
                    ";
                // line 30
                if (($this->getAttribute($context["narush"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 31
                    echo "                        <td class=\"pokazatel1\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["narush"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 32
                    $context["flag1"] = "1";
                    // line 33
                    echo "                    ";
                }
                // line 34
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['narush'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "
                ";
            // line 37
            if (((isset($context["flag1"]) ? $context["flag1"] : $this->getContext($context, "flag1")) == "0")) {
                // line 38
                echo "                    <td></td>
                ";
            }
            // line 40
            echo "                ";
            $context["flag1"] = "0";
            // line 41
            echo "
                ";
            // line 42
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaType2"]) ? $context["narusheniyaType2"] : $this->getContext($context, "narusheniyaType2")));
            foreach ($context['_seq'] as $context["_key"] => $context["narush"]) {
                // line 43
                echo "
                    ";
                // line 44
                if (($this->getAttribute($context["narush"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 45
                    echo "                        <td class=\"pokazatel2\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["narush"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 46
                    $context["flag2"] = "1";
                    // line 47
                    echo "                    ";
                }
                // line 48
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['narush'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 50
            echo "
                ";
            // line 51
            if (((isset($context["flag2"]) ? $context["flag2"] : $this->getContext($context, "flag2")) == "0")) {
                // line 52
                echo "                    <td></td>
                ";
            }
            // line 54
            echo "                ";
            $context["flag2"] = "0";
            // line 55
            echo "
                ";
            // line 56
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaType3"]) ? $context["narusheniyaType3"] : $this->getContext($context, "narusheniyaType3")));
            foreach ($context['_seq'] as $context["_key"] => $context["narush"]) {
                // line 57
                echo "
                    ";
                // line 58
                if (($this->getAttribute($context["narush"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 59
                    echo "                        <td class=\"pokazatel3\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["narush"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 60
                    $context["flag3"] = "1";
                    // line 61
                    echo "                    ";
                }
                // line 62
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['narush'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 64
            echo "
                ";
            // line 65
            if (((isset($context["flag3"]) ? $context["flag3"] : $this->getContext($context, "flag3")) == "0")) {
                // line 66
                echo "                    <td></td>
                ";
            }
            // line 68
            echo "                ";
            $context["flag3"] = "0";
            // line 69
            echo "
                ";
            // line 70
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaType4"]) ? $context["narusheniyaType4"] : $this->getContext($context, "narusheniyaType4")));
            foreach ($context['_seq'] as $context["_key"] => $context["narush"]) {
                // line 71
                echo "
                    ";
                // line 72
                if (($this->getAttribute($context["narush"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 73
                    echo "                        <td class=\"pokazatel1\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["narush"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 74
                    $context["flag4"] = "1";
                    // line 75
                    echo "                    ";
                }
                // line 76
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['narush'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 78
            echo "
                ";
            // line 79
            if (((isset($context["flag4"]) ? $context["flag4"] : $this->getContext($context, "flag4")) == "0")) {
                // line 80
                echo "                    <td></td>
                ";
            }
            // line 82
            echo "                ";
            $context["flag4"] = "0";
            // line 83
            echo "
                ";
            // line 84
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaType5"]) ? $context["narusheniyaType5"] : $this->getContext($context, "narusheniyaType5")));
            foreach ($context['_seq'] as $context["_key"] => $context["narush"]) {
                // line 85
                echo "
                    ";
                // line 86
                if (($this->getAttribute($context["narush"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 87
                    echo "                        <td class=\"pokazatel1\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["narush"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 88
                    $context["flag5"] = "1";
                    // line 89
                    echo "                    ";
                }
                // line 90
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['narush'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 92
            echo "
                ";
            // line 93
            if (((isset($context["flag5"]) ? $context["flag5"] : $this->getContext($context, "flag5")) == "0")) {
                // line 94
                echo "                    <td></td>
                ";
            }
            // line 96
            echo "                ";
            $context["flag5"] = "0";
            // line 97
            echo "
                ";
            // line 98
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaType6"]) ? $context["narusheniyaType6"] : $this->getContext($context, "narusheniyaType6")));
            foreach ($context['_seq'] as $context["_key"] => $context["narush"]) {
                // line 99
                echo "
                    ";
                // line 100
                if (($this->getAttribute($context["narush"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 101
                    echo "                        <td class=\"pokazatel1\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["narush"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 102
                    $context["flag6"] = "1";
                    // line 103
                    echo "                    ";
                }
                // line 104
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['narush'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 106
            echo "
                ";
            // line 107
            if (((isset($context["flag6"]) ? $context["flag6"] : $this->getContext($context, "flag6")) == "0")) {
                // line 108
                echo "                    <td></td>
                ";
            }
            // line 110
            echo "                ";
            $context["flag6"] = "0";
            // line 111
            echo "
                <td></td>
            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 115
        echo "        </tbody>
        <tfoot>
        <tr>
            <td>Всего</td>
            <td id=\"result1\"></td>
            <td id=\"result2\"></td>
            <td id=\"result3\"></td>
            <td id=\"result4\"></td>
            <td id=\"result5\"></td>
            <td id=\"result6\"></td>
            <td id=\"vsego\"></td>
        </tr>
        </tfoot>
    </table>
</div>";
        
        $__internal_13855fbcd691f6e2b72a565b8c1cb42642f4805e706d2cd15a52149290cc56a2->leave($__internal_13855fbcd691f6e2b72a565b8c1cb42642f4805e706d2cd15a52149290cc56a2_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:proverka_nakazanie_type.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  347 => 115,  330 => 111,  327 => 110,  323 => 108,  321 => 107,  318 => 106,  311 => 104,  308 => 103,  306 => 102,  301 => 101,  299 => 100,  296 => 99,  292 => 98,  289 => 97,  286 => 96,  282 => 94,  280 => 93,  277 => 92,  270 => 90,  267 => 89,  265 => 88,  260 => 87,  258 => 86,  255 => 85,  251 => 84,  248 => 83,  245 => 82,  241 => 80,  239 => 79,  236 => 78,  229 => 76,  226 => 75,  224 => 74,  219 => 73,  217 => 72,  214 => 71,  210 => 70,  207 => 69,  204 => 68,  200 => 66,  198 => 65,  195 => 64,  188 => 62,  185 => 61,  183 => 60,  178 => 59,  176 => 58,  173 => 57,  169 => 56,  166 => 55,  163 => 54,  159 => 52,  157 => 51,  154 => 50,  147 => 48,  144 => 47,  142 => 46,  137 => 45,  135 => 44,  132 => 43,  128 => 42,  125 => 41,  122 => 40,  118 => 38,  116 => 37,  113 => 36,  106 => 34,  103 => 33,  101 => 32,  96 => 31,  94 => 30,  91 => 29,  87 => 28,  82 => 26,  77 => 25,  60 => 24,  57 => 23,  54 => 22,  51 => 21,  48 => 20,  45 => 19,  42 => 18,  40 => 17,  22 => 1,);
    }
}
/* <div class="row">*/
/*     <table class="table table-hover table-bordered numbers">*/
/*         <thead>*/
/*         <tr>*/
/*             <td></td>*/
/*             <td style="font-size:12px">Неполное служебное</td>*/
/*             <td style="font-size:12px">Строгий выговор</td>*/
/*             <td style="font-size:12px">Выговор</td>*/
/*             <td style="font-size:12px">Замечание</td>*/
/*             <td style="font-size:12px">Ораничиться ранее</td>*/
/*             <td style="font-size:12px">Строго предупредить</td>*/
/*             <td style="font-size:12px">Итог</td>*/
/*         </tr>*/
/*         </thead>*/
/*         <tbody>*/
/* */
/*         {% set flag1= "0" %}*/
/*         {% set flag2 = "0" %}*/
/*         {% set flag3 = "0" %}*/
/*         {% set flag4 = "0" %}*/
/*         {% set flag5 = "0" %}*/
/*         {% set flag6 = "0" %}*/
/* */
/*         {% for organization in organizations %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{ organization.nameShort|slice(3,7) }}</td>*/
/* */
/*                 {% for narush in narusheniyaType1 %}*/
/* */
/*                     {% if narush.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel1">{{ narush.1 }}</td>*/
/*                         {% set flag1 = "1" %}*/
/*                     {% endif %}*/
/* */
/*                 {% endfor %}*/
/* */
/*                 {% if flag1 == "0" %}*/
/*                     <td></td>*/
/*                 {% endif %}*/
/*                 {% set flag1 = "0" %}*/
/* */
/*                 {% for narush in narusheniyaType2 %}*/
/* */
/*                     {% if narush.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel2">{{ narush.1 }}</td>*/
/*                         {% set flag2 = "1" %}*/
/*                     {% endif %}*/
/* */
/*                 {% endfor %}*/
/* */
/*                 {% if flag2 == "0" %}*/
/*                     <td></td>*/
/*                 {% endif %}*/
/*                 {% set flag2 = "0" %}*/
/* */
/*                 {% for narush in narusheniyaType3 %}*/
/* */
/*                     {% if narush.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel3">{{ narush.1 }}</td>*/
/*                         {% set flag3 = "1" %}*/
/*                     {% endif %}*/
/* */
/*                 {% endfor %}*/
/* */
/*                 {% if flag3 == "0" %}*/
/*                     <td></td>*/
/*                 {% endif %}*/
/*                 {% set flag3 = "0" %}*/
/* */
/*                 {% for narush in narusheniyaType4 %}*/
/* */
/*                     {% if narush.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel1">{{ narush.1 }}</td>*/
/*                         {% set flag4 = "1" %}*/
/*                     {% endif %}*/
/* */
/*                 {% endfor %}*/
/* */
/*                 {% if flag4 == "0" %}*/
/*                     <td></td>*/
/*                 {% endif %}*/
/*                 {% set flag4 = "0" %}*/
/* */
/*                 {% for narush in narusheniyaType5 %}*/
/* */
/*                     {% if narush.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel1">{{ narush.1 }}</td>*/
/*                         {% set flag5 = "1" %}*/
/*                     {% endif %}*/
/* */
/*                 {% endfor %}*/
/* */
/*                 {% if flag5 == "0" %}*/
/*                     <td></td>*/
/*                 {% endif %}*/
/*                 {% set flag5 = "0" %}*/
/* */
/*                 {% for narush in narusheniyaType6 %}*/
/* */
/*                     {% if narush.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel1">{{ narush.1 }}</td>*/
/*                         {% set flag6 = "1" %}*/
/*                     {% endif %}*/
/* */
/*                 {% endfor %}*/
/* */
/*                 {% if flag6 == "0" %}*/
/*                     <td></td>*/
/*                 {% endif %}*/
/*                 {% set flag6 = "0" %}*/
/* */
/*                 <td></td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*         <tr>*/
/*             <td>Всего</td>*/
/*             <td id="result1"></td>*/
/*             <td id="result2"></td>*/
/*             <td id="result3"></td>*/
/*             <td id="result4"></td>*/
/*             <td id="result5"></td>*/
/*             <td id="result6"></td>*/
/*             <td id="vsego"></td>*/
/*         </tr>*/
/*         </tfoot>*/
/*     </table>*/
/* </div>*/
