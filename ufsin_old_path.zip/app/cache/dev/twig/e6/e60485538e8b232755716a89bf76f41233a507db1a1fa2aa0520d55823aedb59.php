<?php

/* :zabolevaniya:showLichnyiSostavs.html.twig */
class __TwigTemplate_30061b5d48287c7b8bcb26973f9627db66786eadb47322f60ae85e92b58634be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":zabolevaniya:showLichnyiSostavs.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63a7eafa1333931d55801178f5ca3f9c3cd163084229e03ca8b3304c07e63976 = $this->env->getExtension("native_profiler");
        $__internal_63a7eafa1333931d55801178f5ca3f9c3cd163084229e03ca8b3304c07e63976->enter($__internal_63a7eafa1333931d55801178f5ca3f9c3cd163084229e03ca8b3304c07e63976_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":zabolevaniya:showLichnyiSostavs.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_63a7eafa1333931d55801178f5ca3f9c3cd163084229e03ca8b3304c07e63976->leave($__internal_63a7eafa1333931d55801178f5ca3f9c3cd163084229e03ca8b3304c07e63976_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_0d5c3e6e6fe65dfd74e564867fdf399f60e304d958537d7bd6b29004f640fc94 = $this->env->getExtension("native_profiler");
        $__internal_0d5c3e6e6fe65dfd74e564867fdf399f60e304d958537d7bd6b29004f640fc94->enter($__internal_0d5c3e6e6fe65dfd74e564867fdf399f60e304d958537d7bd6b29004f640fc94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">
    <h1>Выберите заболевшего личного состава:</h1>
</div>

<div class=\"row\" style=\"margin-bottom:50px\">
    <form class=\"has-validation-callback\" method=\"post\" action=\"/zabolevaniya/showLichnyiSostavs\" >
        <div class=\"col-md-3\">
            <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
            <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
        </div><div class=\"col-md-3\">
            <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
            <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
        </div>
        <div class=\"col-md-3\" style=\"margin-top:25px\">
            <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
        </div>
        <div class=\"col-md-3\" style=\"margin-top:45px\">
            <a href=\"/zabolevaniya/createZabolevanieLichnyi\" style=\"font-size:18px\">Добавить нового заболевшего</a>
        </div>    
    </form>    
</div>

<div class=\"row\">
    <table class=\"table table-hover main table-bordered\">
        <thead>
            <tr>
                <td>ФИО</td>
                <td>Дата рождения</td>
                <td><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></td>
                <td><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></td>
            </tr>
        </thead>
        <tbody>
        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lichnyiSostavs"]) ? $context["lichnyiSostavs"] : $this->getContext($context, "lichnyiSostavs")));
        foreach ($context['_seq'] as $context["_key"] => $context["lichnyiSostav"]) {
            // line 39
            echo "            <tr>
                <td><a href=\"/zabolevaniya/lichnyi/";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "fio", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "date_birthday", array()), "d.m.Y"), "html", null, true);
            echo "</td>
                <td><a href=\"/zabolevaniya/editLichnyiSostav/";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "id", array()), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></a></td>
\t\t\t\t<td><a href=\"/zabolevaniya/deleteLichnyiSostav/";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "id", array()), "html", null, true);
            echo "\" class=\"delete_entity\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></a></td>
            </tr> 
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['lichnyiSostav'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "        </tbody>
    </table>
</div>

";
        
        $__internal_0d5c3e6e6fe65dfd74e564867fdf399f60e304d958537d7bd6b29004f640fc94->leave($__internal_0d5c3e6e6fe65dfd74e564867fdf399f60e304d958537d7bd6b29004f640fc94_prof);

    }

    // line 52
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_4a8602911b18dd2e4d1c373572b2cb2e655211dda068f1fe6d2513a5c8579ffc = $this->env->getExtension("native_profiler");
        $__internal_4a8602911b18dd2e4d1c373572b2cb2e655211dda068f1fe6d2513a5c8579ffc->enter($__internal_4a8602911b18dd2e4d1c373572b2cb2e655211dda068f1fe6d2513a5c8579ffc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 53
        echo "
";
        
        $__internal_4a8602911b18dd2e4d1c373572b2cb2e655211dda068f1fe6d2513a5c8579ffc->leave($__internal_4a8602911b18dd2e4d1c373572b2cb2e655211dda068f1fe6d2513a5c8579ffc_prof);

    }

    public function getTemplateName()
    {
        return ":zabolevaniya:showLichnyiSostavs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 53,  124 => 52,  113 => 46,  104 => 43,  100 => 42,  96 => 41,  90 => 40,  87 => 39,  83 => 38,  58 => 16,  52 => 13,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <h1>Выберите заболевшего личного состава:</h1>*/
/* </div>*/
/* */
/* <div class="row" style="margin-bottom:50px">*/
/*     <form class="has-validation-callback" method="post" action="/zabolevaniya/showLichnyiSostavs" >*/
/*         <div class="col-md-3">*/
/*             <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*             <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*         </div><div class="col-md-3">*/
/*             <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*             <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*         </div>*/
/*         <div class="col-md-3" style="margin-top:25px">*/
/*             <input type="submit" class="btn btn-success" value="Выбрать">*/
/*         </div>*/
/*         <div class="col-md-3" style="margin-top:45px">*/
/*             <a href="/zabolevaniya/createZabolevanieLichnyi" style="font-size:18px">Добавить нового заболевшего</a>*/
/*         </div>    */
/*     </form>    */
/* </div>*/
/* */
/* <div class="row">*/
/*     <table class="table table-hover main table-bordered">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td>ФИО</td>*/
/*                 <td>Дата рождения</td>*/
/*                 <td><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></td>*/
/*                 <td><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for lichnyiSostav in lichnyiSostavs %}*/
/*             <tr>*/
/*                 <td><a href="/zabolevaniya/lichnyi/{{ lichnyiSostav.id }}">{{ lichnyiSostav.fio }}</a></td>*/
/*                 <td>{{lichnyiSostav.date_birthday|date("d.m.Y") }}</td>*/
/*                 <td><a href="/zabolevaniya/editLichnyiSostav/{{ lichnyiSostav.id }}"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></td>*/
/* 				<td><a href="/zabolevaniya/deleteLichnyiSostav/{{ lichnyiSostav.id }}" class="delete_entity"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>*/
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
