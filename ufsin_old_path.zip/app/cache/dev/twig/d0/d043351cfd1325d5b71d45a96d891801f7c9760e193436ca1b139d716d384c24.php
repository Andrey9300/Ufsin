<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_d782314549524f26975c6e3b28508098db77f951653f3eaad7801413f88986df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9aeb5d4a9502a2a2fd9e7c0f35ebb0c2c4b02b2c0dd420963367eb59a23b63c = $this->env->getExtension("native_profiler");
        $__internal_c9aeb5d4a9502a2a2fd9e7c0f35ebb0c2c4b02b2c0dd420963367eb59a23b63c->enter($__internal_c9aeb5d4a9502a2a2fd9e7c0f35ebb0c2c4b02b2c0dd420963367eb59a23b63c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_c9aeb5d4a9502a2a2fd9e7c0f35ebb0c2c4b02b2c0dd420963367eb59a23b63c->leave($__internal_c9aeb5d4a9502a2a2fd9e7c0f35ebb0c2c4b02b2c0dd420963367eb59a23b63c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
