<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_07495cff9a87f8261cf240d044c3bd28b7ca91c074a9f9d3f82d67051628dc39 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fa59c70da4bf301345c7be5615a680aedd4c60033755394bcfff5840595f061 = $this->env->getExtension("native_profiler");
        $__internal_9fa59c70da4bf301345c7be5615a680aedd4c60033755394bcfff5840595f061->enter($__internal_9fa59c70da4bf301345c7be5615a680aedd4c60033755394bcfff5840595f061_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_9fa59c70da4bf301345c7be5615a680aedd4c60033755394bcfff5840595f061->leave($__internal_9fa59c70da4bf301345c7be5615a680aedd4c60033755394bcfff5840595f061_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
