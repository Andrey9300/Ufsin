<?php

/* otchet/ajax/issledovanie_type_fkuz.html.twig */
class __TwigTemplate_4c725c1275ef7b417e28c3bc6140bd5c3391efd0cbb0835d2dd315b935cd4d0f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "otchet/ajax/issledovanie_type_fkuz.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b1dfa8e5181f5f15428d6341ea971c804e72abfe730a9c14e7277736d292e0a = $this->env->getExtension("native_profiler");
        $__internal_5b1dfa8e5181f5f15428d6341ea971c804e72abfe730a9c14e7277736d292e0a->enter($__internal_5b1dfa8e5181f5f15428d6341ea971c804e72abfe730a9c14e7277736d292e0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/ajax/issledovanie_type_fkuz.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5b1dfa8e5181f5f15428d6341ea971c804e72abfe730a9c14e7277736d292e0a->leave($__internal_5b1dfa8e5181f5f15428d6341ea971c804e72abfe730a9c14e7277736d292e0a_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_54e55d354dad073dc3ed34cbc7c9b87549224edf9ca746ad8ae41a1d061bc1a6 = $this->env->getExtension("native_profiler");
        $__internal_54e55d354dad073dc3ed34cbc7c9b87549224edf9ca746ad8ae41a1d061bc1a6->enter($__internal_54e55d354dad073dc3ed34cbc7c9b87549224edf9ca746ad8ae41a1d061bc1a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">
    <h3>Общая статистика исследований</h3>

    ";
        // line 8
        if (twig_test_empty((isset($context["fkuzs"]) ? $context["fkuzs"] : $this->getContext($context, "fkuzs")))) {
            // line 9
            echo "        <p>Не добавлены филиалы</p>
    ";
        } elseif (twig_test_empty(        // line 10
(isset($context["issledovanieTypes"]) ? $context["issledovanieTypes"] : $this->getContext($context, "issledovanieTypes")))) {
            // line 11
            echo "        <p>Не добавлены типы исследований</p>
    ";
        } elseif (twig_test_empty(        // line 12
(isset($context["commonAll"]) ? $context["commonAll"] : $this->getContext($context, "commonAll")))) {
            // line 13
            echo "        <p>Не добавлены исследования в учреждениях</p>
    ";
        } else {
            // line 15
            echo "
        <div class=\"row\" style=\"margin-bottom:50px\">
            <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetFkuz/type\" >
                <div class=\"col-md-3\">
                    <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                    <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
            // line 20
            echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
            echo "\">
                </div><div class=\"col-md-3\">
                    <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                    <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
            // line 23
            echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
            echo "\">
                </div>
                <div class=\"col-md-3\" style=\"margin-top:25px\">
                    <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
                </div>
            </form>
        </div>

        <table class=\"table table-hover table-bordered numbers\" id=\"common_proverka\">
            <thead>
            <tr>
                <td></td>
                ";
            // line 35
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fkuzs"]) ? $context["fkuzs"] : $this->getContext($context, "fkuzs")));
            foreach ($context['_seq'] as $context["_key"] => $context["fkuz"]) {
                // line 36
                echo "                    <td>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["fkuz"], "nameShort", array()), "html", null, true);
                echo "</td>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fkuz'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                <td id=\"issledovaniya\">Итого</td>
            </tr>
            </thead>
            <tbody>

            ";
            // line 43
            $context["flag"] = "0";
            // line 44
            echo "
            ";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["issledovanieTypes"]) ? $context["issledovanieTypes"] : $this->getContext($context, "issledovanieTypes")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                // line 46
                echo "                <tr class=\"pokazatels";
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "\">
                    <td class=\"name\">";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute($context["type"], "name", array()), "html", null, true);
                echo "</td>

                    ";
                // line 49
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["fkuzs"]) ? $context["fkuzs"] : $this->getContext($context, "fkuzs")));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["fkuz"]) {
                    // line 50
                    echo "
                        ";
                    // line 51
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["commonAll"]) ? $context["commonAll"] : $this->getContext($context, "commonAll")));
                    $context['loop'] = array(
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    );
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["quantity"] => $context["key"]) {
                        // line 52
                        echo "
                            ";
                        // line 53
                        if (($this->getAttribute($context["key"], "name_full", array(), "array") == $this->getAttribute($context["fkuz"], "nameFull", array()))) {
                            // line 54
                            echo "
                                ";
                            // line 55
                            if (($this->getAttribute($context["key"], "name", array(), "array") == $this->getAttribute($context["type"], "name", array()))) {
                                // line 56
                                echo "
                                    <td class=\"pokazatel";
                                // line 57
                                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                                echo "\">
                                        <span>";
                                // line 58
                                echo twig_escape_filter($this->env, $this->getAttribute($context["key"], 1, array(), "array"), "html", null, true);
                                echo "</span>(";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["key"], 2, array(), "array"), "html", null, true);
                                echo ")
                                    </td>
                                    ";
                                // line 60
                                $context["flag"] = "1";
                                // line 61
                                echo "                                ";
                            }
                            // line 62
                            echo "
                            ";
                        }
                        // line 64
                        echo "
                        ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['quantity'], $context['key'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 66
                    echo "
                        ";
                    // line 67
                    if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                        // line 68
                        echo "                            <td></td>
                        ";
                    }
                    // line 70
                    echo "                        ";
                    $context["flag"] = "0";
                    // line 71
                    echo "                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fkuz'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 72
                echo "                    <td></td>
                </tr>
            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 75
            echo "            </tbody>
            <tfoot>
            <tr>
                <td>Всего</td>
                ";
            // line 79
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fkuzs"]) ? $context["fkuzs"] : $this->getContext($context, "fkuzs")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["fkuz"]) {
                // line 80
                echo "                    <td id=\"result";
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "\"></td>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fkuz'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 82
            echo "                <td id=\"vsego\"></td>
            </tr>
            <tr>
                <td></td>
                ";
            // line 86
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fkuzs"]) ? $context["fkuzs"] : $this->getContext($context, "fkuzs")));
            foreach ($context['_seq'] as $context["_key"] => $context["fkuz"]) {
                // line 87
                echo "                    <td>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["fkuz"], "nameShort", array()), "html", null, true);
                echo "</td>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fkuz'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 89
            echo "                <td></td>
            </tr>
            </tfoot>
        </table>
    ";
        }
        // line 94
        echo "</div>
";
        
        $__internal_54e55d354dad073dc3ed34cbc7c9b87549224edf9ca746ad8ae41a1d061bc1a6->leave($__internal_54e55d354dad073dc3ed34cbc7c9b87549224edf9ca746ad8ae41a1d061bc1a6_prof);

    }

    // line 97
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_d175e0f369a027ec32f4d82f5fd52a6c59f406dd561a77ddb52e24e6be44fea4 = $this->env->getExtension("native_profiler");
        $__internal_d175e0f369a027ec32f4d82f5fd52a6c59f406dd561a77ddb52e24e6be44fea4->enter($__internal_d175e0f369a027ec32f4d82f5fd52a6c59f406dd561a77ddb52e24e6be44fea4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 98
        echo "
";
        
        $__internal_d175e0f369a027ec32f4d82f5fd52a6c59f406dd561a77ddb52e24e6be44fea4->leave($__internal_d175e0f369a027ec32f4d82f5fd52a6c59f406dd561a77ddb52e24e6be44fea4_prof);

    }

    public function getTemplateName()
    {
        return "otchet/ajax/issledovanie_type_fkuz.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  350 => 98,  344 => 97,  336 => 94,  329 => 89,  320 => 87,  316 => 86,  310 => 82,  293 => 80,  276 => 79,  270 => 75,  254 => 72,  240 => 71,  237 => 70,  233 => 68,  231 => 67,  228 => 66,  213 => 64,  209 => 62,  206 => 61,  204 => 60,  197 => 58,  193 => 57,  190 => 56,  188 => 55,  185 => 54,  183 => 53,  180 => 52,  163 => 51,  160 => 50,  143 => 49,  138 => 47,  133 => 46,  116 => 45,  113 => 44,  111 => 43,  104 => 38,  95 => 36,  91 => 35,  76 => 23,  70 => 20,  63 => 15,  59 => 13,  57 => 12,  54 => 11,  52 => 10,  49 => 9,  47 => 8,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <h3>Общая статистика исследований</h3>*/
/* */
/*     {% if fkuzs is empty%}*/
/*         <p>Не добавлены филиалы</p>*/
/*     {% elseif issledovanieTypes is empty%}*/
/*         <p>Не добавлены типы исследований</p>*/
/*     {% elseif commonAll is empty%}*/
/*         <p>Не добавлены исследования в учреждениях</p>*/
/*     {% else %}*/
/* */
/*         <div class="row" style="margin-bottom:50px">*/
/*             <form class="has-validation-callback" method="post" action="/otchetFkuz/type" >*/
/*                 <div class="col-md-3">*/
/*                     <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                     <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*                 </div><div class="col-md-3">*/
/*                     <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                     <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*                 </div>*/
/*                 <div class="col-md-3" style="margin-top:25px">*/
/*                     <input type="submit" class="btn btn-success" value="Выбрать">*/
/*                 </div>*/
/*             </form>*/
/*         </div>*/
/* */
/*         <table class="table table-hover table-bordered numbers" id="common_proverka">*/
/*             <thead>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 {% for fkuz in fkuzs %}*/
/*                     <td>{{fkuz.nameShort}}</td>*/
/*                 {% endfor %}*/
/*                 <td id="issledovaniya">Итого</td>*/
/*             </tr>*/
/*             </thead>*/
/*             <tbody>*/
/* */
/*             {% set flag = "0" %}*/
/* */
/*             {% for type in issledovanieTypes %}*/
/*                 <tr class="pokazatels{{loop.index}}">*/
/*                     <td class="name">{{type.name}}</td>*/
/* */
/*                     {% for fkuz in fkuzs %}*/
/* */
/*                         {% for quantity, key in commonAll %}*/
/* */
/*                             {% if key["name_full"] == fkuz.nameFull %}*/
/* */
/*                                 {% if key["name"] == type.name %}*/
/* */
/*                                     <td class="pokazatel{{loop.parent.loop.index}}">*/
/*                                         <span>{{ key[1] }}</span>({{ key[2] }})*/
/*                                     </td>*/
/*                                     {% set flag = "1" %}*/
/*                                 {% endif %}*/
/* */
/*                             {% endif %}*/
/* */
/*                         {% endfor %}*/
/* */
/*                         {% if flag == "0" %}*/
/*                             <td></td>*/
/*                         {% endif %}*/
/*                         {% set flag = "0" %}*/
/*                     {% endfor %}*/
/*                     <td></td>*/
/*                 </tr>*/
/*             {% endfor %}*/
/*             </tbody>*/
/*             <tfoot>*/
/*             <tr>*/
/*                 <td>Всего</td>*/
/*                 {% for fkuz in fkuzs %}*/
/*                     <td id="result{{loop.index}}"></td>*/
/*                 {% endfor %}*/
/*                 <td id="vsego"></td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 {% for fkuz in fkuzs %}*/
/*                     <td>{{fkuz.nameShort}}</td>*/
/*                 {% endfor %}*/
/*                 <td></td>*/
/*             </tr>*/
/*             </tfoot>*/
/*         </table>*/
/*     {% endif %}*/
/* </div>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
