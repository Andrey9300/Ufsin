<?php

/* base.html.twig */
class __TwigTemplate_156589c3f97c08c7689693ebd74ad071e552fbd097cd320f856dfd78cd0ae8d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2f5f04391fde4f5094ff331de06c6a2877046bfb52f6bf543197dbb39f263a7 = $this->env->getExtension("native_profiler");
        $__internal_a2f5f04391fde4f5094ff331de06c6a2877046bfb52f6bf543197dbb39f263a7->enter($__internal_a2f5f04391fde4f5094ff331de06c6a2877046bfb52f6bf543197dbb39f263a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>

    <body id=\"";
        // line 14
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

        ";
        // line 16
        $this->displayBlock('header', $context, $blocks);
        // line 91
        echo "
        <div class=\"container body-container\">
            ";
        // line 93
        $this->displayBlock('body', $context, $blocks);
        // line 104
        echo "        </div>

        ";
        // line 106
        $this->displayBlock('footer', $context, $blocks);
        // line 116
        echo "
        ";
        // line 117
        $this->displayBlock('javascripts', $context, $blocks);
        // line 123
        echo "    </body>
</html>
";
        
        $__internal_a2f5f04391fde4f5094ff331de06c6a2877046bfb52f6bf543197dbb39f263a7->leave($__internal_a2f5f04391fde4f5094ff331de06c6a2877046bfb52f6bf543197dbb39f263a7_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_778c752dfcfd2e478f6ca03590276981556c7750c3bb1c27b2f09fded7e01774 = $this->env->getExtension("native_profiler");
        $__internal_778c752dfcfd2e478f6ca03590276981556c7750c3bb1c27b2f09fded7e01774->enter($__internal_778c752dfcfd2e478f6ca03590276981556c7750c3bb1c27b2f09fded7e01774_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Application";
        
        $__internal_778c752dfcfd2e478f6ca03590276981556c7750c3bb1c27b2f09fded7e01774->leave($__internal_778c752dfcfd2e478f6ca03590276981556c7750c3bb1c27b2f09fded7e01774_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ae8cf88dbe431d2b44f3e1fb4a4da5f8cebe7ecf8cc45724dc753c322050c274 = $this->env->getExtension("native_profiler");
        $__internal_ae8cf88dbe431d2b44f3e1fb4a4da5f8cebe7ecf8cc45724dc753c322050c274->enter($__internal_ae8cf88dbe431d2b44f3e1fb4a4da5f8cebe7ecf8cc45724dc753c322050c274_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/app.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_ae8cf88dbe431d2b44f3e1fb4a4da5f8cebe7ecf8cc45724dc753c322050c274->leave($__internal_ae8cf88dbe431d2b44f3e1fb4a4da5f8cebe7ecf8cc45724dc753c322050c274_prof);

    }

    // line 14
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_257c30738e56c9938efeabcbf6c00cd8877369c77d934beb57c3df4a4a164b1a = $this->env->getExtension("native_profiler");
        $__internal_257c30738e56c9938efeabcbf6c00cd8877369c77d934beb57c3df4a4a164b1a->enter($__internal_257c30738e56c9938efeabcbf6c00cd8877369c77d934beb57c3df4a4a164b1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_257c30738e56c9938efeabcbf6c00cd8877369c77d934beb57c3df4a4a164b1a->leave($__internal_257c30738e56c9938efeabcbf6c00cd8877369c77d934beb57c3df4a4a164b1a_prof);

    }

    // line 16
    public function block_header($context, array $blocks = array())
    {
        $__internal_95de392a50fc1ef1e76c622037b9a5e85886b6500a76a301dc4cfdef6b718665 = $this->env->getExtension("native_profiler");
        $__internal_95de392a50fc1ef1e76c622037b9a5e85886b6500a76a301dc4cfdef6b718665->enter($__internal_95de392a50fc1ef1e76c622037b9a5e85886b6500a76a301dc4cfdef6b718665_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 17
        echo "            <header>
                <nav class=\"navbar navbar-default\">
                    <div class=\"container-fluid\">
                        <div class=\"navbar-header\">
                            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                                <span class=\"sr-only\">Toggle navigation</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>

                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav\">
                                ";
        // line 31
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            echo "              
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Учреждения<span class=\"caret\"></span></a>

                                     ";
            // line 35
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Organization:allOrganizations"));
            echo "

                                </li>
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Заболеваемость TBS<span class=\"caret\"></span></a>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"/zabolevaniya/showLichnyiSostavs\">Личный состав</a></li>
                                        <li><a href=\"/zabolevaniya/showOsugdenyis\">Осужденные</a></li>
                                        <li><a href=\"/zabolevaniya/showOchags\">Очаг</a></li>
                                    </ul>
                                </li> 
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">ФКУЗ<span class=\"caret\"></span></a>
                                     
                                     ";
            // line 49
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Fkuz:allNameFilial"));
            echo "
                                     
                                </li>
                                <li>
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Отчеты<span class=\"caret\"></span></a>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"/otchetDogovor/common\">По договорам</a></li>
                                        <li><a href=\"/otchetProverka/\">По проверкам</a></li>
                                        <li><a href=\"/otchetIssledovaniya/\">По исследованиям</a></li>
                                        <li><a href=\"/otchetZabolevaniya/\">По заболевшим</a></li>
                                        <li><a href=\"/otchetFkuz/\">По ФКУЗ/Филиалу</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Добавить<span class=\"caret\"></span></a>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"";
            // line 65
            echo $this->env->getExtension('routing')->getPath("organization_new");
            echo "\">Учреждение</a></li>
                                        <li><a href=\"/fkuz/createFkuz\">ФКУЗ / Филиал</a></li>
                                        <li><a href=\"/issledovanie/createType\">Тип исследования</a></li>
                                        <li><a href=\"/dogovor/createType\">Тип договора</a></li>                       
                                        <li><a href=\"/organization/createObject\">Объект</a></li>
                                        
                                    </ul>
                                </li>                                
                                ";
        }
        // line 73
        echo "                                
                            </ul>
                            <ul class=\"nav navbar-nav navbar-right\">
                                
                                ";
        // line 77
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 78
            echo "                                    <li>
                                        <a href=\"";
            // line 79
            echo $this->env->getExtension('routing')->getPath("security_logout");
            echo "\">
                                            <i class=\"fa fa-sign-out\"></i>Выход
                                        </a>
                                    </li>
                                ";
        }
        // line 84
        echo "
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
        ";
        
        $__internal_95de392a50fc1ef1e76c622037b9a5e85886b6500a76a301dc4cfdef6b718665->leave($__internal_95de392a50fc1ef1e76c622037b9a5e85886b6500a76a301dc4cfdef6b718665_prof);

    }

    // line 93
    public function block_body($context, array $blocks = array())
    {
        $__internal_95d2a8272cc1449bab3ef12d730e3b615fc6d70025a81c7bac01e764b16c2f0a = $this->env->getExtension("native_profiler");
        $__internal_95d2a8272cc1449bab3ef12d730e3b615fc6d70025a81c7bac01e764b16c2f0a->enter($__internal_95d2a8272cc1449bab3ef12d730e3b615fc6d70025a81c7bac01e764b16c2f0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 94
        echo "
                    ";
        // line 95
        $this->displayBlock('main', $context, $blocks);
        // line 98
        echo "
                    ";
        // line 99
        $this->displayBlock('sidebar', $context, $blocks);
        // line 102
        echo "
            ";
        
        $__internal_95d2a8272cc1449bab3ef12d730e3b615fc6d70025a81c7bac01e764b16c2f0a->leave($__internal_95d2a8272cc1449bab3ef12d730e3b615fc6d70025a81c7bac01e764b16c2f0a_prof);

    }

    // line 95
    public function block_main($context, array $blocks = array())
    {
        $__internal_361a6843a8243cf557837f30348cb8e78094a3f59799c1ab249d48c05aee31d8 = $this->env->getExtension("native_profiler");
        $__internal_361a6843a8243cf557837f30348cb8e78094a3f59799c1ab249d48c05aee31d8->enter($__internal_361a6843a8243cf557837f30348cb8e78094a3f59799c1ab249d48c05aee31d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 96
        echo "                        
                    ";
        
        $__internal_361a6843a8243cf557837f30348cb8e78094a3f59799c1ab249d48c05aee31d8->leave($__internal_361a6843a8243cf557837f30348cb8e78094a3f59799c1ab249d48c05aee31d8_prof);

    }

    // line 99
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_f5564ecdfabc6b39bc8d5e0c3cad24024cdcd14fb84e2d080f85ef62d627630e = $this->env->getExtension("native_profiler");
        $__internal_f5564ecdfabc6b39bc8d5e0c3cad24024cdcd14fb84e2d080f85ef62d627630e->enter($__internal_f5564ecdfabc6b39bc8d5e0c3cad24024cdcd14fb84e2d080f85ef62d627630e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 100
        echo "
                    ";
        
        $__internal_f5564ecdfabc6b39bc8d5e0c3cad24024cdcd14fb84e2d080f85ef62d627630e->leave($__internal_f5564ecdfabc6b39bc8d5e0c3cad24024cdcd14fb84e2d080f85ef62d627630e_prof);

    }

    // line 106
    public function block_footer($context, array $blocks = array())
    {
        $__internal_8015b8605bf3a3ab65bcae565cf5059127fe95064597cb0b2385b09370ad6f89 = $this->env->getExtension("native_profiler");
        $__internal_8015b8605bf3a3ab65bcae565cf5059127fe95064597cb0b2385b09370ad6f89->enter($__internal_8015b8605bf3a3ab65bcae565cf5059127fe95064597cb0b2385b09370ad6f89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 107
        echo "            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\"></div>
                        <div id=\"footer-resources\" class=\"col-md-6\"></div>
                    </div>
                </div>
            </footer>
        ";
        
        $__internal_8015b8605bf3a3ab65bcae565cf5059127fe95064597cb0b2385b09370ad6f89->leave($__internal_8015b8605bf3a3ab65bcae565cf5059127fe95064597cb0b2385b09370ad6f89_prof);

    }

    // line 117
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5c79ec59a60cff4a59453373b57a75b6c27080a5cbcd11d610ced42a0719fd74 = $this->env->getExtension("native_profiler");
        $__internal_5c79ec59a60cff4a59453373b57a75b6c27080a5cbcd11d610ced42a0719fd74->enter($__internal_5c79ec59a60cff4a59453373b57a75b6c27080a5cbcd11d610ced42a0719fd74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 118
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/app.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/script.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/jquery.form-validator.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/date.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_5c79ec59a60cff4a59453373b57a75b6c27080a5cbcd11d610ced42a0719fd74->leave($__internal_5c79ec59a60cff4a59453373b57a75b6c27080a5cbcd11d610ced42a0719fd74_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  328 => 121,  324 => 120,  320 => 119,  315 => 118,  309 => 117,  294 => 107,  288 => 106,  280 => 100,  274 => 99,  266 => 96,  260 => 95,  252 => 102,  250 => 99,  247 => 98,  245 => 95,  242 => 94,  236 => 93,  223 => 84,  215 => 79,  212 => 78,  210 => 77,  204 => 73,  192 => 65,  173 => 49,  156 => 35,  149 => 31,  133 => 17,  127 => 16,  116 => 14,  107 => 9,  102 => 8,  96 => 7,  84 => 5,  75 => 123,  73 => 117,  70 => 116,  68 => 106,  64 => 104,  62 => 93,  58 => 91,  56 => 16,  51 => 14,  44 => 11,  42 => 7,  37 => 5,  31 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Application{% endblock %}</title>*/
/* */
/*         {% block stylesheets %}*/
/*             <link rel="stylesheet" href="{{ asset('css/app.css') }}">*/
/*             <link rel="stylesheet" href="{{ asset('css/style.css') }}">*/
/*         {% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/* */
/*     <body id="{% block body_id %}{% endblock %}">*/
/* */
/*         {% block header %}*/
/*             <header>*/
/*                 <nav class="navbar navbar-default">*/
/*                     <div class="container-fluid">*/
/*                         <div class="navbar-header">*/
/*                             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">*/
/*                                 <span class="sr-only">Toggle navigation</span>*/
/*                                 <span class="icon-bar"></span>*/
/*                                 <span class="icon-bar"></span>*/
/*                                 <span class="icon-bar"></span>*/
/*                             </button>*/
/*                         </div>*/
/* */
/*                         <div class="navbar-collapse collapse">*/
/*                             <ul class="nav navbar-nav">*/
/*                                 {% if app.user %}              */
/*                                 <li class="dropdown">*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Учреждения<span class="caret"></span></a>*/
/* */
/*                                      {{ render(controller('AppBundle:Organization:allOrganizations')) }}*/
/* */
/*                                 </li>*/
/*                                 <li class="dropdown">*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Заболеваемость TBS<span class="caret"></span></a>*/
/*                                     <ul class="dropdown-menu">*/
/*                                         <li><a href="/zabolevaniya/showLichnyiSostavs">Личный состав</a></li>*/
/*                                         <li><a href="/zabolevaniya/showOsugdenyis">Осужденные</a></li>*/
/*                                         <li><a href="/zabolevaniya/showOchags">Очаг</a></li>*/
/*                                     </ul>*/
/*                                 </li> */
/*                                 <li class="dropdown">*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">ФКУЗ<span class="caret"></span></a>*/
/*                                      */
/*                                      {{ render(controller('AppBundle:Fkuz:allNameFilial')) }}*/
/*                                      */
/*                                 </li>*/
/*                                 <li>*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Отчеты<span class="caret"></span></a>*/
/*                                     <ul class="dropdown-menu">*/
/*                                         <li><a href="/otchetDogovor/common">По договорам</a></li>*/
/*                                         <li><a href="/otchetProverka/">По проверкам</a></li>*/
/*                                         <li><a href="/otchetIssledovaniya/">По исследованиям</a></li>*/
/*                                         <li><a href="/otchetZabolevaniya/">По заболевшим</a></li>*/
/*                                         <li><a href="/otchetFkuz/">По ФКУЗ/Филиалу</a></li>*/
/*                                     </ul>*/
/*                                 </li>*/
/*                                 <li>*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Добавить<span class="caret"></span></a>*/
/*                                     <ul class="dropdown-menu">*/
/*                                         <li><a href="{{ path('organization_new') }}">Учреждение</a></li>*/
/*                                         <li><a href="/fkuz/createFkuz">ФКУЗ / Филиал</a></li>*/
/*                                         <li><a href="/issledovanie/createType">Тип исследования</a></li>*/
/*                                         <li><a href="/dogovor/createType">Тип договора</a></li>                       */
/*                                         <li><a href="/organization/createObject">Объект</a></li>*/
/*                                         */
/*                                     </ul>*/
/*                                 </li>                                */
/*                                 {% endif %}                                */
/*                             </ul>*/
/*                             <ul class="nav navbar-nav navbar-right">*/
/*                                 */
/*                                 {% if app.user %}*/
/*                                     <li>*/
/*                                         <a href="{{ path('security_logout') }}">*/
/*                                             <i class="fa fa-sign-out"></i>Выход*/
/*                                         </a>*/
/*                                     </li>*/
/*                                 {% endif %}*/
/* */
/*                             </ul>*/
/*                         </div>*/
/*                     </div>*/
/*                 </nav>*/
/*             </header>*/
/*         {% endblock %}*/
/* */
/*         <div class="container body-container">*/
/*             {% block body %}*/
/* */
/*                     {% block main %}*/
/*                         */
/*                     {% endblock %}*/
/* */
/*                     {% block sidebar %}*/
/* */
/*                     {% endblock %}*/
/* */
/*             {% endblock %}*/
/*         </div>*/
/* */
/*         {% block footer %}*/
/*             <footer>*/
/*                 <div class="container">*/
/*                     <div class="row">*/
/*                         <div id="footer-copyright" class="col-md-6"></div>*/
/*                         <div id="footer-resources" class="col-md-6"></div>*/
/*                     </div>*/
/*                 </div>*/
/*             </footer>*/
/*         {% endblock %}*/
/* */
/*         {% block javascripts %}*/
/*             <script src="{{ asset('js/app.js') }}"></script>*/
/*             <script src="{{ asset('js/script.js') }}"></script>*/
/*             <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>*/
/*             <script src="{{ asset('js/date.js') }}"></script>*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
