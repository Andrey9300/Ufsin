<?php

/* fkuz/editLicense.html.twig */
class __TwigTemplate_f263a0c37d52e056c442770e076c938b05dd1518daf5025c6dd9f9251d321df3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "fkuz/editLicense.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0492a06afaf88acc3ec0fd1731fd074a1cc1b59b8cb164df980e4d9526cb50d4 = $this->env->getExtension("native_profiler");
        $__internal_0492a06afaf88acc3ec0fd1731fd074a1cc1b59b8cb164df980e4d9526cb50d4->enter($__internal_0492a06afaf88acc3ec0fd1731fd074a1cc1b59b8cb164df980e4d9526cb50d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "fkuz/editLicense.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0492a06afaf88acc3ec0fd1731fd074a1cc1b59b8cb164df980e4d9526cb50d4->leave($__internal_0492a06afaf88acc3ec0fd1731fd074a1cc1b59b8cb164df980e4d9526cb50d4_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_196ac60ef66d11e5138d5688d67d5f9f7b71023fa15092656856cb4dfa718f1a = $this->env->getExtension("native_profiler");
        $__internal_196ac60ef66d11e5138d5688d67d5f9f7b71023fa15092656856cb4dfa718f1a->enter($__internal_196ac60ef66d11e5138d5688d67d5f9f7b71023fa15092656856cb4dfa718f1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<h1>Изменить лицензию</h1>

";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

<div class=\"row\">
    <div class=\"col-md-4\">
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nomer", array()), 'label', array("label" => "Номер"));
        echo "
        ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nomer", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "
        ";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date", array()), 'label', array("label" => "Дата"));
        echo "
        ";
        // line 14
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date", array()), 'widget', array("attr" => array("class" => "form-control", "data-validation" => "date", "data-validation-optional" => "true", "data-validation-format" => "dd.mm.yyyy")));
        echo "  
        ";
        // line 15
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vidDeytelnosti", array()), 'label', array("label" => "Вид деятельности"));
        echo "
        ";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vidDeytelnosti", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "\t\t
    </div>
</div>

<div class=\"row\">
    <div class=\"col-md-4\">
        <input type=\"submit\" value=\"Сохранить изменения\" class=\"btn btn-success add_button\" />
    </div>
</div>

";
        
        $__internal_196ac60ef66d11e5138d5688d67d5f9f7b71023fa15092656856cb4dfa718f1a->leave($__internal_196ac60ef66d11e5138d5688d67d5f9f7b71023fa15092656856cb4dfa718f1a_prof);

    }

    // line 28
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_72371231e9f102bb36abab9918db1e503db0cd5602f528492faac40016460759 = $this->env->getExtension("native_profiler");
        $__internal_72371231e9f102bb36abab9918db1e503db0cd5602f528492faac40016460759->enter($__internal_72371231e9f102bb36abab9918db1e503db0cd5602f528492faac40016460759_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 29
        echo "
";
        
        $__internal_72371231e9f102bb36abab9918db1e503db0cd5602f528492faac40016460759->leave($__internal_72371231e9f102bb36abab9918db1e503db0cd5602f528492faac40016460759_prof);

    }

    public function getTemplateName()
    {
        return "fkuz/editLicense.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 29,  91 => 28,  73 => 16,  69 => 15,  65 => 14,  61 => 13,  57 => 12,  53 => 11,  46 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <h1>Изменить лицензию</h1>*/
/* */
/* {{ form_start(form) }}*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         {{ form_label(form.nomer, 'Номер') }}*/
/*         {{ form_widget(form.nomer, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}*/
/*         {{ form_label(form.date, 'Дата') }}*/
/*         {{ form_widget(form.date, { 'attr': {'class': 'form-control', 'data-validation' : 'date', 'data-validation-optional' : 'true', 'data-validation-format' : 'dd.mm.yyyy'} }) }}  */
/*         {{ form_label(form.vidDeytelnosti, 'Вид деятельности') }}*/
/*         {{ form_widget(form.vidDeytelnosti, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}		*/
/*     </div>*/
/* </div>*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         <input type="submit" value="Сохранить изменения" class="btn btn-success add_button" />*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
