<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_627d09f9c101b8ababb52bc2cdf87e39a605b7e55047be98542030a24c122901 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56899b4be0dfd330e62a9706a3e0aaf3f815e0649e9c996c836d5e9dc7d9fa24 = $this->env->getExtension("native_profiler");
        $__internal_56899b4be0dfd330e62a9706a3e0aaf3f815e0649e9c996c836d5e9dc7d9fa24->enter($__internal_56899b4be0dfd330e62a9706a3e0aaf3f815e0649e9c996c836d5e9dc7d9fa24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_56899b4be0dfd330e62a9706a3e0aaf3f815e0649e9c996c836d5e9dc7d9fa24->leave($__internal_56899b4be0dfd330e62a9706a3e0aaf3f815e0649e9c996c836d5e9dc7d9fa24_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
