<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_24687303a2572919c1cb78c9c4b6322ed04e1d5cf7edff8228a5100d17b41ccf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a3ba637832634961895fe9b3309c4fc6d6f3ffb7f3d76a5504e1ba4ca94bfd33 = $this->env->getExtension("native_profiler");
        $__internal_a3ba637832634961895fe9b3309c4fc6d6f3ffb7f3d76a5504e1ba4ca94bfd33->enter($__internal_a3ba637832634961895fe9b3309c4fc6d6f3ffb7f3d76a5504e1ba4ca94bfd33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_a3ba637832634961895fe9b3309c4fc6d6f3ffb7f3d76a5504e1ba4ca94bfd33->leave($__internal_a3ba637832634961895fe9b3309c4fc6d6f3ffb7f3d76a5504e1ba4ca94bfd33_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
