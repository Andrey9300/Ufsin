<?php

/* otchet/fkuz.html.twig */
class __TwigTemplate_8d20f3a1b17ee414192bd9e74aef7f7b629f2143e348163786329586280363ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "otchet/fkuz.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a264af4a417472773cfa9842d46ca18945bcefd3befc5a30f6d43e5140d6197 = $this->env->getExtension("native_profiler");
        $__internal_8a264af4a417472773cfa9842d46ca18945bcefd3befc5a30f6d43e5140d6197->enter($__internal_8a264af4a417472773cfa9842d46ca18945bcefd3befc5a30f6d43e5140d6197_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/fkuz.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8a264af4a417472773cfa9842d46ca18945bcefd3befc5a30f6d43e5140d6197->leave($__internal_8a264af4a417472773cfa9842d46ca18945bcefd3befc5a30f6d43e5140d6197_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_bec85810e271e5bea6601d91a1a5f0bdd7c4f01b3703ce18231f3c314860f44a = $this->env->getExtension("native_profiler");
        $__internal_bec85810e271e5bea6601d91a1a5f0bdd7c4f01b3703ce18231f3c314860f44a->enter($__internal_bec85810e271e5bea6601d91a1a5f0bdd7c4f01b3703ce18231f3c314860f44a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
    ";
        // line 5
        $this->loadTemplate("views/otchet/ajax/fkuz_menu.html", "otchet/fkuz.html.twig", 5)->display($context);
        // line 6
        echo "
";
        
        $__internal_bec85810e271e5bea6601d91a1a5f0bdd7c4f01b3703ce18231f3c314860f44a->leave($__internal_bec85810e271e5bea6601d91a1a5f0bdd7c4f01b3703ce18231f3c314860f44a_prof);

    }

    // line 9
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_03985fd935332ec6907796c557d70eafad365b098fcc3f0077f68613006c5e5f = $this->env->getExtension("native_profiler");
        $__internal_03985fd935332ec6907796c557d70eafad365b098fcc3f0077f68613006c5e5f->enter($__internal_03985fd935332ec6907796c557d70eafad365b098fcc3f0077f68613006c5e5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 10
        echo "
";
        
        $__internal_03985fd935332ec6907796c557d70eafad365b098fcc3f0077f68613006c5e5f->leave($__internal_03985fd935332ec6907796c557d70eafad365b098fcc3f0077f68613006c5e5f_prof);

    }

    public function getTemplateName()
    {
        return "otchet/fkuz.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 10,  54 => 9,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*     {% include 'views/otchet/ajax/fkuz_menu.html' %}*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
