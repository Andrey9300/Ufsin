<?php

/* :otchet/ajax:zabolevaniya_iz_kontaktnyh.html.twig */
class __TwigTemplate_c61823f5f2805d292bbc00b96a03dead57f26503420dbcd260d209aca8064429 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet/ajax:zabolevaniya_iz_kontaktnyh.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b83c361249a135ef23c6b5a290fc7004d8c1c155588fbf210516ea3e49c02b7 = $this->env->getExtension("native_profiler");
        $__internal_3b83c361249a135ef23c6b5a290fc7004d8c1c155588fbf210516ea3e49c02b7->enter($__internal_3b83c361249a135ef23c6b5a290fc7004d8c1c155588fbf210516ea3e49c02b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:zabolevaniya_iz_kontaktnyh.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3b83c361249a135ef23c6b5a290fc7004d8c1c155588fbf210516ea3e49c02b7->leave($__internal_3b83c361249a135ef23c6b5a290fc7004d8c1c155588fbf210516ea3e49c02b7_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_0bb871bd663ff245e85e8fd5cbda485cfdd40af68e94e8b1c83facef88ee9e06 = $this->env->getExtension("native_profiler");
        $__internal_0bb871bd663ff245e85e8fd5cbda485cfdd40af68e94e8b1c83facef88ee9e06->enter($__internal_0bb871bd663ff245e85e8fd5cbda485cfdd40af68e94e8b1c83facef88ee9e06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/zabolevanie_menu.html", ":otchet/ajax:zabolevaniya_iz_kontaktnyh.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Повторно заболевших</h3>
    
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetZabolevaniya/izKontaktnyh\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>
    
    <div class=\"col-md-2\">
        <table class=\"table table-hover table-bordered numbers\">
            <thead>
                <tr>
                    <td>Учреждение</td>
                    <td id=\"zabolevaniya\">Количество</td>
                </tr>
            </thead>
            <tbody>

            ";
        // line 35
        $context["flag"] = "0";
        // line 36
        echo "
            ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 38
            echo "                <tr  class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                    <td class=\"name\">";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>

                        ";
            // line 41
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["onOrganizationIzKontaktnyh"]) ? $context["onOrganizationIzKontaktnyh"] : $this->getContext($context, "onOrganizationIzKontaktnyh")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["quantity"]) {
                // line 42
                echo "
                            ";
                // line 43
                if (($this->getAttribute($context["quantity"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 44
                    echo "                            
                                <td  class=\"pokazatel";
                    // line 45
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["quantity"], 1, array(), "array"), "html", null, true);
                    echo "</td>
                                ";
                    // line 46
                    $context["flag"] = "1";
                    // line 47
                    echo "
                            ";
                }
                // line 49
                echo "
                        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quantity'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 51
            echo "                        
                        ";
            // line 52
            if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                // line 53
                echo "                            <td></td>
                        ";
            }
            // line 55
            echo "                        ";
            $context["flag"] = "0";
            // line 56
            echo "                </tr> 
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "            </tbody>
            <tfoot>
                <tr>
                    <td>Всего</td>
                    <td id=\"vsego_zabolevchih\"></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
    
";
        
        $__internal_0bb871bd663ff245e85e8fd5cbda485cfdd40af68e94e8b1c83facef88ee9e06->leave($__internal_0bb871bd663ff245e85e8fd5cbda485cfdd40af68e94e8b1c83facef88ee9e06_prof);

    }

    // line 71
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_2d583628876b9ea4209ded5905e471613e29d8fe8c258bf1c5ca9c90006e9a75 = $this->env->getExtension("native_profiler");
        $__internal_2d583628876b9ea4209ded5905e471613e29d8fe8c258bf1c5ca9c90006e9a75->enter($__internal_2d583628876b9ea4209ded5905e471613e29d8fe8c258bf1c5ca9c90006e9a75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 72
        echo "
";
        
        $__internal_2d583628876b9ea4209ded5905e471613e29d8fe8c258bf1c5ca9c90006e9a75->leave($__internal_2d583628876b9ea4209ded5905e471613e29d8fe8c258bf1c5ca9c90006e9a75_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:zabolevaniya_iz_kontaktnyh.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 72,  212 => 71,  194 => 58,  179 => 56,  176 => 55,  172 => 53,  170 => 52,  167 => 51,  152 => 49,  148 => 47,  146 => 46,  140 => 45,  137 => 44,  135 => 43,  132 => 42,  115 => 41,  110 => 39,  105 => 38,  88 => 37,  85 => 36,  83 => 35,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/zabolevanie_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Повторно заболевших</h3>*/
/*     */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetZabolevaniya/izKontaktnyh" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/*     */
/*     <div class="col-md-2">*/
/*         <table class="table table-hover table-bordered numbers">*/
/*             <thead>*/
/*                 <tr>*/
/*                     <td>Учреждение</td>*/
/*                     <td id="zabolevaniya">Количество</td>*/
/*                 </tr>*/
/*             </thead>*/
/*             <tbody>*/
/* */
/*             {% set flag = "0" %}*/
/* */
/*             {% for organization in organizations %}*/
/*                 <tr  class="pokazatels{{loop.index}}">*/
/*                     <td class="name">{{organization.nameShort}}</td>*/
/* */
/*                         {% for quantity in onOrganizationIzKontaktnyh %}*/
/* */
/*                             {% if quantity.name_full == organization.nameFull %}*/
/*                             */
/*                                 <td  class="pokazatel{{loop.parent.loop.index}}">{{quantity[1]}}</td>*/
/*                                 {% set flag = "1" %}*/
/* */
/*                             {% endif %}*/
/* */
/*                         {% endfor %}*/
/*                         */
/*                         {% if flag == "0" %}*/
/*                             <td></td>*/
/*                         {% endif %}*/
/*                         {% set flag = "0" %}*/
/*                 </tr> */
/*             {% endfor %}*/
/*             </tbody>*/
/*             <tfoot>*/
/*                 <tr>*/
/*                     <td>Всего</td>*/
/*                     <td id="vsego_zabolevchih"></td>*/
/*                 </tr>*/
/*             </tfoot>*/
/*         </table>*/
/*     </div>*/
/* </div>*/
/*     */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
