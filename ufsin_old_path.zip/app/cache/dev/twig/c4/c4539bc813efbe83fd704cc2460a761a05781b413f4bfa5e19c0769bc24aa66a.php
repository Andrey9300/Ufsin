<?php

/* otchet/ajax/fkuz_menu.html */
class __TwigTemplate_403a0fc302e8dad87cdff75d851392119263dcf258c85d8219d55ba5aa3886dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_225c3deb66af2bbe2567bb2dba608a7f6640aee49e3f0ceffe97bf5574774312 = $this->env->getExtension("native_profiler");
        $__internal_225c3deb66af2bbe2567bb2dba608a7f6640aee49e3f0ceffe97bf5574774312->enter($__internal_225c3deb66af2bbe2567bb2dba608a7f6640aee49e3f0ceffe97bf5574774312_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/ajax/fkuz_menu.html"));

        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetFkuz/nakazaniya\">Наказания</a></li>
        <li><a href=\"/otchetFkuz/type\">Исследования</a></li>
    </ul>
</div>";
        
        $__internal_225c3deb66af2bbe2567bb2dba608a7f6640aee49e3f0ceffe97bf5574774312->leave($__internal_225c3deb66af2bbe2567bb2dba608a7f6640aee49e3f0ceffe97bf5574774312_prof);

    }

    public function getTemplateName()
    {
        return "otchet/ajax/fkuz_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetFkuz/nakazaniya">Наказания</a></li>*/
/*         <li><a href="/otchetFkuz/type">Исследования</a></li>*/
/*     </ul>*/
/* </div>*/
