<?php

/* :organization:index.html.twig */
class __TwigTemplate_29e1af24efeca691628b0c9d3f7a9f893f3ffd91f18f18c20f3b0480fa4cb146 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":organization:index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0bca8e318555bc94fdf7c34479ad852696b7af8fe4e6931bbb750a36901e5342 = $this->env->getExtension("native_profiler");
        $__internal_0bca8e318555bc94fdf7c34479ad852696b7af8fe4e6931bbb750a36901e5342->enter($__internal_0bca8e318555bc94fdf7c34479ad852696b7af8fe4e6931bbb750a36901e5342_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":organization:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0bca8e318555bc94fdf7c34479ad852696b7af8fe4e6931bbb750a36901e5342->leave($__internal_0bca8e318555bc94fdf7c34479ad852696b7af8fe4e6931bbb750a36901e5342_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_3dd6b2e8d7087effb3b0b9b6f0e53d9bb9c702f8eb37ce74365652292065b690 = $this->env->getExtension("native_profiler");
        $__internal_3dd6b2e8d7087effb3b0b9b6f0e53d9bb9c702f8eb37ce74365652292065b690->enter($__internal_3dd6b2e8d7087effb3b0b9b6f0e53d9bb9c702f8eb37ce74365652292065b690_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
    <div class=\"row\">
        <div class=\"col-sm-5\">
            <div class=\"well\">
                <h1>Security</h1>
            </div>
        </div>
    </div>
";
        
        $__internal_3dd6b2e8d7087effb3b0b9b6f0e53d9bb9c702f8eb37ce74365652292065b690->leave($__internal_3dd6b2e8d7087effb3b0b9b6f0e53d9bb9c702f8eb37ce74365652292065b690_prof);

    }

    // line 14
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_986bbc7e0cc2371eb8ad0b9441389fc05ac6c114374d6f9568ef97c347d6a087 = $this->env->getExtension("native_profiler");
        $__internal_986bbc7e0cc2371eb8ad0b9441389fc05ac6c114374d6f9568ef97c347d6a087->enter($__internal_986bbc7e0cc2371eb8ad0b9441389fc05ac6c114374d6f9568ef97c347d6a087_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 15
        echo "
";
        
        $__internal_986bbc7e0cc2371eb8ad0b9441389fc05ac6c114374d6f9568ef97c347d6a087->leave($__internal_986bbc7e0cc2371eb8ad0b9441389fc05ac6c114374d6f9568ef97c347d6a087_prof);

    }

    // line 18
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_079be9a94fb5d29254fa46a269af1d8190a3ccbde0f5a134c10c99b42dfdaefc = $this->env->getExtension("native_profiler");
        $__internal_079be9a94fb5d29254fa46a269af1d8190a3ccbde0f5a134c10c99b42dfdaefc->enter($__internal_079be9a94fb5d29254fa46a269af1d8190a3ccbde0f5a134c10c99b42dfdaefc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 19
        echo "
";
        // line 20
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

";
        
        $__internal_079be9a94fb5d29254fa46a269af1d8190a3ccbde0f5a134c10c99b42dfdaefc->leave($__internal_079be9a94fb5d29254fa46a269af1d8190a3ccbde0f5a134c10c99b42dfdaefc_prof);

    }

    public function getTemplateName()
    {
        return ":organization:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 20,  77 => 19,  71 => 18,  63 => 15,  57 => 14,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*     <div class="row">*/
/*         <div class="col-sm-5">*/
/*             <div class="well">*/
/*                 <h1>Security</h1>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/* */
/* {{ parent() }}*/
/* */
/* {% endblock %}*/
/* */
