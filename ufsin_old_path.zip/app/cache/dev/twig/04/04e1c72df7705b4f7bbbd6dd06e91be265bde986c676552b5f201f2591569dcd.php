<?php

/* :otchet/ajax:issledovanie_type.html.twig */
class __TwigTemplate_c4f2994f9bb317a388060fd3e70152ec56b84e3427e0b6692c7e3e388c294d71 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet/ajax:issledovanie_type.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_456c811375e9097c1318a7e487920ea20d978db4c3d348a0a5a6de98727565a2 = $this->env->getExtension("native_profiler");
        $__internal_456c811375e9097c1318a7e487920ea20d978db4c3d348a0a5a6de98727565a2->enter($__internal_456c811375e9097c1318a7e487920ea20d978db4c3d348a0a5a6de98727565a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:issledovanie_type.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_456c811375e9097c1318a7e487920ea20d978db4c3d348a0a5a6de98727565a2->leave($__internal_456c811375e9097c1318a7e487920ea20d978db4c3d348a0a5a6de98727565a2_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_0240d6a7ffd2e46eb0abdbfe3dae06e126b944f308aad824f22125041f6620ce = $this->env->getExtension("native_profiler");
        $__internal_0240d6a7ffd2e46eb0abdbfe3dae06e126b944f308aad824f22125041f6620ce->enter($__internal_0240d6a7ffd2e46eb0abdbfe3dae06e126b944f308aad824f22125041f6620ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/issledovanie_menu.html", ":otchet/ajax:issledovanie_type.html.twig", 5)->display($context);
        // line 6
        echo "    
<div class=\"row\">
    <h3>Общая статистика исследований</h3>
        
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetIssledovaniya/type\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>

    <table class=\"table table-hover table-bordered numbers\" id=\"common_proverka\">
        <thead>
            <tr>
                <td></td>
                ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 30
            echo "                    <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                <td id=\"issledovaniya\">Итого</td>
            </tr>
        </thead>
        <tbody>

        ";
        // line 37
        $context["flag"] = "0";
        // line 38
        echo "
        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["issledovanieTypes"]) ? $context["issledovanieTypes"] : $this->getContext($context, "issledovanieTypes")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 40
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["type"], "name", array()), "html", null, true);
            echo "</td>

                ";
            // line 43
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
                // line 44
                echo "
                    ";
                // line 45
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["commonAll"]) ? $context["commonAll"] : $this->getContext($context, "commonAll")));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["quantity"] => $context["key"]) {
                    // line 46
                    echo "
                        ";
                    // line 47
                    if (($this->getAttribute($context["key"], "name_full", array(), "array") == $this->getAttribute($context["organization"], "nameFull", array()))) {
                        // line 48
                        echo "
                                ";
                        // line 49
                        if (($this->getAttribute($context["key"], "name", array(), "array") == $this->getAttribute($context["type"], "name", array()))) {
                            // line 50
                            echo "
                                    <td class=\"pokazatel";
                            // line 51
                            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                            echo "\">
                                    <span>";
                            // line 52
                            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], 1, array(), "array"), "html", null, true);
                            echo "</span>(";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["key"], 2, array(), "array"), "html", null, true);
                            echo ")
                                </td>
                                    ";
                            // line 54
                            $context["flag"] = "1";
                            // line 55
                            echo "                                ";
                        }
                        // line 56
                        echo "
                        ";
                    }
                    // line 58
                    echo "
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['quantity'], $context['key'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 60
                echo "
                    ";
                // line 61
                if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                    // line 62
                    echo "                        <td></td>
                    ";
                }
                // line 64
                echo "                    ";
                $context["flag"] = "0";
                // line 65
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 66
            echo "                <td></td>
            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 69
        echo "        </tbody>
        <tfoot>
            <tr>
                <td>Всего</td>
                ";
        // line 73
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 74
            echo "                    <td id=\"result";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\"></td>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 76
        echo "                <td id=\"vsego\"></td>
            </tr>
            <tr>
                <td></td>
                ";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 81
            echo "                    <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "                <td></td>
            </tr>
        </tfoot>
    </table>
</div>
";
        
        $__internal_0240d6a7ffd2e46eb0abdbfe3dae06e126b944f308aad824f22125041f6620ce->leave($__internal_0240d6a7ffd2e46eb0abdbfe3dae06e126b944f308aad824f22125041f6620ce_prof);

    }

    // line 90
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_956b37114217b08e85703df184366106ae0389a9ccfb1e3dd4c82b1336ebafe3 = $this->env->getExtension("native_profiler");
        $__internal_956b37114217b08e85703df184366106ae0389a9ccfb1e3dd4c82b1336ebafe3->enter($__internal_956b37114217b08e85703df184366106ae0389a9ccfb1e3dd4c82b1336ebafe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 91
        echo "
";
        
        $__internal_956b37114217b08e85703df184366106ae0389a9ccfb1e3dd4c82b1336ebafe3->leave($__internal_956b37114217b08e85703df184366106ae0389a9ccfb1e3dd4c82b1336ebafe3_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:issledovanie_type.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  333 => 91,  327 => 90,  315 => 83,  306 => 81,  302 => 80,  296 => 76,  279 => 74,  262 => 73,  256 => 69,  240 => 66,  226 => 65,  223 => 64,  219 => 62,  217 => 61,  214 => 60,  199 => 58,  195 => 56,  192 => 55,  190 => 54,  183 => 52,  179 => 51,  176 => 50,  174 => 49,  171 => 48,  169 => 47,  166 => 46,  149 => 45,  146 => 44,  129 => 43,  124 => 41,  119 => 40,  102 => 39,  99 => 38,  97 => 37,  90 => 32,  81 => 30,  77 => 29,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/issledovanie_menu.html' %}*/
/*     */
/* <div class="row">*/
/*     <h3>Общая статистика исследований</h3>*/
/*         */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetIssledovaniya/type" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/* */
/*     <table class="table table-hover table-bordered numbers" id="common_proverka">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 {% for organization in organizations %}*/
/*                     <td>{{organization.nameShort}}</td>*/
/*                 {% endfor %}*/
/*                 <td id="issledovaniya">Итого</td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/* */
/*         {% set flag = "0" %}*/
/* */
/*         {% for type in issledovanieTypes %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{type.name}}</td>*/
/* */
/*                 {% for organization in organizations %}*/
/* */
/*                     {% for quantity, key in commonAll %}*/
/* */
/*                         {% if key["name_full"] == organization.nameFull %}*/
/* */
/*                                 {% if key["name"] == type.name %}*/
/* */
/*                                     <td class="pokazatel{{loop.parent.loop.index}}">*/
/*                                     <span>{{ key[1] }}</span>({{ key[2] }})*/
/*                                 </td>*/
/*                                     {% set flag = "1" %}*/
/*                                 {% endif %}*/
/* */
/*                         {% endif %}*/
/* */
/*                     {% endfor %}*/
/* */
/*                     {% if flag == "0" %}*/
/*                         <td></td>*/
/*                     {% endif %}*/
/*                     {% set flag = "0" %}*/
/*                 {% endfor %}*/
/*                 <td></td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*             <tr>*/
/*                 <td>Всего</td>*/
/*                 {% for organization in organizations %}*/
/*                     <td id="result{{loop.index}}"></td>*/
/*                 {% endfor %}*/
/*                 <td id="vsego"></td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 {% for organization in organizations %}*/
/*                     <td>{{organization.nameShort}}</td>*/
/*                 {% endfor %}*/
/*                 <td></td>*/
/*             </tr>*/
/*         </tfoot>*/
/*     </table>*/
/* </div>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
