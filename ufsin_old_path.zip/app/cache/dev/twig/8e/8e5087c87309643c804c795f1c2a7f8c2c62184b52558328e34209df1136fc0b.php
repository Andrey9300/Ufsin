<?php

/* :fkuz:editPokazatel.html.twig */
class __TwigTemplate_d95a2bf5d967b9c47a33292139c2d3bf316c3ed01ab31ff4e6acd8bc5135881a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":fkuz:editPokazatel.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9506308b0e01dc43be9dcfde8d18f4106648b494d80e19c4981d4197d3685ef = $this->env->getExtension("native_profiler");
        $__internal_f9506308b0e01dc43be9dcfde8d18f4106648b494d80e19c4981d4197d3685ef->enter($__internal_f9506308b0e01dc43be9dcfde8d18f4106648b494d80e19c4981d4197d3685ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":fkuz:editPokazatel.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f9506308b0e01dc43be9dcfde8d18f4106648b494d80e19c4981d4197d3685ef->leave($__internal_f9506308b0e01dc43be9dcfde8d18f4106648b494d80e19c4981d4197d3685ef_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_da8795b1c7ec7f9a586cbcf9372a127a859b2476ce718e8dbec85a64d661f45f = $this->env->getExtension("native_profiler");
        $__internal_da8795b1c7ec7f9a586cbcf9372a127a859b2476ce718e8dbec85a64d661f45f->enter($__internal_da8795b1c7ec7f9a586cbcf9372a127a859b2476ce718e8dbec85a64d661f45f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
    <div class=\"row\">
        <h1>Редактирование показателя</h1>
    </div>

    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

    <div class=\"row\">
        <div class=\"col-md-12\">
            <input type=\"submit\" value=\"Сохранить изменения\" class=\"btn btn-success\" style=\"float:right;\"/>
        </div>
    </div>

    <div class=\"row\">
        ";
        // line 18
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pokazatel", array()), 'label', array("label" => "Показатель"));
        echo "
        ";
        // line 19
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pokazatel", array()), 'widget', array("attr" => array("class" => "form-control", "readonly" => "readonly")));
        echo "
        ";
        // line 20
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'label', array("label" => "Не соответствие"));
        echo "
        ";
        // line 21
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
    </div>

    <div class=\"row\">
        <hr/>
        <ul class=\"nav navbar-nav add\">
            <li><a href=\"/fkuz/deletePokazatel/";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pokazateslIssledovaniyaFkuz"]) ? $context["pokazateslIssledovaniyaFkuz"] : $this->getContext($context, "pokazateslIssledovaniyaFkuz")), "id", array()), "html", null, true);
        echo "\" class=\"delete_entity\">Удалить показатель</a></li>
        </ul>
    </div>

    <div class=\"row\">
        <div class=\"col-md-12\">
            <input type=\"submit\" value=\"Сохранить изменения\" class=\"btn btn-success\" style=\"float:right;\"/>
        </div>
    </div>

";
        
        $__internal_da8795b1c7ec7f9a586cbcf9372a127a859b2476ce718e8dbec85a64d661f45f->leave($__internal_da8795b1c7ec7f9a586cbcf9372a127a859b2476ce718e8dbec85a64d661f45f_prof);

    }

    // line 39
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_1f7e49753543f6de8dda223666cc406e1f0d2bb54646013505edf9cb19cf9ddb = $this->env->getExtension("native_profiler");
        $__internal_1f7e49753543f6de8dda223666cc406e1f0d2bb54646013505edf9cb19cf9ddb->enter($__internal_1f7e49753543f6de8dda223666cc406e1f0d2bb54646013505edf9cb19cf9ddb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 40
        echo "
";
        
        $__internal_1f7e49753543f6de8dda223666cc406e1f0d2bb54646013505edf9cb19cf9ddb->leave($__internal_1f7e49753543f6de8dda223666cc406e1f0d2bb54646013505edf9cb19cf9ddb_prof);

    }

    public function getTemplateName()
    {
        return ":fkuz:editPokazatel.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 40,  99 => 39,  81 => 27,  72 => 21,  68 => 20,  64 => 19,  60 => 18,  48 => 9,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*     <div class="row">*/
/*         <h1>Редактирование показателя</h1>*/
/*     </div>*/
/* */
/*     {{ form_start(form) }}*/
/* */
/*     <div class="row">*/
/*         <div class="col-md-12">*/
/*             <input type="submit" value="Сохранить изменения" class="btn btn-success" style="float:right;"/>*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="row">*/
/*         {{ form_label(form.pokazatel, 'Показатель') }}*/
/*         {{ form_widget(form.pokazatel, { 'attr': {'class': 'form-control', 'readonly' : 'readonly'} }) }}*/
/*         {{ form_label(form.description, 'Не соответствие') }}*/
/*         {{ form_widget(form.description, { 'attr': {'class': 'form-control'} }) }}*/
/*     </div>*/
/* */
/*     <div class="row">*/
/*         <hr/>*/
/*         <ul class="nav navbar-nav add">*/
/*             <li><a href="/fkuz/deletePokazatel/{{ pokazateslIssledovaniyaFkuz.id }}" class="delete_entity">Удалить показатель</a></li>*/
/*         </ul>*/
/*     </div>*/
/* */
/*     <div class="row">*/
/*         <div class="col-md-12">*/
/*             <input type="submit" value="Сохранить изменения" class="btn btn-success" style="float:right;"/>*/
/*         </div>*/
/*     </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
