<?php

/* :fkuz:createVidDeyatelnosti.html.twig */
class __TwigTemplate_a1bd064e54de74cd6caed134024c146d4ed59ded4eff764cee15ae12b3899faa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":fkuz:createVidDeyatelnosti.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7efd5128e8d116c58031761570c456eb79b5c8a89dddf330ed5c495ef990e578 = $this->env->getExtension("native_profiler");
        $__internal_7efd5128e8d116c58031761570c456eb79b5c8a89dddf330ed5c495ef990e578->enter($__internal_7efd5128e8d116c58031761570c456eb79b5c8a89dddf330ed5c495ef990e578_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":fkuz:createVidDeyatelnosti.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7efd5128e8d116c58031761570c456eb79b5c8a89dddf330ed5c495ef990e578->leave($__internal_7efd5128e8d116c58031761570c456eb79b5c8a89dddf330ed5c495ef990e578_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_c42aabbc255749438049df19a9781d29906cc67ce21cdd3511b2258ad5c1d50d = $this->env->getExtension("native_profiler");
        $__internal_c42aabbc255749438049df19a9781d29906cc67ce21cdd3511b2258ad5c1d50d->enter($__internal_c42aabbc255749438049df19a9781d29906cc67ce21cdd3511b2258ad5c1d50d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<h1>Добавить вид деятельности</h1>

";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

<div class=\"row\">
    <div class=\"col-md-4\">
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label', array("label" => "Наименование"));
        echo "
        ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "     
    </div>
</div>

<div class=\"row\">
    <div class=\"col-md-4\">
        <input type=\"submit\" value=\"Добавить\" class=\"btn btn-success add_button\" />
    </div>
</div>

";
        
        $__internal_c42aabbc255749438049df19a9781d29906cc67ce21cdd3511b2258ad5c1d50d->leave($__internal_c42aabbc255749438049df19a9781d29906cc67ce21cdd3511b2258ad5c1d50d_prof);

    }

    // line 24
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_d7a2b99a0c5db50dddaf478acf490e8f4c3b40a825dfcb98aa9636144b2eba18 = $this->env->getExtension("native_profiler");
        $__internal_d7a2b99a0c5db50dddaf478acf490e8f4c3b40a825dfcb98aa9636144b2eba18->enter($__internal_d7a2b99a0c5db50dddaf478acf490e8f4c3b40a825dfcb98aa9636144b2eba18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 25
        echo "
";
        
        $__internal_d7a2b99a0c5db50dddaf478acf490e8f4c3b40a825dfcb98aa9636144b2eba18->leave($__internal_d7a2b99a0c5db50dddaf478acf490e8f4c3b40a825dfcb98aa9636144b2eba18_prof);

    }

    public function getTemplateName()
    {
        return ":fkuz:createVidDeyatelnosti.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 25,  75 => 24,  57 => 12,  53 => 11,  46 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <h1>Добавить вид деятельности</h1>*/
/* */
/* {{ form_start(form) }}*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         {{ form_label(form.name, 'Наименование') }}*/
/*         {{ form_widget(form.name, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}     */
/*     </div>*/
/* </div>*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         <input type="submit" value="Добавить" class="btn btn-success add_button" />*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
