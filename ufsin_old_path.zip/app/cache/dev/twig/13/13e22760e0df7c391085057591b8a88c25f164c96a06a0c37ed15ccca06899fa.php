<?php

/* :organization:allNameOrganizations.html.twig */
class __TwigTemplate_1cbbc211b6a6b7cb150930b01a04b1af6759d3ea672ee9f2dfbed5caa4d0578f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a6e83519fff04751b268fe9af453c453f009f151cc76567a435ec366ab8df3b5 = $this->env->getExtension("native_profiler");
        $__internal_a6e83519fff04751b268fe9af453c453f009f151cc76567a435ec366ab8df3b5->enter($__internal_a6e83519fff04751b268fe9af453c453f009f151cc76567a435ec366ab8df3b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":organization:allNameOrganizations.html.twig"));

        // line 1
        echo "<ul class=\"dropdown-menu\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        foreach ($context['_seq'] as $context["_key"] => $context["org"]) {
            // line 3
            echo "        <li><a href=\"/organization/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["org"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["org"], "nameShort", array()), "html", null, true);
            echo "</a></li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['org'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 5
        echo "</ul>";
        
        $__internal_a6e83519fff04751b268fe9af453c453f009f151cc76567a435ec366ab8df3b5->leave($__internal_a6e83519fff04751b268fe9af453c453f009f151cc76567a435ec366ab8df3b5_prof);

    }

    public function getTemplateName()
    {
        return ":organization:allNameOrganizations.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 5,  29 => 3,  25 => 2,  22 => 1,);
    }
}
/* <ul class="dropdown-menu">*/
/*     {% for org in organizations %}*/
/*         <li><a href="/organization/{{org.id}}">{{org.nameShort}}</a></li>*/
/*     {% endfor %}*/
/* </ul>*/
