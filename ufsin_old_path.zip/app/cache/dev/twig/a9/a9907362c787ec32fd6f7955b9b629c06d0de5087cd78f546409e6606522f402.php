<?php

/* :otchet/ajax:proverka_type.html.twig */
class __TwigTemplate_997b82390a8d7fec4ebf3d5719a9feabd6ca3ea2cdeb7478161e591d79702d24 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet/ajax:proverka_type.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75598323e54ca962e1a406d4304320d758ea8296e7bf7b181fd48b25cb48e399 = $this->env->getExtension("native_profiler");
        $__internal_75598323e54ca962e1a406d4304320d758ea8296e7bf7b181fd48b25cb48e399->enter($__internal_75598323e54ca962e1a406d4304320d758ea8296e7bf7b181fd48b25cb48e399_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:proverka_type.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_75598323e54ca962e1a406d4304320d758ea8296e7bf7b181fd48b25cb48e399->leave($__internal_75598323e54ca962e1a406d4304320d758ea8296e7bf7b181fd48b25cb48e399_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_6cf8e13bf57b1e63f8c49e9e0b185974beb28a33f03d9a857e686af2397af7d3 = $this->env->getExtension("native_profiler");
        $__internal_6cf8e13bf57b1e63f8c49e9e0b185974beb28a33f03d9a857e686af2397af7d3->enter($__internal_6cf8e13bf57b1e63f8c49e9e0b185974beb28a33f03d9a857e686af2397af7d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/proverka_menu.html", ":otchet/ajax:proverka_type.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Статистика по проверкам</h3>
    
    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetProverka/common\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>    
    </div>
    
    <table class=\"table table-hover table-bordered numbers\">
        <thead>
            <tr>
                <td></td>
                <td colspan=\"4\">Плановые</td>
                <td colspan=\"3\">Внеплановые</td>
                <td colspan=\"2\" id=\"itog_double\">Итог</td>
            </tr>
            <tr>
                <td>Учреждение</td>
                ";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverkaType"]) ? $context["proverkaType"] : $this->getContext($context, "proverkaType")));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 36
            echo "                    <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["type"], "name", array()), "html", null, true);
            echo "</td>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                <td>Плановые</td>
                <td>Внеплановые</td>
            </tr>
        </thead>
        <tbody>

        ";
        // line 44
        $context["flag"] = "0";
        // line 45
        echo "
        ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 47
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>
                
                ";
            // line 50
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["proverkaType"]) ? $context["proverkaType"] : $this->getContext($context, "proverkaType")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                // line 51
                echo "
                    ";
                // line 52
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["onTypeAndOrganizationQuantity"]) ? $context["onTypeAndOrganizationQuantity"] : $this->getContext($context, "onTypeAndOrganizationQuantity")));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["quantity"]) {
                    // line 53
                    echo "                    
                        ";
                    // line 54
                    if (($this->getAttribute($context["quantity"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                        // line 55
                        echo "                        
                            ";
                        // line 56
                        if (($this->getAttribute($context["quantity"], "name", array()) == $this->getAttribute($context["type"], "name", array()))) {
                            // line 57
                            echo "                                
                                ";
                            // line 58
                            if (($this->getAttribute($context["quantity"], "planovost", array()) == "1")) {
                                // line 59
                                echo "                                <td class=\"pokazatel";
                                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                                echo " plan\">";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["quantity"], 1, array(), "array"), "html", null, true);
                                echo "</td>
                                ";
                            } else {
                                // line 61
                                echo "                                <td class=\"pokazatel";
                                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                                echo " vneplan\">";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["quantity"], 1, array(), "array"), "html", null, true);
                                echo "</td>
                                ";
                            }
                            // line 63
                            echo "                                
                                ";
                            // line 64
                            $context["flag"] = "1";
                            // line 65
                            echo "                                
                            ";
                        }
                        // line 67
                        echo "                            
                        ";
                    }
                    // line 69
                    echo "
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quantity'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 71
                echo "                    
                    ";
                // line 72
                if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                    // line 73
                    echo "                        <td></td>
                    ";
                }
                // line 75
                echo "                    ";
                $context["flag"] = "0";
                // line 76
                echo "
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 78
            echo "                
                <td></td>
                <td></td>
            </tr> 
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "        </tbody>
        <tfoot>
            <tr>
                <td rowspan=\"3\" style=\"text-align:center; padding-top:40px\">Всего</td>
                <td id=\"result1\"></td>
                <td id=\"result2\"></td>
                <td id=\"result3\"></td>
                <td id=\"result4\"></td>
                <td id=\"result5\"></td>
                <td id=\"result6\"></td>
                <td id=\"result7\"></td>
                <td style=\"text-align:center;padding-top:40px\" colspan=\"2\" rowspan=\"3\" id=\"vsego\"></td>
            </tr> 
            <tr>
                <td colspan=\"4\">Плановые</td>
                <td colspan=\"3\">Внеплановые</td>
            </tr>            
            <tr>
                <td colspan=\"4\" id=\"result8\"></td>
                <td colspan=\"3\" id=\"result9\"></td>
            </tr>
        </tfoot>
        
    </table>
</div>
";
        
        $__internal_6cf8e13bf57b1e63f8c49e9e0b185974beb28a33f03d9a857e686af2397af7d3->leave($__internal_6cf8e13bf57b1e63f8c49e9e0b185974beb28a33f03d9a857e686af2397af7d3_prof);

    }

    // line 110
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_01b82f985197bacfa5517a74f4e96fad6e504063c52b7020e5106ab1393bdce0 = $this->env->getExtension("native_profiler");
        $__internal_01b82f985197bacfa5517a74f4e96fad6e504063c52b7020e5106ab1393bdce0->enter($__internal_01b82f985197bacfa5517a74f4e96fad6e504063c52b7020e5106ab1393bdce0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 111
        echo "
";
        
        $__internal_01b82f985197bacfa5517a74f4e96fad6e504063c52b7020e5106ab1393bdce0->leave($__internal_01b82f985197bacfa5517a74f4e96fad6e504063c52b7020e5106ab1393bdce0_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:proverka_type.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  315 => 111,  309 => 110,  277 => 83,  259 => 78,  244 => 76,  241 => 75,  237 => 73,  235 => 72,  232 => 71,  217 => 69,  213 => 67,  209 => 65,  207 => 64,  204 => 63,  196 => 61,  188 => 59,  186 => 58,  183 => 57,  181 => 56,  178 => 55,  176 => 54,  173 => 53,  156 => 52,  153 => 51,  136 => 50,  131 => 48,  126 => 47,  109 => 46,  106 => 45,  104 => 44,  96 => 38,  87 => 36,  83 => 35,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/proverka_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Статистика по проверкам</h3>*/
/*     */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetProverka/common" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>    */
/*     </div>*/
/*     */
/*     <table class="table table-hover table-bordered numbers">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 <td colspan="4">Плановые</td>*/
/*                 <td colspan="3">Внеплановые</td>*/
/*                 <td colspan="2" id="itog_double">Итог</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <td>Учреждение</td>*/
/*                 {% for type in proverkaType %}*/
/*                     <td>{{type.name}}</td>*/
/*                 {% endfor %}*/
/*                 <td>Плановые</td>*/
/*                 <td>Внеплановые</td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/* */
/*         {% set flag = "0" %}*/
/* */
/*         {% for organization in organizations %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{organization.nameShort}}</td>*/
/*                 */
/*                 {% for type in proverkaType %}*/
/* */
/*                     {% for quantity in onTypeAndOrganizationQuantity %}*/
/*                     */
/*                         {% if quantity.name_full == organization.nameFull %}*/
/*                         */
/*                             {% if quantity.name == type.name %}*/
/*                                 */
/*                                 {% if quantity.planovost == "1" %}*/
/*                                 <td class="pokazatel{{loop.parent.loop.index}} plan">{{quantity[1]}}</td>*/
/*                                 {% else %}*/
/*                                 <td class="pokazatel{{loop.parent.loop.index}} vneplan">{{quantity[1]}}</td>*/
/*                                 {% endif %}*/
/*                                 */
/*                                 {% set flag = "1" %}*/
/*                                 */
/*                             {% endif %}*/
/*                             */
/*                         {% endif %}*/
/* */
/*                     {% endfor %}*/
/*                     */
/*                     {% if flag == "0" %}*/
/*                         <td></td>*/
/*                     {% endif %}*/
/*                     {% set flag = "0" %}*/
/* */
/*                 {% endfor %}*/
/*                 */
/*                 <td></td>*/
/*                 <td></td>*/
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*             <tr>*/
/*                 <td rowspan="3" style="text-align:center; padding-top:40px">Всего</td>*/
/*                 <td id="result1"></td>*/
/*                 <td id="result2"></td>*/
/*                 <td id="result3"></td>*/
/*                 <td id="result4"></td>*/
/*                 <td id="result5"></td>*/
/*                 <td id="result6"></td>*/
/*                 <td id="result7"></td>*/
/*                 <td style="text-align:center;padding-top:40px" colspan="2" rowspan="3" id="vsego"></td>*/
/*             </tr> */
/*             <tr>*/
/*                 <td colspan="4">Плановые</td>*/
/*                 <td colspan="3">Внеплановые</td>*/
/*             </tr>            */
/*             <tr>*/
/*                 <td colspan="4" id="result8"></td>*/
/*                 <td colspan="3" id="result9"></td>*/
/*             </tr>*/
/*         </tfoot>*/
/*         */
/*     </table>*/
/* </div>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
