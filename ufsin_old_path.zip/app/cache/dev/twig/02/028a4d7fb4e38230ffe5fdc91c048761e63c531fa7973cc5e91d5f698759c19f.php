<?php

/* organization/index.html.twig */
class __TwigTemplate_74489ee646fa61ae1bfe8f708a9107b2bad71d4fae0e22e95b40b8256d3881a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "organization/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b9ef8d964258b8b38cb8420b949cdcb4242388dcb8022a634df04a38b408737e = $this->env->getExtension("native_profiler");
        $__internal_b9ef8d964258b8b38cb8420b949cdcb4242388dcb8022a634df04a38b408737e->enter($__internal_b9ef8d964258b8b38cb8420b949cdcb4242388dcb8022a634df04a38b408737e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "organization/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b9ef8d964258b8b38cb8420b949cdcb4242388dcb8022a634df04a38b408737e->leave($__internal_b9ef8d964258b8b38cb8420b949cdcb4242388dcb8022a634df04a38b408737e_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_5e96bf0d84398da8e5df212f182234cbfea106b151f664c45021402a7d959626 = $this->env->getExtension("native_profiler");
        $__internal_5e96bf0d84398da8e5df212f182234cbfea106b151f664c45021402a7d959626->enter($__internal_5e96bf0d84398da8e5df212f182234cbfea106b151f664c45021402a7d959626_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
    <div class=\"row\">
        <div class=\"col-sm-5\">
            <div class=\"well\">
                <h1>Security</h1>
            </div>
        </div>
    </div>
";
        
        $__internal_5e96bf0d84398da8e5df212f182234cbfea106b151f664c45021402a7d959626->leave($__internal_5e96bf0d84398da8e5df212f182234cbfea106b151f664c45021402a7d959626_prof);

    }

    // line 14
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_79d4ef130425e396e14a2b1cd1940c825ebe9a71d072d4091b4de9efa04bb69a = $this->env->getExtension("native_profiler");
        $__internal_79d4ef130425e396e14a2b1cd1940c825ebe9a71d072d4091b4de9efa04bb69a->enter($__internal_79d4ef130425e396e14a2b1cd1940c825ebe9a71d072d4091b4de9efa04bb69a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 15
        echo "
";
        
        $__internal_79d4ef130425e396e14a2b1cd1940c825ebe9a71d072d4091b4de9efa04bb69a->leave($__internal_79d4ef130425e396e14a2b1cd1940c825ebe9a71d072d4091b4de9efa04bb69a_prof);

    }

    // line 18
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5bd779f5215ae795316008071bf543276ba1325c45796f71f700794f37578299 = $this->env->getExtension("native_profiler");
        $__internal_5bd779f5215ae795316008071bf543276ba1325c45796f71f700794f37578299->enter($__internal_5bd779f5215ae795316008071bf543276ba1325c45796f71f700794f37578299_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 19
        echo "
";
        // line 20
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

";
        
        $__internal_5bd779f5215ae795316008071bf543276ba1325c45796f71f700794f37578299->leave($__internal_5bd779f5215ae795316008071bf543276ba1325c45796f71f700794f37578299_prof);

    }

    public function getTemplateName()
    {
        return "organization/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 20,  77 => 19,  71 => 18,  63 => 15,  57 => 14,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*     <div class="row">*/
/*         <div class="col-sm-5">*/
/*             <div class="well">*/
/*                 <h1>Security</h1>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/* */
/* {{ parent() }}*/
/* */
/* {% endblock %}*/
/* */
