<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_52c3cf0bfa9d66aa60696fad94e9bc3ba529fc93e2dad074bcad8bc304d83bb7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1791a0c15f0fa9379f9c4fc26438a032c4d7a06fc120ea4f0da7e92a93eddffd = $this->env->getExtension("native_profiler");
        $__internal_1791a0c15f0fa9379f9c4fc26438a032c4d7a06fc120ea4f0da7e92a93eddffd->enter($__internal_1791a0c15f0fa9379f9c4fc26438a032c4d7a06fc120ea4f0da7e92a93eddffd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_1791a0c15f0fa9379f9c4fc26438a032c4d7a06fc120ea4f0da7e92a93eddffd->leave($__internal_1791a0c15f0fa9379f9c4fc26438a032c4d7a06fc120ea4f0da7e92a93eddffd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
