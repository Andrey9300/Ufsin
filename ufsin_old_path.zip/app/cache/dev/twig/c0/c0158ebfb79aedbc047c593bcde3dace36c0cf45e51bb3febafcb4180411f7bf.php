<?php

/* TwigBundle:Exception:error.html.twig */
class __TwigTemplate_f2a5b3e586d4e888f7e2505e951a8616120775097ce194dbec352d964fcdba15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a6d644ec6b834bf487d4e8d26a09e7e2465742518e6516c2d9cce3d9fac7334d = $this->env->getExtension("native_profiler");
        $__internal_a6d644ec6b834bf487d4e8d26a09e7e2465742518e6516c2d9cce3d9fac7334d->enter($__internal_a6d644ec6b834bf487d4e8d26a09e7e2465742518e6516c2d9cce3d9fac7334d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a6d644ec6b834bf487d4e8d26a09e7e2465742518e6516c2d9cce3d9fac7334d->leave($__internal_a6d644ec6b834bf487d4e8d26a09e7e2465742518e6516c2d9cce3d9fac7334d_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_0f46160ea460c495ddb7f4b92cc1631e3fc86ead31e6a5916736f349bf077cb9 = $this->env->getExtension("native_profiler");
        $__internal_0f46160ea460c495ddb7f4b92cc1631e3fc86ead31e6a5916736f349bf077cb9->enter($__internal_0f46160ea460c495ddb7f4b92cc1631e3fc86ead31e6a5916736f349bf077cb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_0f46160ea460c495ddb7f4b92cc1631e3fc86ead31e6a5916736f349bf077cb9->leave($__internal_0f46160ea460c495ddb7f4b92cc1631e3fc86ead31e6a5916736f349bf077cb9_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_9006995379885bb4f27e14ffea0556edea6a41932f519be2711c8e7b928102f7 = $this->env->getExtension("native_profiler");
        $__internal_9006995379885bb4f27e14ffea0556edea6a41932f519be2711c8e7b928102f7->enter($__internal_9006995379885bb4f27e14ffea0556edea6a41932f519be2711c8e7b928102f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">Произошла ошибка</h1>

    <p class=\"lead\">
        Скорее всего вы не верно ввели данные или произошла техническая ошибка.
    </p>
    
    <p>
        Пожалуйста, проверьте вводимые данные <a href=\"#\" id=\"back_page\">на предыдущей странице</a> и/или повторите снова.
    </p>
";
        
        $__internal_9006995379885bb4f27e14ffea0556edea6a41932f519be2711c8e7b928102f7->leave($__internal_9006995379885bb4f27e14ffea0556edea6a41932f519be2711c8e7b928102f7_prof);

    }

    // line 27
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_b26065b182b4a67828f1eed8f065746b38b5b16145b9fb21d256661cbe655c2f = $this->env->getExtension("native_profiler");
        $__internal_b26065b182b4a67828f1eed8f065746b38b5b16145b9fb21d256661cbe655c2f->enter($__internal_b26065b182b4a67828f1eed8f065746b38b5b16145b9fb21d256661cbe655c2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 28
        echo "
";
        
        $__internal_b26065b182b4a67828f1eed8f065746b38b5b16145b9fb21d256661cbe655c2f->leave($__internal_b26065b182b4a67828f1eed8f065746b38b5b16145b9fb21d256661cbe655c2f_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 28,  70 => 27,  54 => 16,  48 => 15,  36 => 13,  11 => 11,);
    }
}
/* {#*/
/*     This template is used to render errors of type HTTP 500 (Internal Server Error)*/
/* */
/*     This is the simplest way to customize error pages in Symfony applications.*/
/*     In case you need it, you can also hook into the internal exception handling*/
/*     made by Symfony. This allows you to perform advanced tasks and even recover*/
/*     your application from some errors.*/
/*     See http://symfony.com/doc/current/cookbook/controller/error_pages.html*/
/* #}*/
/* */
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'error' %}*/
/* */
/* {% block main %}*/
/*     <h1 class="text-danger">Произошла ошибка</h1>*/
/* */
/*     <p class="lead">*/
/*         Скорее всего вы не верно ввели данные или произошла техническая ошибка.*/
/*     </p>*/
/*     */
/*     <p>*/
/*         Пожалуйста, проверьте вводимые данные <a href="#" id="back_page">на предыдущей странице</a> и/или повторите снова.*/
/*     </p>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
/* */
