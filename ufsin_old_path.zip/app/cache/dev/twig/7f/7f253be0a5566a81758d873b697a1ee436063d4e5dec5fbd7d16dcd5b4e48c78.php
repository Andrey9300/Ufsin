<?php

/* fkuz/createVidDeyatelnosti.html.twig */
class __TwigTemplate_df0756a180adc52110d4b0870905e2ee24a22122ebbaeaa3f2be63dfc145244e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "fkuz/createVidDeyatelnosti.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80df576efa604d9cdee85bd2fb4954ad9edcc124fe7746b495121f1adf76856b = $this->env->getExtension("native_profiler");
        $__internal_80df576efa604d9cdee85bd2fb4954ad9edcc124fe7746b495121f1adf76856b->enter($__internal_80df576efa604d9cdee85bd2fb4954ad9edcc124fe7746b495121f1adf76856b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "fkuz/createVidDeyatelnosti.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_80df576efa604d9cdee85bd2fb4954ad9edcc124fe7746b495121f1adf76856b->leave($__internal_80df576efa604d9cdee85bd2fb4954ad9edcc124fe7746b495121f1adf76856b_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_361a0ccada3d143098909b1cd601745bc8c60bcddd288e5001dc59094f0f178a = $this->env->getExtension("native_profiler");
        $__internal_361a0ccada3d143098909b1cd601745bc8c60bcddd288e5001dc59094f0f178a->enter($__internal_361a0ccada3d143098909b1cd601745bc8c60bcddd288e5001dc59094f0f178a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<h1>Добавить вид деятельности</h1>

";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

<div class=\"row\">
    <div class=\"col-md-4\">
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label', array("label" => "Наименование"));
        echo "
        ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "     
    </div>
</div>

<div class=\"row\">
    <div class=\"col-md-4\">
        <input type=\"submit\" value=\"Добавить\" class=\"btn btn-success add_button\" />
    </div>
</div>

";
        
        $__internal_361a0ccada3d143098909b1cd601745bc8c60bcddd288e5001dc59094f0f178a->leave($__internal_361a0ccada3d143098909b1cd601745bc8c60bcddd288e5001dc59094f0f178a_prof);

    }

    // line 24
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_be4361fe738290cbf8c72144d82e6604357e6409bde12c9a7467b73b83d04130 = $this->env->getExtension("native_profiler");
        $__internal_be4361fe738290cbf8c72144d82e6604357e6409bde12c9a7467b73b83d04130->enter($__internal_be4361fe738290cbf8c72144d82e6604357e6409bde12c9a7467b73b83d04130_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 25
        echo "
";
        
        $__internal_be4361fe738290cbf8c72144d82e6604357e6409bde12c9a7467b73b83d04130->leave($__internal_be4361fe738290cbf8c72144d82e6604357e6409bde12c9a7467b73b83d04130_prof);

    }

    public function getTemplateName()
    {
        return "fkuz/createVidDeyatelnosti.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 25,  75 => 24,  57 => 12,  53 => 11,  46 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <h1>Добавить вид деятельности</h1>*/
/* */
/* {{ form_start(form) }}*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         {{ form_label(form.name, 'Наименование') }}*/
/*         {{ form_widget(form.name, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}     */
/*     </div>*/
/* </div>*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         <input type="submit" value="Добавить" class="btn btn-success add_button" />*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
