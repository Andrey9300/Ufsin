<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_b313f6bee973338c3a1f3434f022b7602dc3619f97cd1426f9af84f517a12fd7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b95002590d6026034c9b73bbc50c775e18af5d65f414aecc631b658579bc6dfd = $this->env->getExtension("native_profiler");
        $__internal_b95002590d6026034c9b73bbc50c775e18af5d65f414aecc631b658579bc6dfd->enter($__internal_b95002590d6026034c9b73bbc50c775e18af5d65f414aecc631b658579bc6dfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_b95002590d6026034c9b73bbc50c775e18af5d65f414aecc631b658579bc6dfd->leave($__internal_b95002590d6026034c9b73bbc50c775e18af5d65f414aecc631b658579bc6dfd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
