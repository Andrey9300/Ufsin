<?php

/* :otchet/ajax:zabolevaniya_common.html.twig */
class __TwigTemplate_77b2f87e7d4388bff2cd648e6ec051aeebffbd9f63a3888da67b99d2c9d2ca33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_77f918a4ac9e65c58b3b82980e93ab7c0f947059c8b2c250fd2589bf2eac9c57 = $this->env->getExtension("native_profiler");
        $__internal_77f918a4ac9e65c58b3b82980e93ab7c0f947059c8b2c250fd2589bf2eac9c57->enter($__internal_77f918a4ac9e65c58b3b82980e93ab7c0f947059c8b2c250fd2589bf2eac9c57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:zabolevaniya_common.html.twig"));

        // line 1
        echo "<table class=\"table table-hover table-bordered numbers\">
    <thead>
        <tr>
            <td>Учреждение</td>
            <td id=\"zabolevaniya\">Количество</td>
        </tr>
    </thead>
    <tbody>

    ";
        // line 10
        $context["flag"] = "0";
        // line 11
        echo "
    ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 13
            echo "        <tr  class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
            <td class=\"name\">";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
            echo "</td>

                ";
            // line 16
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["onOrganization"]) ? $context["onOrganization"] : $this->getContext($context, "onOrganization")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["quantity"]) {
                // line 17
                echo "                
                    ";
                // line 18
                if (($this->getAttribute($context["quantity"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 19
                    echo "                    
                        <td  class=\"pokazatel";
                    // line 20
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["quantity"], 1, array(), "array"), "html", null, true);
                    echo "</td>
                        ";
                    // line 21
                    $context["flag"] = "1";
                    // line 22
                    echo "
                    ";
                }
                // line 24
                echo "
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['quantity'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "                
                ";
            // line 27
            if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                // line 28
                echo "                    <td></td>
                ";
            }
            // line 30
            echo "                ";
            $context["flag"] = "0";
            // line 31
            echo "        </tr> 
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "    </tbody>
    <tfoot>
        <tr>
            <td>Всего</td>
            <td id=\"vsego_zabolevchih\"></td>
        </tr>
    </tfoot>
</table>";
        
        $__internal_77f918a4ac9e65c58b3b82980e93ab7c0f947059c8b2c250fd2589bf2eac9c57->leave($__internal_77f918a4ac9e65c58b3b82980e93ab7c0f947059c8b2c250fd2589bf2eac9c57_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:zabolevaniya_common.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 33,  129 => 31,  126 => 30,  122 => 28,  120 => 27,  117 => 26,  102 => 24,  98 => 22,  96 => 21,  90 => 20,  87 => 19,  85 => 18,  82 => 17,  65 => 16,  60 => 14,  55 => 13,  38 => 12,  35 => 11,  33 => 10,  22 => 1,);
    }
}
/* <table class="table table-hover table-bordered numbers">*/
/*     <thead>*/
/*         <tr>*/
/*             <td>Учреждение</td>*/
/*             <td id="zabolevaniya">Количество</td>*/
/*         </tr>*/
/*     </thead>*/
/*     <tbody>*/
/* */
/*     {% set flag = "0" %}*/
/* */
/*     {% for organization in organizations %}*/
/*         <tr  class="pokazatels{{loop.index}}">*/
/*             <td class="name">{{organization.nameShort}}</td>*/
/* */
/*                 {% for quantity in onOrganization %}*/
/*                 */
/*                     {% if quantity.name_full == organization.nameFull %}*/
/*                     */
/*                         <td  class="pokazatel{{loop.parent.loop.index}}">{{quantity[1]}}</td>*/
/*                         {% set flag = "1" %}*/
/* */
/*                     {% endif %}*/
/* */
/*                 {% endfor %}*/
/*                 */
/*                 {% if flag == "0" %}*/
/*                     <td></td>*/
/*                 {% endif %}*/
/*                 {% set flag = "0" %}*/
/*         </tr> */
/*     {% endfor %}*/
/*     </tbody>*/
/*     <tfoot>*/
/*         <tr>*/
/*             <td>Всего</td>*/
/*             <td id="vsego_zabolevchih"></td>*/
/*         </tr>*/
/*     </tfoot>*/
/* </table>*/
