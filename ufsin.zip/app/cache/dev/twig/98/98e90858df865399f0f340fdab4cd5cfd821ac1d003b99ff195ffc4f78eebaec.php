<?php

/* otchet/ajax/proverka_menu.html */
class __TwigTemplate_768de611be225a169830705c2d264b416614282ddb15462f9d1c03874020f494 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c349bd8c21b7a1ace66412c061aee95c1995c7a04a65db70f7357e9b3214d78b = $this->env->getExtension("native_profiler");
        $__internal_c349bd8c21b7a1ace66412c061aee95c1995c7a04a65db70f7357e9b3214d78b->enter($__internal_c349bd8c21b7a1ace66412c061aee95c1995c7a04a65db70f7357e9b3214d78b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/ajax/proverka_menu.html"));

        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetProverka/common\">Общее число проверок</a></li>
        <li><a href=\"/otchetProverka/narusheniya\">Нарушения по проверкам</a></li>
        <li><a href=\"/otchetProverka/narusheniyaObj\">Нарушения по объектам</a></li>
        <li><a href=\"/otchetProverka/nakazaniya\">Наказаниям</a></li>      
        <li><a href=\"/otchetProverka/narusheniyaAll\">Нарушения по всем учреждениям</a></li>      
        <li><a href=\"/otchetProverka/proverkaNakazaniya\">Сотрудники привлеченные к назазанию</a></li>
        <li><a href=\"/otchetProverka/proverkaNevyp\">Невыполненные нарушения</a></li>
        <li><a href=\"/otchetProverka/proverkaNarusheniyaVnimanie\">Нарушения требующие особого внимания</a></li>
    </ul>
</div>";
        
        $__internal_c349bd8c21b7a1ace66412c061aee95c1995c7a04a65db70f7357e9b3214d78b->leave($__internal_c349bd8c21b7a1ace66412c061aee95c1995c7a04a65db70f7357e9b3214d78b_prof);

    }

    public function getTemplateName()
    {
        return "otchet/ajax/proverka_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetProverka/common">Общее число проверок</a></li>*/
/*         <li><a href="/otchetProverka/narusheniya">Нарушения по проверкам</a></li>*/
/*         <li><a href="/otchetProverka/narusheniyaObj">Нарушения по объектам</a></li>*/
/*         <li><a href="/otchetProverka/nakazaniya">Наказаниям</a></li>      */
/*         <li><a href="/otchetProverka/narusheniyaAll">Нарушения по всем учреждениям</a></li>      */
/*         <li><a href="/otchetProverka/proverkaNakazaniya">Сотрудники привлеченные к назазанию</a></li>*/
/*         <li><a href="/otchetProverka/proverkaNevyp">Невыполненные нарушения</a></li>*/
/*         <li><a href="/otchetProverka/proverkaNarusheniyaVnimanie">Нарушения требующие особого внимания</a></li>*/
/*     </ul>*/
/* </div>*/
