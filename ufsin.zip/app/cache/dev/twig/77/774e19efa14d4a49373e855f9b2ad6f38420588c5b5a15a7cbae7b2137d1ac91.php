<?php

/* zabolevaniya/showLichnyiSostavs.html.twig */
class __TwigTemplate_7c3148fc54eb457c9b4c97fc67c4a5eae7af1f69eded027379edd5d1f608e126 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "zabolevaniya/showLichnyiSostavs.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<div class=\"row\">
    <h1>Выберите заболевшего личного состава:</h1>
</div>

<div class=\"row\" style=\"margin-bottom:50px\">
    <form class=\"has-validation-callback\" method=\"post\" action=\"/zabolevaniya/showLichnyiSostavs\" >
        <div class=\"col-md-3\">
            <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
            <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : null), "html", null, true);
        echo "\">
        </div><div class=\"col-md-3\">
            <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
            <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : null), "html", null, true);
        echo "\">
        </div>
        <div class=\"col-md-3\" style=\"margin-top:25px\">
            <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
        </div>
        <div class=\"col-md-3\" style=\"margin-top:45px\">
            <a href=\"/zabolevaniya/createZabolevanieLichnyi\" style=\"font-size:18px\">Добавить нового заболевшего</a>
        </div>
    </form>

    ";
        // line 26
        if (twig_test_empty((isset($context["lichnyiSostavs"]) ? $context["lichnyiSostavs"] : null))) {
            // line 27
            echo "        <p>Нет заболевших в данный период</p>
    ";
        } else {
            // line 29
            echo "
        <table class=\"table table-hover main table-bordered\">
            <thead>
                <tr>
                    <td>ФИО</td>
                    <td>Дата рождения</td>
                    <td><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></td>
                    <td><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></td>
                </tr>
            </thead>
            <tbody>
            ";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["lichnyiSostavs"]) ? $context["lichnyiSostavs"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["lichnyiSostav"]) {
                // line 41
                echo "                <tr>
                    <td><a href=\"/zabolevaniya/lichnyi/";
                // line 42
                echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "fio", array()), "html", null, true);
                echo "</a></td>
                    <td>";
                // line 43
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "date_birthday", array()), "d.m.Y"), "html", null, true);
                echo "</td>
                    <td><a href=\"/zabolevaniya/editLichnyiSostav/";
                // line 44
                echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "id", array()), "html", null, true);
                echo "\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></a></td>
                    <td><a href=\"/zabolevaniya/deleteLichnyiSostav/";
                // line 45
                echo twig_escape_filter($this->env, $this->getAttribute($context["lichnyiSostav"], "id", array()), "html", null, true);
                echo "\" class=\"delete_entity\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></a></td>
                </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['lichnyiSostav'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 48
            echo "            </tbody>
        </table>
    ";
        }
        // line 51
        echo "</div>

";
    }

    // line 55
    public function block_sidebar($context, array $blocks = array())
    {
        // line 56
        echo "
";
    }

    public function getTemplateName()
    {
        return "zabolevaniya/showLichnyiSostavs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 56,  122 => 55,  116 => 51,  111 => 48,  102 => 45,  98 => 44,  94 => 43,  88 => 42,  85 => 41,  81 => 40,  68 => 29,  64 => 27,  62 => 26,  49 => 16,  43 => 13,  32 => 4,  29 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <h1>Выберите заболевшего личного состава:</h1>*/
/* </div>*/
/* */
/* <div class="row" style="margin-bottom:50px">*/
/*     <form class="has-validation-callback" method="post" action="/zabolevaniya/showLichnyiSostavs" >*/
/*         <div class="col-md-3">*/
/*             <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*             <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*         </div><div class="col-md-3">*/
/*             <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*             <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*         </div>*/
/*         <div class="col-md-3" style="margin-top:25px">*/
/*             <input type="submit" class="btn btn-success" value="Выбрать">*/
/*         </div>*/
/*         <div class="col-md-3" style="margin-top:45px">*/
/*             <a href="/zabolevaniya/createZabolevanieLichnyi" style="font-size:18px">Добавить нового заболевшего</a>*/
/*         </div>*/
/*     </form>*/
/* */
/*     {% if lichnyiSostavs is empty%}*/
/*         <p>Нет заболевших в данный период</p>*/
/*     {% else %}*/
/* */
/*         <table class="table table-hover main table-bordered">*/
/*             <thead>*/
/*                 <tr>*/
/*                     <td>ФИО</td>*/
/*                     <td>Дата рождения</td>*/
/*                     <td><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></td>*/
/*                     <td><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>*/
/*                 </tr>*/
/*             </thead>*/
/*             <tbody>*/
/*             {% for lichnyiSostav in lichnyiSostavs %}*/
/*                 <tr>*/
/*                     <td><a href="/zabolevaniya/lichnyi/{{ lichnyiSostav.id }}">{{ lichnyiSostav.fio }}</a></td>*/
/*                     <td>{{lichnyiSostav.date_birthday|date("d.m.Y") }}</td>*/
/*                     <td><a href="/zabolevaniya/editLichnyiSostav/{{ lichnyiSostav.id }}"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></td>*/
/*                     <td><a href="/zabolevaniya/deleteLichnyiSostav/{{ lichnyiSostav.id }}" class="delete_entity"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>*/
/*                 </tr>*/
/*             {% endfor %}*/
/*             </tbody>*/
/*         </table>*/
/*     {% endif %}*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
