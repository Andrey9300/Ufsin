<?php

/* otchet/index.html.twig */
class __TwigTemplate_49296d8c3872576ad427234e0ff207ceaeac3a72a036a713d938362fa11a389f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "otchet/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7143b0b9177309eb273d766084cf98c99086112c4cda8797f459d4169f29db91 = $this->env->getExtension("native_profiler");
        $__internal_7143b0b9177309eb273d766084cf98c99086112c4cda8797f459d4169f29db91->enter($__internal_7143b0b9177309eb273d766084cf98c99086112c4cda8797f459d4169f29db91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7143b0b9177309eb273d766084cf98c99086112c4cda8797f459d4169f29db91->leave($__internal_7143b0b9177309eb273d766084cf98c99086112c4cda8797f459d4169f29db91_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_3e65696ac72b4348deb6f18d3205e7fdd0d47e29d8be0ccd1388d812f4dab0b5 = $this->env->getExtension("native_profiler");
        $__internal_3e65696ac72b4348deb6f18d3205e7fdd0d47e29d8be0ccd1388d812f4dab0b5->enter($__internal_3e65696ac72b4348deb6f18d3205e7fdd0d47e29d8be0ccd1388d812f4dab0b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">
    <div id=\"main\" class=\"col-sm-9\">
        <h1>Все отчеты</h1>
    </div>
</div>

";
        
        $__internal_3e65696ac72b4348deb6f18d3205e7fdd0d47e29d8be0ccd1388d812f4dab0b5->leave($__internal_3e65696ac72b4348deb6f18d3205e7fdd0d47e29d8be0ccd1388d812f4dab0b5_prof);

    }

    // line 13
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_75f0d3fcfc0e1b9acf2802cf30289ff27f6f27af6030da96e84fc61ddffda0ac = $this->env->getExtension("native_profiler");
        $__internal_75f0d3fcfc0e1b9acf2802cf30289ff27f6f27af6030da96e84fc61ddffda0ac->enter($__internal_75f0d3fcfc0e1b9acf2802cf30289ff27f6f27af6030da96e84fc61ddffda0ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 14
        echo "
";
        
        $__internal_75f0d3fcfc0e1b9acf2802cf30289ff27f6f27af6030da96e84fc61ddffda0ac->leave($__internal_75f0d3fcfc0e1b9acf2802cf30289ff27f6f27af6030da96e84fc61ddffda0ac_prof);

    }

    public function getTemplateName()
    {
        return "otchet/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 14,  55 => 13,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <div id="main" class="col-sm-9">*/
/*         <h1>Все отчеты</h1>*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
