<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_b10dd336bb76d0a7aeae60f3c9b698a28e9d75bd3c28dd7222bd70f46c543a33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_887ad8b05ace8948b62ebe06717c3585fd33446d244e89e7d1de64cf2b125886 = $this->env->getExtension("native_profiler");
        $__internal_887ad8b05ace8948b62ebe06717c3585fd33446d244e89e7d1de64cf2b125886->enter($__internal_887ad8b05ace8948b62ebe06717c3585fd33446d244e89e7d1de64cf2b125886_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_887ad8b05ace8948b62ebe06717c3585fd33446d244e89e7d1de64cf2b125886->leave($__internal_887ad8b05ace8948b62ebe06717c3585fd33446d244e89e7d1de64cf2b125886_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
