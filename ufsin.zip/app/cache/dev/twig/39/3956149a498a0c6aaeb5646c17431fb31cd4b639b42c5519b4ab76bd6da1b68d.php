<?php

/* :otchet/ajax:proverka_nakazanie_podch.html.twig */
class __TwigTemplate_66be390e673333805225914d738630bc2adae7a1e8e4614cf88d17f2154c0d56 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fa9960f4671395a19a4d062e98ba98f24a38221bf1ee865610f4dae0c506fca = $this->env->getExtension("native_profiler");
        $__internal_2fa9960f4671395a19a4d062e98ba98f24a38221bf1ee865610f4dae0c506fca->enter($__internal_2fa9960f4671395a19a4d062e98ba98f24a38221bf1ee865610f4dae0c506fca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet/ajax:proverka_nakazanie_podch.html.twig"));

        // line 1
        echo "<div class=\"row\">
    <table class=\"table table-hover table-bordered numbers\">
        <thead>
            <tr>
                <td></td>
                <td style=\"font-size:12px\">Аттестованные</td>
                <td style=\"font-size:12px\">Вольные</td>
                <td style=\"font-size:12px\">Итог</td>
            </tr>
        </thead>
        <tbody>
        
        ";
        // line 13
        $context["flag1"] = "0";
        // line 14
        echo "        ";
        $context["flag2"] = "0";
        // line 15
        echo "
        ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
            // line 17
            echo "            <tr class=\"pokazatels";
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\">
                <td class=\"name\">";
            // line 18
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["organization"], "nameShort", array()), 3, 7), "html", null, true);
            echo "</td>

                    ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaPeoAtt"]) ? $context["narusheniyaPeoAtt"] : $this->getContext($context, "narusheniyaPeoAtt")));
            foreach ($context['_seq'] as $context["_key"] => $context["people"]) {
                // line 21
                echo "                    
                        ";
                // line 22
                if (($this->getAttribute($context["people"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 23
                    echo "                        <td class=\"pokazatel1\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["people"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 24
                    $context["flag1"] = "1";
                    // line 25
                    echo "                        ";
                }
                // line 26
                echo "                        
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['people'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 28
            echo "                    
                    ";
            // line 29
            if (((isset($context["flag1"]) ? $context["flag1"] : $this->getContext($context, "flag1")) == "0")) {
                // line 30
                echo "                        <td></td>
                    ";
            }
            // line 32
            echo "                    ";
            $context["flag1"] = "0";
            // line 33
            echo "                    
                    ";
            // line 34
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["narusheniyaPeoVol"]) ? $context["narusheniyaPeoVol"] : $this->getContext($context, "narusheniyaPeoVol")));
            foreach ($context['_seq'] as $context["_key"] => $context["people"]) {
                // line 35
                echo "                    
                        ";
                // line 36
                if (($this->getAttribute($context["people"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                    // line 37
                    echo "                        <td class=\"pokazatel2\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["people"], 1, array()), "html", null, true);
                    echo "</td>
                        ";
                    // line 38
                    $context["flag2"] = "1";
                    // line 39
                    echo "                        ";
                }
                // line 40
                echo "                        
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['people'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 42
            echo "                    
                    ";
            // line 43
            if (((isset($context["flag2"]) ? $context["flag2"] : $this->getContext($context, "flag2")) == "0")) {
                // line 44
                echo "                        <td></td>
                    ";
            }
            // line 46
            echo "                    ";
            $context["flag2"] = "0";
            // line 47
            echo "                    
                    <td></td>
            </tr> 
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "        </tbody>
        <tfoot>
            <tr>
                <td>Всего</td>
                <td id=\"result1\"></td>
                <td id=\"result2\"></td>
                <td id=\"vsego\"></td>
            </tr>  
        </tfoot>
    </table>
</div>";
        
        $__internal_2fa9960f4671395a19a4d062e98ba98f24a38221bf1ee865610f4dae0c506fca->leave($__internal_2fa9960f4671395a19a4d062e98ba98f24a38221bf1ee865610f4dae0c506fca_prof);

    }

    public function getTemplateName()
    {
        return ":otchet/ajax:proverka_nakazanie_podch.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 51,  150 => 47,  147 => 46,  143 => 44,  141 => 43,  138 => 42,  131 => 40,  128 => 39,  126 => 38,  121 => 37,  119 => 36,  116 => 35,  112 => 34,  109 => 33,  106 => 32,  102 => 30,  100 => 29,  97 => 28,  90 => 26,  87 => 25,  85 => 24,  80 => 23,  78 => 22,  75 => 21,  71 => 20,  66 => 18,  61 => 17,  44 => 16,  41 => 15,  38 => 14,  36 => 13,  22 => 1,);
    }
}
/* <div class="row">*/
/*     <table class="table table-hover table-bordered numbers">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td></td>*/
/*                 <td style="font-size:12px">Аттестованные</td>*/
/*                 <td style="font-size:12px">Вольные</td>*/
/*                 <td style="font-size:12px">Итог</td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         */
/*         {% set flag1= "0" %}*/
/*         {% set flag2 = "0" %}*/
/* */
/*         {% for organization in organizations %}*/
/*             <tr class="pokazatels{{loop.index}}">*/
/*                 <td class="name">{{ organization.nameShort|slice(3,7) }}</td>*/
/* */
/*                     {% for people in narusheniyaPeoAtt %}*/
/*                     */
/*                         {% if people.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel1">{{ people.1 }}</td>*/
/*                         {% set flag1 = "1" %}*/
/*                         {% endif %}*/
/*                         */
/*                     {% endfor %}*/
/*                     */
/*                     {% if flag1 == "0" %}*/
/*                         <td></td>*/
/*                     {% endif %}*/
/*                     {% set flag1 = "0" %}*/
/*                     */
/*                     {% for people in narusheniyaPeoVol %}*/
/*                     */
/*                         {% if people.name_full == organization.nameFull %}*/
/*                         <td class="pokazatel2">{{ people.1 }}</td>*/
/*                         {% set flag2 = "1" %}*/
/*                         {% endif %}*/
/*                         */
/*                     {% endfor %}*/
/*                     */
/*                     {% if flag2 == "0" %}*/
/*                         <td></td>*/
/*                     {% endif %}*/
/*                     {% set flag2 = "0" %}*/
/*                     */
/*                     <td></td>*/
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*         <tfoot>*/
/*             <tr>*/
/*                 <td>Всего</td>*/
/*                 <td id="result1"></td>*/
/*                 <td id="result2"></td>*/
/*                 <td id="vsego"></td>*/
/*             </tr>  */
/*         </tfoot>*/
/*     </table>*/
/* </div>*/
