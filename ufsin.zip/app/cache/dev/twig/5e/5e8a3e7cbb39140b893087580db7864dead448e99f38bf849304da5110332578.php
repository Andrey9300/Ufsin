<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_b9860edeb16d191a60227487678e8806b9f2785afdd0d1b539ae6fa010c35a2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ff36fcea6b8497b1fb0975c506c2cd753fd51a56caf025cd61371ed767f2e56 = $this->env->getExtension("native_profiler");
        $__internal_9ff36fcea6b8497b1fb0975c506c2cd753fd51a56caf025cd61371ed767f2e56->enter($__internal_9ff36fcea6b8497b1fb0975c506c2cd753fd51a56caf025cd61371ed767f2e56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_9ff36fcea6b8497b1fb0975c506c2cd753fd51a56caf025cd61371ed767f2e56->leave($__internal_9ff36fcea6b8497b1fb0975c506c2cd753fd51a56caf025cd61371ed767f2e56_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
