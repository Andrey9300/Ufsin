<?php

/* :otchet:proverkaNarusheniyaVnimanie.html.twig */
class __TwigTemplate_95c3962f6e7f9c2eba8c7c615f9b495092b801f94132971a554e4ac6450ebcd0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":otchet:proverkaNarusheniyaVnimanie.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49616a3eaadb462db88c8839ff54886e0fe886aeaecbaf1cfbecf109733991c8 = $this->env->getExtension("native_profiler");
        $__internal_49616a3eaadb462db88c8839ff54886e0fe886aeaecbaf1cfbecf109733991c8->enter($__internal_49616a3eaadb462db88c8839ff54886e0fe886aeaecbaf1cfbecf109733991c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":otchet:proverkaNarusheniyaVnimanie.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_49616a3eaadb462db88c8839ff54886e0fe886aeaecbaf1cfbecf109733991c8->leave($__internal_49616a3eaadb462db88c8839ff54886e0fe886aeaecbaf1cfbecf109733991c8_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_a0e22020c0f4ade08bfbd836fd701f3517ae1e454cefa686a20ae894be5a2b0e = $this->env->getExtension("native_profiler");
        $__internal_a0e22020c0f4ade08bfbd836fd701f3517ae1e454cefa686a20ae894be5a2b0e->enter($__internal_a0e22020c0f4ade08bfbd836fd701f3517ae1e454cefa686a20ae894be5a2b0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/proverka_menu.html", ":otchet:proverkaNarusheniyaVnimanie.html.twig", 5)->display($context);
        // line 6
        echo "    <div class=\"row\">
        <h3>Нарушения требующие особого внимания</h3>

        <div class=\"row\" style=\"margin-bottom:50px\">
            <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetProverka/proverkaNarusheniyaVnimanie\">
                <div class=\"col-md-3\">
                    <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                    <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
                </div><div class=\"col-md-3\">
                    <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                    <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
                </div>
                <div class=\"col-md-3\" style=\"margin-top:25px\">
                    <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
                </div>
            </form>
        </div>

        <table class=\"table table-hover main narusheniyaOrganization\">
            <thead>
            <tr>
                <td>УК</td>
                <td>Объект</td>
                <td>Описание</td>
                <td>Дата устранения</td>
                <td>Затраты</td>
                <td>Отметка устранения</td>
            </tr>
            </thead>
            <tbody>
            ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverkaNarusheniyaVnimanie"]) ? $context["proverkaNarusheniyaVnimanie"] : $this->getContext($context, "proverkaNarusheniyaVnimanie")));
        foreach ($context['_seq'] as $context["_key"] => $context["proverka"]) {
            // line 37
            echo "                <tr>
                    <td>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "name_short", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "name", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "description", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["proverka"], "date_ustraneniya", array()), "d.m.Y"), "html", null, true);
            echo "</td>
                    <td>";
            // line 42
            if (($this->getAttribute($context["proverka"], "zatraty", array()) == "1")) {
                // line 43
                echo "                            Требует больших затрат
                        ";
            } elseif (($this->getAttribute(            // line 44
$context["proverka"], "zatraty", array()) == "0")) {
                // line 45
                echo "                            Требует затрат
                        ";
            } elseif (($this->getAttribute(            // line 46
$context["proverka"], "zatraty", array()) == "-1")) {
                // line 47
                echo "                            Не требует затрат
                        ";
            }
            // line 49
            echo "                    </td>
                    <td>
                        <select class=\"form-control otmetka\">
                            ";
            // line 52
            if (($this->getAttribute($context["proverka"], "otmetka_ustraneniya", array()) == "0")) {
                // line 53
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                                <option id=\"";
                // line 54
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 55
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 56
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                            ";
            } elseif (($this->getAttribute(            // line 57
$context["proverka"], "otmetka_ustraneniya", array()) == "-1")) {
                // line 58
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 59
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                                <option id=\"";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                            ";
            } elseif (($this->getAttribute(            // line 62
$context["proverka"], "otmetka_ustraneniya", array()) == "1")) {
                // line 63
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 64
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                                <option id=\"";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                            ";
            } elseif (($this->getAttribute(            // line 67
$context["proverka"], "otmetka_ustraneniya", array()) == "2")) {
                // line 68
                echo "                                <option id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"2\">Устранено в ходе проверки</option>
                                <option id=\"";
                // line 69
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"1\">Да</option>
                                <option id=\"";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"-1\">Частично</option>
                                <option id=\"";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" otmetka=\"0\">Нет</option>
                            ";
            }
            // line 73
            echo "                        </select>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['proverka'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "            </tbody>
        </table>
    </div>

";
        
        $__internal_a0e22020c0f4ade08bfbd836fd701f3517ae1e454cefa686a20ae894be5a2b0e->leave($__internal_a0e22020c0f4ade08bfbd836fd701f3517ae1e454cefa686a20ae894be5a2b0e_prof);

    }

    // line 83
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_e42a0ddf958532a222fd2fe99d4ab9851083257f84fa4afef40cad68b4e8ad3a = $this->env->getExtension("native_profiler");
        $__internal_e42a0ddf958532a222fd2fe99d4ab9851083257f84fa4afef40cad68b4e8ad3a->enter($__internal_e42a0ddf958532a222fd2fe99d4ab9851083257f84fa4afef40cad68b4e8ad3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 84
        echo "
";
        
        $__internal_e42a0ddf958532a222fd2fe99d4ab9851083257f84fa4afef40cad68b4e8ad3a->leave($__internal_e42a0ddf958532a222fd2fe99d4ab9851083257f84fa4afef40cad68b4e8ad3a_prof);

    }

    public function getTemplateName()
    {
        return ":otchet:proverkaNarusheniyaVnimanie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  231 => 84,  225 => 83,  214 => 77,  205 => 73,  200 => 71,  196 => 70,  192 => 69,  187 => 68,  185 => 67,  181 => 66,  177 => 65,  173 => 64,  168 => 63,  166 => 62,  162 => 61,  158 => 60,  154 => 59,  149 => 58,  147 => 57,  143 => 56,  139 => 55,  135 => 54,  130 => 53,  128 => 52,  123 => 49,  119 => 47,  117 => 46,  114 => 45,  112 => 44,  109 => 43,  107 => 42,  103 => 41,  99 => 40,  95 => 39,  91 => 38,  88 => 37,  84 => 36,  61 => 16,  55 => 13,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/proverka_menu.html' %}*/
/*     <div class="row">*/
/*         <h3>Нарушения требующие особого внимания</h3>*/
/* */
/*         <div class="row" style="margin-bottom:50px">*/
/*             <form class="has-validation-callback" method="post" action="/otchetProverka/proverkaNarusheniyaVnimanie">*/
/*                 <div class="col-md-3">*/
/*                     <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                     <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*                 </div><div class="col-md-3">*/
/*                     <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                     <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*                 </div>*/
/*                 <div class="col-md-3" style="margin-top:25px">*/
/*                     <input type="submit" class="btn btn-success" value="Выбрать">*/
/*                 </div>*/
/*             </form>*/
/*         </div>*/
/* */
/*         <table class="table table-hover main narusheniyaOrganization">*/
/*             <thead>*/
/*             <tr>*/
/*                 <td>УК</td>*/
/*                 <td>Объект</td>*/
/*                 <td>Описание</td>*/
/*                 <td>Дата устранения</td>*/
/*                 <td>Затраты</td>*/
/*                 <td>Отметка устранения</td>*/
/*             </tr>*/
/*             </thead>*/
/*             <tbody>*/
/*             {% for proverka in proverkaNarusheniyaVnimanie %}*/
/*                 <tr>*/
/*                     <td>{{ proverka.name_short }}</td>*/
/*                     <td>{{ proverka.name }}</td>*/
/*                     <td>{{ proverka.description }}</td>*/
/*                     <td>{{ proverka.date_ustraneniya|date("d.m.Y") }}</td>*/
/*                     <td>{% if proverka.zatraty == "1" %}*/
/*                             Требует больших затрат*/
/*                         {% elseif proverka.zatraty == "0" %}*/
/*                             Требует затрат*/
/*                         {% elseif proverka.zatraty == "-1" %}*/
/*                             Не требует затрат*/
/*                         {% endif %}*/
/*                     </td>*/
/*                     <td>*/
/*                         <select class="form-control otmetka">*/
/*                             {% if proverka.otmetka_ustraneniya == "0" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                             {% elseif proverka.otmetka_ustraneniya == "-1" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                             {% elseif proverka.otmetka_ustraneniya == "1" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                             {% elseif proverka.otmetka_ustraneniya == "2" %}*/
/*                                 <option id="{{ proverka.id }}" otmetka="2">Устранено в ходе проверки</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="1">Да</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="-1">Частично</option>*/
/*                                 <option id="{{ proverka.id }}" otmetka="0">Нет</option>*/
/*                             {% endif %}*/
/*                         </select>*/
/*                     </td>*/
/*                 </tr>*/
/*             {% endfor %}*/
/*             </tbody>*/
/*         </table>*/
/*     </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
