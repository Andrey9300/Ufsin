<?php

/* :fkuz:allFilialNames.html.twig */
class __TwigTemplate_66c3b030ca7fbc57b6f69d4d12bff7c4034cccf59cecfcf14a93d0543fd47930 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae866207cfb11b2b3eb6489e73a7244235996c9e6ce89142540c6bb5d5338e1d = $this->env->getExtension("native_profiler");
        $__internal_ae866207cfb11b2b3eb6489e73a7244235996c9e6ce89142540c6bb5d5338e1d->enter($__internal_ae866207cfb11b2b3eb6489e73a7244235996c9e6ce89142540c6bb5d5338e1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":fkuz:allFilialNames.html.twig"));

        // line 1
        echo "<ul class=\"dropdown-menu\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["filialNames"]) ? $context["filialNames"] : $this->getContext($context, "filialNames")));
        foreach ($context['_seq'] as $context["_key"] => $context["filial"]) {
            // line 3
            echo "        <li><a href=\"/fkuz/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["filial"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["filial"], "nameShort", array()), "html", null, true);
            echo "</a></li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['filial'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 5
        echo "</ul>";
        
        $__internal_ae866207cfb11b2b3eb6489e73a7244235996c9e6ce89142540c6bb5d5338e1d->leave($__internal_ae866207cfb11b2b3eb6489e73a7244235996c9e6ce89142540c6bb5d5338e1d_prof);

    }

    public function getTemplateName()
    {
        return ":fkuz:allFilialNames.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 5,  29 => 3,  25 => 2,  22 => 1,);
    }
}
/* <ul class="dropdown-menu">*/
/*     {% for filial in filialNames %}*/
/*         <li><a href="/fkuz/{{filial.id}}">{{filial.nameShort}}</a></li>*/
/*     {% endfor %}*/
/* </ul>*/
