<?php

/* :zabolevaniya:showOchags.html.twig */
class __TwigTemplate_cc5c06ac353914e06c15a9b43b6eae6bc8f938e64e0bce06deb1c96e90cc79d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":zabolevaniya:showOchags.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1db43c229c0eaa06f925f4bf1bd556a661ae6b87facc16910d1403b918c081c6 = $this->env->getExtension("native_profiler");
        $__internal_1db43c229c0eaa06f925f4bf1bd556a661ae6b87facc16910d1403b918c081c6->enter($__internal_1db43c229c0eaa06f925f4bf1bd556a661ae6b87facc16910d1403b918c081c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":zabolevaniya:showOchags.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1db43c229c0eaa06f925f4bf1bd556a661ae6b87facc16910d1403b918c081c6->leave($__internal_1db43c229c0eaa06f925f4bf1bd556a661ae6b87facc16910d1403b918c081c6_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_74733e25184048be6d43af5c08770936bcbc7608f6d135fa2361ca5431646ed6 = $this->env->getExtension("native_profiler");
        $__internal_74733e25184048be6d43af5c08770936bcbc7608f6d135fa2361ca5431646ed6->enter($__internal_74733e25184048be6d43af5c08770936bcbc7608f6d135fa2361ca5431646ed6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">
    <h1>Выберите очаг:</h1>
</div>

<div class=\"row\" style=\"margin-bottom:50px\">
    <form class=\"has-validation-callback\" method=\"post\" action=\"/zabolevaniya/showOchags\" >
        <div class=\"col-md-3\">
            <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
            <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
        </div><div class=\"col-md-3\">
            <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
            <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
        </div>
        <div class=\"col-md-3\" style=\"margin-top:25px\">
            <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
        </div>
        <div class=\"col-md-3\" style=\"margin-top:45px\">
            <a href=\"/zabolevaniya/createZabolevanieOchag\" style=\"font-size:18px\">Добавить очаг</a>
        </div>    
    </form>    
</div>

<div class=\"row\">
    <table class=\"table table-hover main table-bordered\">
        <thead>
            <tr>
                <td>Название</td>
                <td>Место</td>
                <td>Дата </td>
                <td><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></td>
                <td><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></td>
            </tr>
        </thead>
        <tbody>
        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ochags"]) ? $context["ochags"] : $this->getContext($context, "ochags")));
        foreach ($context['_seq'] as $context["_key"] => $context["ochag"]) {
            // line 40
            echo "            <tr>
                <td><a href=\"/zabolevaniya/ochag/";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["ochag"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ochag"], "name", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["ochag"], "place", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["ochag"], "date", array()), "d.m.Y"), "html", null, true);
            echo "</td>
                <td><a href=\"/zabolevaniya/editOchag/";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["ochag"], "id", array()), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></a></td>
\t\t\t\t<td><a href=\"/zabolevaniya/deleteOchag/";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["ochag"], "id", array()), "html", null, true);
            echo "\" class=\"delete_entity\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></a></td>
            </tr> 
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ochag'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "        </tbody>
    </table>
</div>

";
        
        $__internal_74733e25184048be6d43af5c08770936bcbc7608f6d135fa2361ca5431646ed6->leave($__internal_74733e25184048be6d43af5c08770936bcbc7608f6d135fa2361ca5431646ed6_prof);

    }

    // line 54
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_3c64a3949be15ea3be3efd12ed4727122ff9ab786456964a2f49b0746c32b986 = $this->env->getExtension("native_profiler");
        $__internal_3c64a3949be15ea3be3efd12ed4727122ff9ab786456964a2f49b0746c32b986->enter($__internal_3c64a3949be15ea3be3efd12ed4727122ff9ab786456964a2f49b0746c32b986_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 55
        echo "
";
        
        $__internal_3c64a3949be15ea3be3efd12ed4727122ff9ab786456964a2f49b0746c32b986->leave($__internal_3c64a3949be15ea3be3efd12ed4727122ff9ab786456964a2f49b0746c32b986_prof);

    }

    public function getTemplateName()
    {
        return ":zabolevaniya:showOchags.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 55,  129 => 54,  118 => 48,  109 => 45,  105 => 44,  101 => 43,  97 => 42,  91 => 41,  88 => 40,  84 => 39,  58 => 16,  52 => 13,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <h1>Выберите очаг:</h1>*/
/* </div>*/
/* */
/* <div class="row" style="margin-bottom:50px">*/
/*     <form class="has-validation-callback" method="post" action="/zabolevaniya/showOchags" >*/
/*         <div class="col-md-3">*/
/*             <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*             <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*         </div><div class="col-md-3">*/
/*             <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*             <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*         </div>*/
/*         <div class="col-md-3" style="margin-top:25px">*/
/*             <input type="submit" class="btn btn-success" value="Выбрать">*/
/*         </div>*/
/*         <div class="col-md-3" style="margin-top:45px">*/
/*             <a href="/zabolevaniya/createZabolevanieOchag" style="font-size:18px">Добавить очаг</a>*/
/*         </div>    */
/*     </form>    */
/* </div>*/
/* */
/* <div class="row">*/
/*     <table class="table table-hover main table-bordered">*/
/*         <thead>*/
/*             <tr>*/
/*                 <td>Название</td>*/
/*                 <td>Место</td>*/
/*                 <td>Дата </td>*/
/*                 <td><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></td>*/
/*                 <td><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for ochag in ochags %}*/
/*             <tr>*/
/*                 <td><a href="/zabolevaniya/ochag/{{ ochag.id }}">{{ ochag.name }}</a></td>*/
/*                 <td>{{ ochag.place }}</td>*/
/*                 <td>{{ ochag.date|date("d.m.Y") }}</td>*/
/*                 <td><a href="/zabolevaniya/editOchag/{{ ochag.id }}"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></td>*/
/* 				<td><a href="/zabolevaniya/deleteOchag/{{ ochag.id }}" class="delete_entity"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>*/
/*             </tr> */
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
