<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_ae5df3779b33a7a4f50a9629e0cae03ad1f653bef193b1908659190e553dba8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0009b6e41acd5f4ceae7b16ca4b836b28f2588df2e40d94b9b5322ba14392171 = $this->env->getExtension("native_profiler");
        $__internal_0009b6e41acd5f4ceae7b16ca4b836b28f2588df2e40d94b9b5322ba14392171->enter($__internal_0009b6e41acd5f4ceae7b16ca4b836b28f2588df2e40d94b9b5322ba14392171_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_0009b6e41acd5f4ceae7b16ca4b836b28f2588df2e40d94b9b5322ba14392171->leave($__internal_0009b6e41acd5f4ceae7b16ca4b836b28f2588df2e40d94b9b5322ba14392171_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_901849f3f00a70efe8cd1f64f55583d3a12f6c1823fe92e0dcf4e64a9ca7cb34 = $this->env->getExtension("native_profiler");
        $__internal_901849f3f00a70efe8cd1f64f55583d3a12f6c1823fe92e0dcf4e64a9ca7cb34->enter($__internal_901849f3f00a70efe8cd1f64f55583d3a12f6c1823fe92e0dcf4e64a9ca7cb34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_901849f3f00a70efe8cd1f64f55583d3a12f6c1823fe92e0dcf4e64a9ca7cb34->leave($__internal_901849f3f00a70efe8cd1f64f55583d3a12f6c1823fe92e0dcf4e64a9ca7cb34_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
