<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_4fc2e9a325ff0184fc058a1a1f810f8308b58c0351af430f1777683c82349b8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c3ea0b1da7eac8a8a2feb86624e5633dcbf3fa98107d179f1779411d2fd72f3e = $this->env->getExtension("native_profiler");
        $__internal_c3ea0b1da7eac8a8a2feb86624e5633dcbf3fa98107d179f1779411d2fd72f3e->enter($__internal_c3ea0b1da7eac8a8a2feb86624e5633dcbf3fa98107d179f1779411d2fd72f3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_c3ea0b1da7eac8a8a2feb86624e5633dcbf3fa98107d179f1779411d2fd72f3e->leave($__internal_c3ea0b1da7eac8a8a2feb86624e5633dcbf3fa98107d179f1779411d2fd72f3e_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
