<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_dcc63ac5c8833d52a4956ee2a3d988259e0f7d2e8a5df225e747b360c0ecb6ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6e35760ab7b8a3318aed8d9f4d837cf5eb6c5152afb6921d228bc609f7bb47d = $this->env->getExtension("native_profiler");
        $__internal_d6e35760ab7b8a3318aed8d9f4d837cf5eb6c5152afb6921d228bc609f7bb47d->enter($__internal_d6e35760ab7b8a3318aed8d9f4d837cf5eb6c5152afb6921d228bc609f7bb47d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_d6e35760ab7b8a3318aed8d9f4d837cf5eb6c5152afb6921d228bc609f7bb47d->leave($__internal_d6e35760ab7b8a3318aed8d9f4d837cf5eb6c5152afb6921d228bc609f7bb47d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
