<?php

/* otchet/ajax/zabolevaniya_otryad.html.twig */
class __TwigTemplate_98c3a0b9115fa10a5abcfb353724de568335a97bff4a9d222d1df1beb89910ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "otchet/ajax/zabolevaniya_otryad.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9b906f74ded14886a0cd872c4ed36184c7bd0ffb0cf86fad43dd97456d83d8c = $this->env->getExtension("native_profiler");
        $__internal_c9b906f74ded14886a0cd872c4ed36184c7bd0ffb0cf86fad43dd97456d83d8c->enter($__internal_c9b906f74ded14886a0cd872c4ed36184c7bd0ffb0cf86fad43dd97456d83d8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "otchet/ajax/zabolevaniya_otryad.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c9b906f74ded14886a0cd872c4ed36184c7bd0ffb0cf86fad43dd97456d83d8c->leave($__internal_c9b906f74ded14886a0cd872c4ed36184c7bd0ffb0cf86fad43dd97456d83d8c_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_7b69a968377c0676375b38b386ea49612eb5a0f6f41f9a438072a2b41cc847d5 = $this->env->getExtension("native_profiler");
        $__internal_7b69a968377c0676375b38b386ea49612eb5a0f6f41f9a438072a2b41cc847d5->enter($__internal_7b69a968377c0676375b38b386ea49612eb5a0f6f41f9a438072a2b41cc847d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        // line 5
        $this->loadTemplate("views/otchet/ajax/zabolevanie_menu.html", "otchet/ajax/zabolevaniya_otryad.html.twig", 5)->display($context);
        // line 6
        echo "
<div class=\"row\">
    <h3>Статистика заболевших осужденных по отрядам</h3>

    <div class=\"row\" style=\"margin-bottom:50px\">
        <form class=\"has-validation-callback\" method=\"post\" action=\"/otchetZabolevaniya/otryad\" >
            <div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата от (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateOt\" id=\"proverka_date\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["dateOt"]) ? $context["dateOt"] : $this->getContext($context, "dateOt")), "html", null, true);
        echo "\">
            </div><div class=\"col-md-3\">
                <label class=\"required\" for=\"proverka_date\">Дата до (дд.мм.гггг)</label>
                <input type=\"text\" data-validation-format=\"dd.mm.yyyy\" data-validation-optional=\"true\" data-validation=\"date\" class=\"form-control\" required=\"required\" name=\"dateDo\" id=\"proverka_date\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["dateDo"]) ? $context["dateDo"] : $this->getContext($context, "dateDo")), "html", null, true);
        echo "\">
            </div>
            <div class=\"col-md-3\" style=\"margin-top:25px\">
                <input type=\"submit\" class=\"btn btn-success\" value=\"Выбрать\">
            </div>
        </form>
    </div>

    ";
        // line 25
        if (twig_test_empty((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")))) {
            // line 26
            echo "        <p>Не добавлены учреждения</p>
    ";
        } elseif (twig_test_empty(        // line 27
(isset($context["place_progivaniya"]) ? $context["place_progivaniya"] : $this->getContext($context, "place_progivaniya")))) {
            // line 28
            echo "        <p>Не добавлены отряды</p>
    ";
        } elseif (twig_test_empty(        // line 29
(isset($context["osugdeniy"]) ? $context["osugdeniy"] : $this->getContext($context, "osugdeniy")))) {
            // line 30
            echo "        <p>Нет заболевших в выбранный период</p>
    ";
        } else {
            // line 32
            echo "
        ";
            // line 33
            $context["place_progivaniya"] = array(0 => "1 отряд", 1 => "2 отряд", 2 => "3 отряд", 3 => "4 отряд", 4 => "5 отряд", 5 => "6 отряд", 6 => "7 отряд", 7 => "8 отряд", 8 => "9 отряд", 9 => "10 отряд", 10 => "11 отряд", 11 => "12 отряд", 12 => "ПКТ", 13 => "ЕПКТ", 14 => "ОСУОН", 15 => "ШИЗО", 16 => "Карантинное отделение");
            // line 34
            echo "
        <table class=\"table table-hover table-bordered numbers\">
            <thead>
                <tr>
                    <td>Учреждение</td>
                    ";
            // line 39
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["place_progivaniya"]) ? $context["place_progivaniya"] : $this->getContext($context, "place_progivaniya")));
            foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
                // line 40
                echo "                        <td>";
                echo twig_escape_filter($this->env, twig_slice($this->env, $context["place"], 0, 5), "html", null, true);
                echo "</td>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 42
            echo "                    <td>Итог</td>
                </tr>
            </thead>
            <tbody>

            ";
            // line 47
            $context["flag"] = "0";
            // line 48
            echo "
            ";
            // line 49
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["organizations"]) ? $context["organizations"] : $this->getContext($context, "organizations")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["organization"]) {
                // line 50
                echo "                <tr class=\"pokazatels";
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "\">
                    <td class=\"name\">";
                // line 51
                echo twig_escape_filter($this->env, $this->getAttribute($context["organization"], "nameShort", array()), "html", null, true);
                echo "</td>

                    ";
                // line 53
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["place_progivaniya"]) ? $context["place_progivaniya"] : $this->getContext($context, "place_progivaniya")));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
                    // line 54
                    echo "
                            ";
                    // line 55
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["osugdeniy"]) ? $context["osugdeniy"] : $this->getContext($context, "osugdeniy")));
                    $context['loop'] = array(
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    );
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["osug"]) {
                        // line 56
                        echo "
                                ";
                        // line 57
                        if (($this->getAttribute($context["osug"], "name_full", array()) == $this->getAttribute($context["organization"], "nameFull", array()))) {
                            // line 58
                            echo "
                                    ";
                            // line 59
                            if (($this->getAttribute($context["osug"], "place_progivaniya", array()) == $context["place"])) {
                                // line 60
                                echo "
                                        <td class=\"pokazatel";
                                // line 61
                                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["loop"], "parent", array()), "loop", array()), "index", array()), "html", null, true);
                                echo "\">";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["osug"], 1, array(), "array"), "html", null, true);
                                echo "</td>

                                        ";
                                // line 63
                                $context["flag"] = "1";
                                // line 64
                                echo "
                                    ";
                            }
                            // line 66
                            echo "
                                ";
                        }
                        // line 68
                        echo "
                            ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['osug'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 70
                    echo "
                            ";
                    // line 71
                    if (((isset($context["flag"]) ? $context["flag"] : $this->getContext($context, "flag")) == "0")) {
                        // line 72
                        echo "                                <td></td>
                            ";
                    }
                    // line 74
                    echo "
                            ";
                    // line 75
                    $context["flag"] = "0";
                    // line 76
                    echo "
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 78
                echo "                    <td></td>
                </tr>
            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['organization'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 81
            echo "            </tbody>
            <tfoot>
                <tr>
                    <td>Всего</td>
                    ";
            // line 85
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["place_progivaniya"]) ? $context["place_progivaniya"] : $this->getContext($context, "place_progivaniya")));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
                // line 86
                echo "                        <td id=\"result";
                echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
                echo "\"></td>
                    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 88
            echo "                    <td id=\"vsego\"></td>
                </tr>
            </tfoot>
        </table>
    ";
        }
        // line 93
        echo "</div>

";
        
        $__internal_7b69a968377c0676375b38b386ea49612eb5a0f6f41f9a438072a2b41cc847d5->leave($__internal_7b69a968377c0676375b38b386ea49612eb5a0f6f41f9a438072a2b41cc847d5_prof);

    }

    // line 97
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_04be97c06f9a30b632969aedb61ac16dabb26a3743b88d8dff09ef9a92cfcdcf = $this->env->getExtension("native_profiler");
        $__internal_04be97c06f9a30b632969aedb61ac16dabb26a3743b88d8dff09ef9a92cfcdcf->enter($__internal_04be97c06f9a30b632969aedb61ac16dabb26a3743b88d8dff09ef9a92cfcdcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 98
        echo "
";
        
        $__internal_04be97c06f9a30b632969aedb61ac16dabb26a3743b88d8dff09ef9a92cfcdcf->leave($__internal_04be97c06f9a30b632969aedb61ac16dabb26a3743b88d8dff09ef9a92cfcdcf_prof);

    }

    public function getTemplateName()
    {
        return "otchet/ajax/zabolevaniya_otryad.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  342 => 98,  336 => 97,  327 => 93,  320 => 88,  303 => 86,  286 => 85,  280 => 81,  264 => 78,  249 => 76,  247 => 75,  244 => 74,  240 => 72,  238 => 71,  235 => 70,  220 => 68,  216 => 66,  212 => 64,  210 => 63,  203 => 61,  200 => 60,  198 => 59,  195 => 58,  193 => 57,  190 => 56,  173 => 55,  170 => 54,  153 => 53,  148 => 51,  143 => 50,  126 => 49,  123 => 48,  121 => 47,  114 => 42,  105 => 40,  101 => 39,  94 => 34,  92 => 33,  89 => 32,  85 => 30,  83 => 29,  80 => 28,  78 => 27,  75 => 26,  73 => 25,  62 => 17,  56 => 14,  46 => 6,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* {% include 'views/otchet/ajax/zabolevanie_menu.html' %}*/
/* */
/* <div class="row">*/
/*     <h3>Статистика заболевших осужденных по отрядам</h3>*/
/* */
/*     <div class="row" style="margin-bottom:50px">*/
/*         <form class="has-validation-callback" method="post" action="/otchetZabolevaniya/otryad" >*/
/*             <div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата от (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateOt" id="proverka_date" value="{{ dateOt }}">*/
/*             </div><div class="col-md-3">*/
/*                 <label class="required" for="proverka_date">Дата до (дд.мм.гггг)</label>*/
/*                 <input type="text" data-validation-format="dd.mm.yyyy" data-validation-optional="true" data-validation="date" class="form-control" required="required" name="dateDo" id="proverka_date" value="{{ dateDo }}">*/
/*             </div>*/
/*             <div class="col-md-3" style="margin-top:25px">*/
/*                 <input type="submit" class="btn btn-success" value="Выбрать">*/
/*             </div>*/
/*         </form>*/
/*     </div>*/
/* */
/*     {% if organizations is empty%}*/
/*         <p>Не добавлены учреждения</p>*/
/*     {% elseif place_progivaniya is empty%}*/
/*         <p>Не добавлены отряды</p>*/
/*     {% elseif osugdeniy is empty%}*/
/*         <p>Нет заболевших в выбранный период</p>*/
/*     {% else %}*/
/* */
/*         {% set place_progivaniya = ["1 отряд", "2 отряд", "3 отряд", "4 отряд", "5 отряд", "6 отряд", "7 отряд", "8 отряд", "9 отряд", "10 отряд", "11 отряд", "12 отряд", "ПКТ", "ЕПКТ", "ОСУОН", "ШИЗО", "Карантинное отделение"] %}*/
/* */
/*         <table class="table table-hover table-bordered numbers">*/
/*             <thead>*/
/*                 <tr>*/
/*                     <td>Учреждение</td>*/
/*                     {% for place in place_progivaniya %}*/
/*                         <td>{{ place|slice(0,5) }}</td>*/
/*                     {% endfor %}*/
/*                     <td>Итог</td>*/
/*                 </tr>*/
/*             </thead>*/
/*             <tbody>*/
/* */
/*             {% set flag = "0" %}*/
/* */
/*             {% for organization in organizations %}*/
/*                 <tr class="pokazatels{{loop.index}}">*/
/*                     <td class="name">{{organization.nameShort}}</td>*/
/* */
/*                     {% for place in place_progivaniya %}*/
/* */
/*                             {% for osug in osugdeniy %}*/
/* */
/*                                 {% if osug.name_full == organization.nameFull %}*/
/* */
/*                                     {% if osug.place_progivaniya == place %}*/
/* */
/*                                         <td class="pokazatel{{loop.parent.loop.index}}">{{ osug[1] }}</td>*/
/* */
/*                                         {% set flag = "1" %}*/
/* */
/*                                     {% endif %}*/
/* */
/*                                 {% endif %}*/
/* */
/*                             {% endfor %}*/
/* */
/*                             {% if flag == "0" %}*/
/*                                 <td></td>*/
/*                             {% endif %}*/
/* */
/*                             {% set flag = "0" %}*/
/* */
/*                     {% endfor %}*/
/*                     <td></td>*/
/*                 </tr>*/
/*             {% endfor %}*/
/*             </tbody>*/
/*             <tfoot>*/
/*                 <tr>*/
/*                     <td>Всего</td>*/
/*                     {% for place in place_progivaniya %}*/
/*                         <td id="result{{loop.index}}"></td>*/
/*                     {% endfor %}*/
/*                     <td id="vsego"></td>*/
/*                 </tr>*/
/*             </tfoot>*/
/*         </table>*/
/*     {% endif %}*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
