<?php

/* :fkuz:showPokazatelsIssledovaniya.html.twig */
class __TwigTemplate_efaf7a0f7dd31892acaa5865c476a696a059cf6de6dbb0b9ef43f1bdedf230b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":fkuz:showPokazatelsIssledovaniya.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38cfce829216a176a46665c10b5370d243855a4915bad5026f8601815fadae0a = $this->env->getExtension("native_profiler");
        $__internal_38cfce829216a176a46665c10b5370d243855a4915bad5026f8601815fadae0a->enter($__internal_38cfce829216a176a46665c10b5370d243855a4915bad5026f8601815fadae0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":fkuz:showPokazatelsIssledovaniya.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_38cfce829216a176a46665c10b5370d243855a4915bad5026f8601815fadae0a->leave($__internal_38cfce829216a176a46665c10b5370d243855a4915bad5026f8601815fadae0a_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_c7b7a10cc9822b420345aa64875eab30ef40915dfb7afb6cfa8bff6123444a8d = $this->env->getExtension("native_profiler");
        $__internal_c7b7a10cc9822b420345aa64875eab30ef40915dfb7afb6cfa8bff6123444a8d->enter($__internal_c7b7a10cc9822b420345aa64875eab30ef40915dfb7afb6cfa8bff6123444a8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
    <div class=\"row\">
        <h1>Выберите показатель:</h1>
    </div>

    <div class=\"row\">
        <table class=\"table table-hover main table-bordered\">
            <thead>
            <tr>
                <td>Показатель</td>
                <td>Не соответствие</td>
                <td><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></td>
                <td><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></td>
            </tr>
            </thead>
            <tbody>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pokazatelsIssledovaniya"]) ? $context["pokazatelsIssledovaniya"] : $this->getContext($context, "pokazatelsIssledovaniya")));
        foreach ($context['_seq'] as $context["_key"] => $context["pokazatel"]) {
            // line 21
            echo "                <tr>
                    <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["pokazatel"], "description", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["pokazatel"], "pokazatel", array()), "html", null, true);
            echo "</td>
                    <td><a href=\"/fkuz/editPokazatel/";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["pokazatel"], "id", array()), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></a></td>
                    <td><a href=\"/fkuz/deletePokazatel/";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["pokazatel"], "id", array()), "html", null, true);
            echo "\" class=\"delete_entity\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></a></td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pokazatel'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "            </tbody>
        </table>
    </div>

";
        
        $__internal_c7b7a10cc9822b420345aa64875eab30ef40915dfb7afb6cfa8bff6123444a8d->leave($__internal_c7b7a10cc9822b420345aa64875eab30ef40915dfb7afb6cfa8bff6123444a8d_prof);

    }

    // line 34
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_cedba9b2f4e79e69d93c5116b656eb53278dd9df464fb7b794b429ecaef46dcd = $this->env->getExtension("native_profiler");
        $__internal_cedba9b2f4e79e69d93c5116b656eb53278dd9df464fb7b794b429ecaef46dcd->enter($__internal_cedba9b2f4e79e69d93c5116b656eb53278dd9df464fb7b794b429ecaef46dcd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 35
        echo "
";
        
        $__internal_cedba9b2f4e79e69d93c5116b656eb53278dd9df464fb7b794b429ecaef46dcd->leave($__internal_cedba9b2f4e79e69d93c5116b656eb53278dd9df464fb7b794b429ecaef46dcd_prof);

    }

    public function getTemplateName()
    {
        return ":fkuz:showPokazatelsIssledovaniya.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 35,  98 => 34,  87 => 28,  78 => 25,  74 => 24,  70 => 23,  66 => 22,  63 => 21,  59 => 20,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/*     <div class="row">*/
/*         <h1>Выберите показатель:</h1>*/
/*     </div>*/
/* */
/*     <div class="row">*/
/*         <table class="table table-hover main table-bordered">*/
/*             <thead>*/
/*             <tr>*/
/*                 <td>Показатель</td>*/
/*                 <td>Не соответствие</td>*/
/*                 <td><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></td>*/
/*                 <td><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>*/
/*             </tr>*/
/*             </thead>*/
/*             <tbody>*/
/*             {% for pokazatel in pokazatelsIssledovaniya %}*/
/*                 <tr>*/
/*                     <td>{{ pokazatel.description }}</td>*/
/*                     <td>{{ pokazatel.pokazatel }}</td>*/
/*                     <td><a href="/fkuz/editPokazatel/{{ pokazatel.id }}"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></td>*/
/*                     <td><a href="/fkuz/deletePokazatel/{{ pokazatel.id }}" class="delete_entity"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>*/
/*                 </tr>*/
/*             {% endfor %}*/
/*             </tbody>*/
/*         </table>*/
/*     </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
