<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_cee596443ba63ee436353d4555cfcf923237dc8891a320bccee902c90e9d1ffe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_abcba37ffad227d3aee42a44a2e6d45ec3fbd6441c9c6a501e23104e1f2e6dc6 = $this->env->getExtension("native_profiler");
        $__internal_abcba37ffad227d3aee42a44a2e6d45ec3fbd6441c9c6a501e23104e1f2e6dc6->enter($__internal_abcba37ffad227d3aee42a44a2e6d45ec3fbd6441c9c6a501e23104e1f2e6dc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_abcba37ffad227d3aee42a44a2e6d45ec3fbd6441c9c6a501e23104e1f2e6dc6->leave($__internal_abcba37ffad227d3aee42a44a2e6d45ec3fbd6441c9c6a501e23104e1f2e6dc6_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_ca3fb52d3a36ceedbe1cd7c665fb4d6bc292d8d8b9174f19f7318c52f905aef3 = $this->env->getExtension("native_profiler");
        $__internal_ca3fb52d3a36ceedbe1cd7c665fb4d6bc292d8d8b9174f19f7318c52f905aef3->enter($__internal_ca3fb52d3a36ceedbe1cd7c665fb4d6bc292d8d8b9174f19f7318c52f905aef3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_ca3fb52d3a36ceedbe1cd7c665fb4d6bc292d8d8b9174f19f7318c52f905aef3->leave($__internal_ca3fb52d3a36ceedbe1cd7c665fb4d6bc292d8d8b9174f19f7318c52f905aef3_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_2dc95720674b257e9d76f94b5e32e892f23fee233555af2a9f66618b15d9a2f6 = $this->env->getExtension("native_profiler");
        $__internal_2dc95720674b257e9d76f94b5e32e892f23fee233555af2a9f66618b15d9a2f6->enter($__internal_2dc95720674b257e9d76f94b5e32e892f23fee233555af2a9f66618b15d9a2f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_2dc95720674b257e9d76f94b5e32e892f23fee233555af2a9f66618b15d9a2f6->leave($__internal_2dc95720674b257e9d76f94b5e32e892f23fee233555af2a9f66618b15d9a2f6_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
