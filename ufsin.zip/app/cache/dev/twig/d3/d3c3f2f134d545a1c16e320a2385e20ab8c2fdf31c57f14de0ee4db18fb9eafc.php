<?php

/* ::base.html.twig */
class __TwigTemplate_0f2fadb8d51163506090a6dd8f61b290956d817f68609906f622e7c4827471cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_91a9c7f8e0d9e8614274cd33157de0ff3366dd534c2cd401c01665168f89b0e8 = $this->env->getExtension("native_profiler");
        $__internal_91a9c7f8e0d9e8614274cd33157de0ff3366dd534c2cd401c01665168f89b0e8->enter($__internal_91a9c7f8e0d9e8614274cd33157de0ff3366dd534c2cd401c01665168f89b0e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>

    <body id=\"";
        // line 14
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

        ";
        // line 16
        $this->displayBlock('header', $context, $blocks);
        // line 91
        echo "
        <div class=\"container body-container\">
            ";
        // line 93
        $this->displayBlock('body', $context, $blocks);
        // line 104
        echo "        </div>

        ";
        // line 106
        $this->displayBlock('footer', $context, $blocks);
        // line 116
        echo "
        ";
        // line 117
        $this->displayBlock('javascripts', $context, $blocks);
        // line 123
        echo "    </body>
</html>
";
        
        $__internal_91a9c7f8e0d9e8614274cd33157de0ff3366dd534c2cd401c01665168f89b0e8->leave($__internal_91a9c7f8e0d9e8614274cd33157de0ff3366dd534c2cd401c01665168f89b0e8_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_3f3c505c6f13b0b88d0589a6de4c7d20c6c028a6e2cf307cc0195b1e7a0a5d3e = $this->env->getExtension("native_profiler");
        $__internal_3f3c505c6f13b0b88d0589a6de4c7d20c6c028a6e2cf307cc0195b1e7a0a5d3e->enter($__internal_3f3c505c6f13b0b88d0589a6de4c7d20c6c028a6e2cf307cc0195b1e7a0a5d3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Application";
        
        $__internal_3f3c505c6f13b0b88d0589a6de4c7d20c6c028a6e2cf307cc0195b1e7a0a5d3e->leave($__internal_3f3c505c6f13b0b88d0589a6de4c7d20c6c028a6e2cf307cc0195b1e7a0a5d3e_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_38eb98e32030f29dfa75be8f6c1ccb789c997d3bfa43a46a32f2cb440c3dd873 = $this->env->getExtension("native_profiler");
        $__internal_38eb98e32030f29dfa75be8f6c1ccb789c997d3bfa43a46a32f2cb440c3dd873->enter($__internal_38eb98e32030f29dfa75be8f6c1ccb789c997d3bfa43a46a32f2cb440c3dd873_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/app.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_38eb98e32030f29dfa75be8f6c1ccb789c997d3bfa43a46a32f2cb440c3dd873->leave($__internal_38eb98e32030f29dfa75be8f6c1ccb789c997d3bfa43a46a32f2cb440c3dd873_prof);

    }

    // line 14
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_3a519a797745014fc615de7ec6ed44d16d1e870d607e8f745340137bce9c9863 = $this->env->getExtension("native_profiler");
        $__internal_3a519a797745014fc615de7ec6ed44d16d1e870d607e8f745340137bce9c9863->enter($__internal_3a519a797745014fc615de7ec6ed44d16d1e870d607e8f745340137bce9c9863_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_3a519a797745014fc615de7ec6ed44d16d1e870d607e8f745340137bce9c9863->leave($__internal_3a519a797745014fc615de7ec6ed44d16d1e870d607e8f745340137bce9c9863_prof);

    }

    // line 16
    public function block_header($context, array $blocks = array())
    {
        $__internal_a2d61a83b1efd5faa16653c1999a2ed220cbd347e1bfac5673709442942f277b = $this->env->getExtension("native_profiler");
        $__internal_a2d61a83b1efd5faa16653c1999a2ed220cbd347e1bfac5673709442942f277b->enter($__internal_a2d61a83b1efd5faa16653c1999a2ed220cbd347e1bfac5673709442942f277b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 17
        echo "            <header>
                <nav class=\"navbar navbar-default\">
                    <div class=\"container-fluid\">
                        <div class=\"navbar-header\">
                            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                                <span class=\"sr-only\">Toggle navigation</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>

                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav\">
                                ";
        // line 31
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            echo "              
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Учреждения<span class=\"caret\"></span></a>

                                     ";
            // line 35
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Organization:allOrganizations"));
            echo "

                                </li>
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Заболеваемость TBS<span class=\"caret\"></span></a>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"/zabolevaniya/showLichnyiSostavs\">Личный состав</a></li>
                                        <li><a href=\"/zabolevaniya/showOsugdenyis\">Осужденные</a></li>
                                        <li><a href=\"/zabolevaniya/showOchags\">Очаг</a></li>
                                    </ul>
                                </li> 
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">ФКУЗ<span class=\"caret\"></span></a>
                                     
                                     ";
            // line 49
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Fkuz:allNameFilial"));
            echo "
                                     
                                </li>
                                <li>
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Отчеты<span class=\"caret\"></span></a>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"/otchetDogovor/common\">По договорам</a></li>
                                        <li><a href=\"/otchetProverka/\">По проверкам</a></li>
                                        <li><a href=\"/otchetIssledovaniya/\">По исследованиям</a></li>
                                        <li><a href=\"/otchetZabolevaniya/\">По заболевшим</a></li>
                                        <li><a href=\"/otchetFkuz/\">По ФКУЗ/Филиалу</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Добавить<span class=\"caret\"></span></a>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"";
            // line 65
            echo $this->env->getExtension('routing')->getPath("organization_new");
            echo "\">Учреждение</a></li>
                                        <li><a href=\"/fkuz/createFkuz\">ФКУЗ / Филиал</a></li>
                                        <li><a href=\"/issledovanie/createType\">Тип исследования</a></li>
                                        <li><a href=\"/dogovor/createType\">Тип договора</a></li>                       
                                        <li><a href=\"/organization/createObject\">Объект</a></li>
                                        
                                    </ul>
                                </li>                                
                                ";
        }
        // line 73
        echo "                                
                            </ul>
                            <ul class=\"nav navbar-nav navbar-right\">
                                
                                ";
        // line 77
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 78
            echo "                                    <li>
                                        <a href=\"";
            // line 79
            echo $this->env->getExtension('routing')->getPath("security_logout");
            echo "\">
                                            <i class=\"fa fa-sign-out\"></i>Выход
                                        </a>
                                    </li>
                                ";
        }
        // line 84
        echo "
                            </ul>
                        </div>
                    </div>
                </nav>
            </header>
        ";
        
        $__internal_a2d61a83b1efd5faa16653c1999a2ed220cbd347e1bfac5673709442942f277b->leave($__internal_a2d61a83b1efd5faa16653c1999a2ed220cbd347e1bfac5673709442942f277b_prof);

    }

    // line 93
    public function block_body($context, array $blocks = array())
    {
        $__internal_5b35805ca482f5f03674dca844c024915a3717010cc54ca61089d0465391eeff = $this->env->getExtension("native_profiler");
        $__internal_5b35805ca482f5f03674dca844c024915a3717010cc54ca61089d0465391eeff->enter($__internal_5b35805ca482f5f03674dca844c024915a3717010cc54ca61089d0465391eeff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 94
        echo "
                    ";
        // line 95
        $this->displayBlock('main', $context, $blocks);
        // line 98
        echo "
                    ";
        // line 99
        $this->displayBlock('sidebar', $context, $blocks);
        // line 102
        echo "
            ";
        
        $__internal_5b35805ca482f5f03674dca844c024915a3717010cc54ca61089d0465391eeff->leave($__internal_5b35805ca482f5f03674dca844c024915a3717010cc54ca61089d0465391eeff_prof);

    }

    // line 95
    public function block_main($context, array $blocks = array())
    {
        $__internal_ee77b7eac2c11198d31585a79b49f9216e45d81d9fb080486a1536340546c1c6 = $this->env->getExtension("native_profiler");
        $__internal_ee77b7eac2c11198d31585a79b49f9216e45d81d9fb080486a1536340546c1c6->enter($__internal_ee77b7eac2c11198d31585a79b49f9216e45d81d9fb080486a1536340546c1c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 96
        echo "                        
                    ";
        
        $__internal_ee77b7eac2c11198d31585a79b49f9216e45d81d9fb080486a1536340546c1c6->leave($__internal_ee77b7eac2c11198d31585a79b49f9216e45d81d9fb080486a1536340546c1c6_prof);

    }

    // line 99
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_9c0cb5377d157f12067980ba9341859fe4310add99248725cec83aae2cf30ae1 = $this->env->getExtension("native_profiler");
        $__internal_9c0cb5377d157f12067980ba9341859fe4310add99248725cec83aae2cf30ae1->enter($__internal_9c0cb5377d157f12067980ba9341859fe4310add99248725cec83aae2cf30ae1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 100
        echo "
                    ";
        
        $__internal_9c0cb5377d157f12067980ba9341859fe4310add99248725cec83aae2cf30ae1->leave($__internal_9c0cb5377d157f12067980ba9341859fe4310add99248725cec83aae2cf30ae1_prof);

    }

    // line 106
    public function block_footer($context, array $blocks = array())
    {
        $__internal_4c090cc47e5dbbfe429eafcaa8e208905f82f775ac1fd6cd29d51441b6faa6e7 = $this->env->getExtension("native_profiler");
        $__internal_4c090cc47e5dbbfe429eafcaa8e208905f82f775ac1fd6cd29d51441b6faa6e7->enter($__internal_4c090cc47e5dbbfe429eafcaa8e208905f82f775ac1fd6cd29d51441b6faa6e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 107
        echo "            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\"></div>
                        <div id=\"footer-resources\" class=\"col-md-6\"></div>
                    </div>
                </div>
            </footer>
        ";
        
        $__internal_4c090cc47e5dbbfe429eafcaa8e208905f82f775ac1fd6cd29d51441b6faa6e7->leave($__internal_4c090cc47e5dbbfe429eafcaa8e208905f82f775ac1fd6cd29d51441b6faa6e7_prof);

    }

    // line 117
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5c2446a0dc576df7902169eb408c17b41e7f969c06e408717ea7160a9a70df65 = $this->env->getExtension("native_profiler");
        $__internal_5c2446a0dc576df7902169eb408c17b41e7f969c06e408717ea7160a9a70df65->enter($__internal_5c2446a0dc576df7902169eb408c17b41e7f969c06e408717ea7160a9a70df65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 118
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/app.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/script.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/jquery.form-validator.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/date.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_5c2446a0dc576df7902169eb408c17b41e7f969c06e408717ea7160a9a70df65->leave($__internal_5c2446a0dc576df7902169eb408c17b41e7f969c06e408717ea7160a9a70df65_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  328 => 121,  324 => 120,  320 => 119,  315 => 118,  309 => 117,  294 => 107,  288 => 106,  280 => 100,  274 => 99,  266 => 96,  260 => 95,  252 => 102,  250 => 99,  247 => 98,  245 => 95,  242 => 94,  236 => 93,  223 => 84,  215 => 79,  212 => 78,  210 => 77,  204 => 73,  192 => 65,  173 => 49,  156 => 35,  149 => 31,  133 => 17,  127 => 16,  116 => 14,  107 => 9,  102 => 8,  96 => 7,  84 => 5,  75 => 123,  73 => 117,  70 => 116,  68 => 106,  64 => 104,  62 => 93,  58 => 91,  56 => 16,  51 => 14,  44 => 11,  42 => 7,  37 => 5,  31 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Application{% endblock %}</title>*/
/* */
/*         {% block stylesheets %}*/
/*             <link rel="stylesheet" href="{{ asset('css/app.css') }}">*/
/*             <link rel="stylesheet" href="{{ asset('css/style.css') }}">*/
/*         {% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/* */
/*     <body id="{% block body_id %}{% endblock %}">*/
/* */
/*         {% block header %}*/
/*             <header>*/
/*                 <nav class="navbar navbar-default">*/
/*                     <div class="container-fluid">*/
/*                         <div class="navbar-header">*/
/*                             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">*/
/*                                 <span class="sr-only">Toggle navigation</span>*/
/*                                 <span class="icon-bar"></span>*/
/*                                 <span class="icon-bar"></span>*/
/*                                 <span class="icon-bar"></span>*/
/*                             </button>*/
/*                         </div>*/
/* */
/*                         <div class="navbar-collapse collapse">*/
/*                             <ul class="nav navbar-nav">*/
/*                                 {% if app.user %}              */
/*                                 <li class="dropdown">*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Учреждения<span class="caret"></span></a>*/
/* */
/*                                      {{ render(controller('AppBundle:Organization:allOrganizations')) }}*/
/* */
/*                                 </li>*/
/*                                 <li class="dropdown">*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Заболеваемость TBS<span class="caret"></span></a>*/
/*                                     <ul class="dropdown-menu">*/
/*                                         <li><a href="/zabolevaniya/showLichnyiSostavs">Личный состав</a></li>*/
/*                                         <li><a href="/zabolevaniya/showOsugdenyis">Осужденные</a></li>*/
/*                                         <li><a href="/zabolevaniya/showOchags">Очаг</a></li>*/
/*                                     </ul>*/
/*                                 </li> */
/*                                 <li class="dropdown">*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">ФКУЗ<span class="caret"></span></a>*/
/*                                      */
/*                                      {{ render(controller('AppBundle:Fkuz:allNameFilial')) }}*/
/*                                      */
/*                                 </li>*/
/*                                 <li>*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Отчеты<span class="caret"></span></a>*/
/*                                     <ul class="dropdown-menu">*/
/*                                         <li><a href="/otchetDogovor/common">По договорам</a></li>*/
/*                                         <li><a href="/otchetProverka/">По проверкам</a></li>*/
/*                                         <li><a href="/otchetIssledovaniya/">По исследованиям</a></li>*/
/*                                         <li><a href="/otchetZabolevaniya/">По заболевшим</a></li>*/
/*                                         <li><a href="/otchetFkuz/">По ФКУЗ/Филиалу</a></li>*/
/*                                     </ul>*/
/*                                 </li>*/
/*                                 <li>*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Добавить<span class="caret"></span></a>*/
/*                                     <ul class="dropdown-menu">*/
/*                                         <li><a href="{{ path('organization_new') }}">Учреждение</a></li>*/
/*                                         <li><a href="/fkuz/createFkuz">ФКУЗ / Филиал</a></li>*/
/*                                         <li><a href="/issledovanie/createType">Тип исследования</a></li>*/
/*                                         <li><a href="/dogovor/createType">Тип договора</a></li>                       */
/*                                         <li><a href="/organization/createObject">Объект</a></li>*/
/*                                         */
/*                                     </ul>*/
/*                                 </li>                                */
/*                                 {% endif %}                                */
/*                             </ul>*/
/*                             <ul class="nav navbar-nav navbar-right">*/
/*                                 */
/*                                 {% if app.user %}*/
/*                                     <li>*/
/*                                         <a href="{{ path('security_logout') }}">*/
/*                                             <i class="fa fa-sign-out"></i>Выход*/
/*                                         </a>*/
/*                                     </li>*/
/*                                 {% endif %}*/
/* */
/*                             </ul>*/
/*                         </div>*/
/*                     </div>*/
/*                 </nav>*/
/*             </header>*/
/*         {% endblock %}*/
/* */
/*         <div class="container body-container">*/
/*             {% block body %}*/
/* */
/*                     {% block main %}*/
/*                         */
/*                     {% endblock %}*/
/* */
/*                     {% block sidebar %}*/
/* */
/*                     {% endblock %}*/
/* */
/*             {% endblock %}*/
/*         </div>*/
/* */
/*         {% block footer %}*/
/*             <footer>*/
/*                 <div class="container">*/
/*                     <div class="row">*/
/*                         <div id="footer-copyright" class="col-md-6"></div>*/
/*                         <div id="footer-resources" class="col-md-6"></div>*/
/*                     </div>*/
/*                 </div>*/
/*             </footer>*/
/*         {% endblock %}*/
/* */
/*         {% block javascripts %}*/
/*             <script src="{{ asset('js/app.js') }}"></script>*/
/*             <script src="{{ asset('js/script.js') }}"></script>*/
/*             <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>*/
/*             <script src="{{ asset('js/date.js') }}"></script>*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
