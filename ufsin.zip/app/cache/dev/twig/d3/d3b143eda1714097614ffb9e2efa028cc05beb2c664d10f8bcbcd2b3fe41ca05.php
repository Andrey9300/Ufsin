<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_e7d470ece4629ecb9908ecfa0f939d093c0625c1a86458ddd677071edb5d51d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2696e24a35a159e5d8a1f12763ff522fe45df4409392e351e330d309faa90c7 = $this->env->getExtension("native_profiler");
        $__internal_a2696e24a35a159e5d8a1f12763ff522fe45df4409392e351e330d309faa90c7->enter($__internal_a2696e24a35a159e5d8a1f12763ff522fe45df4409392e351e330d309faa90c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_a2696e24a35a159e5d8a1f12763ff522fe45df4409392e351e330d309faa90c7->leave($__internal_a2696e24a35a159e5d8a1f12763ff522fe45df4409392e351e330d309faa90c7_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
