<?php

/* :organization:showNakazaniyaProverka.html.twig */
class __TwigTemplate_dbde2b240aaa7c40b3d849fa36f192e7eb4feb9824c4c15ae05699d7e4c2d2b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":organization:showNakazaniyaProverka.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e8b5df1c343abab3f360d758f0dc97f5f59448b408a158d166a349cc6da4c6e = $this->env->getExtension("native_profiler");
        $__internal_6e8b5df1c343abab3f360d758f0dc97f5f59448b408a158d166a349cc6da4c6e->enter($__internal_6e8b5df1c343abab3f360d758f0dc97f5f59448b408a158d166a349cc6da4c6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":organization:showNakazaniyaProverka.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6e8b5df1c343abab3f360d758f0dc97f5f59448b408a158d166a349cc6da4c6e->leave($__internal_6e8b5df1c343abab3f360d758f0dc97f5f59448b408a158d166a349cc6da4c6e_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_4764b8707439536bae97bc00bac859c4e259b75af3c8cca0378c2a2f9d9804e2 = $this->env->getExtension("native_profiler");
        $__internal_4764b8707439536bae97bc00bac859c4e259b75af3c8cca0378c2a2f9d9804e2->enter($__internal_4764b8707439536bae97bc00bac859c4e259b75af3c8cca0378c2a2f9d9804e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">

    <div class=\"col-md-3\">
        <div>Выберите проверку</div>
        <select class=\"form-control\" id=\"proverkiNakazaniya\">
            ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverka"]) ? $context["proverka"] : $this->getContext($context, "proverka")));
        foreach ($context['_seq'] as $context["_key"] => $context["prov"]) {
            // line 11
            echo "            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["prov"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["prov"], "nomer", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["prov"], "date", array()), "d.m.Y"), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['prov'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "        </select>
    </div>
    
    <div class=\"col-md-3\"> 
        <div>Выберите наказание</div>
        <div id=\"nakazaniya\"></div>
    </div>
</div>
   
<div class=\"row\">  
    <div class=\"col-md-3\">
        <input type=\"submit\" value=\"Редактировать наказание\" class=\"btn btn-success\" id=\"showNakazaniya\" style=\"margin-top:30px\"/>
    </div>
</div>

";
        
        $__internal_4764b8707439536bae97bc00bac859c4e259b75af3c8cca0378c2a2f9d9804e2->leave($__internal_4764b8707439536bae97bc00bac859c4e259b75af3c8cca0378c2a2f9d9804e2_prof);

    }

    // line 30
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_3dfb7717a2794e5ff39ef3928a77b841da184526bc129ecf8ae01cd0eb1060ff = $this->env->getExtension("native_profiler");
        $__internal_3dfb7717a2794e5ff39ef3928a77b841da184526bc129ecf8ae01cd0eb1060ff->enter($__internal_3dfb7717a2794e5ff39ef3928a77b841da184526bc129ecf8ae01cd0eb1060ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 31
        echo "
";
        
        $__internal_3dfb7717a2794e5ff39ef3928a77b841da184526bc129ecf8ae01cd0eb1060ff->leave($__internal_3dfb7717a2794e5ff39ef3928a77b841da184526bc129ecf8ae01cd0eb1060ff_prof);

    }

    public function getTemplateName()
    {
        return ":organization:showNakazaniyaProverka.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 31,  88 => 30,  66 => 13,  53 => 11,  49 => 10,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/* */
/*     <div class="col-md-3">*/
/*         <div>Выберите проверку</div>*/
/*         <select class="form-control" id="proverkiNakazaniya">*/
/*             {% for prov in proverka %}*/
/*             <option value="{{ prov.id }}">{{ prov.nomer }}, {{prov.date|date("d.m.Y") }}</option>*/
/*             {% endfor %}*/
/*         </select>*/
/*     </div>*/
/*     */
/*     <div class="col-md-3"> */
/*         <div>Выберите наказание</div>*/
/*         <div id="nakazaniya"></div>*/
/*     </div>*/
/* </div>*/
/*    */
/* <div class="row">  */
/*     <div class="col-md-3">*/
/*         <input type="submit" value="Редактировать наказание" class="btn btn-success" id="showNakazaniya" style="margin-top:30px"/>*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
