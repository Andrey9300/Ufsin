<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_87da5b7994726e3ab3cc179b420ec7dc6962e2efb59211154ce424e46839584e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b60b466cc764317c4657b2a9d94506e56fbb49585afb4f3a1e90551b81f844d = $this->env->getExtension("native_profiler");
        $__internal_6b60b466cc764317c4657b2a9d94506e56fbb49585afb4f3a1e90551b81f844d->enter($__internal_6b60b466cc764317c4657b2a9d94506e56fbb49585afb4f3a1e90551b81f844d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_6b60b466cc764317c4657b2a9d94506e56fbb49585afb4f3a1e90551b81f844d->leave($__internal_6b60b466cc764317c4657b2a9d94506e56fbb49585afb4f3a1e90551b81f844d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
