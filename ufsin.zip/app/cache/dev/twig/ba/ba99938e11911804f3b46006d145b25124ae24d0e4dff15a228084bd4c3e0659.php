<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_4dc4d11c651077bfdacf30cfc542bc1081b67054450d13854eb145fe9a636c4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cbc8250f770e50ab2fc4686725f0188a1431d6212881f6e80f7bac2e1d869ba4 = $this->env->getExtension("native_profiler");
        $__internal_cbc8250f770e50ab2fc4686725f0188a1431d6212881f6e80f7bac2e1d869ba4->enter($__internal_cbc8250f770e50ab2fc4686725f0188a1431d6212881f6e80f7bac2e1d869ba4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_cbc8250f770e50ab2fc4686725f0188a1431d6212881f6e80f7bac2e1d869ba4->leave($__internal_cbc8250f770e50ab2fc4686725f0188a1431d6212881f6e80f7bac2e1d869ba4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
