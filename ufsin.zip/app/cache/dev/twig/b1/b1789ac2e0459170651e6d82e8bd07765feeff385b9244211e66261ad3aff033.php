<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_e38205574b21f09c759b98d7b9e336bc219cd92a770ba6039ad68f7674ed2f1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_96219e50da09343ba949066cf5dadb2ea5203f93e20e45956dd04e533ed06885 = $this->env->getExtension("native_profiler");
        $__internal_96219e50da09343ba949066cf5dadb2ea5203f93e20e45956dd04e533ed06885->enter($__internal_96219e50da09343ba949066cf5dadb2ea5203f93e20e45956dd04e533ed06885_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_96219e50da09343ba949066cf5dadb2ea5203f93e20e45956dd04e533ed06885->leave($__internal_96219e50da09343ba949066cf5dadb2ea5203f93e20e45956dd04e533ed06885_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
