<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_a2d4c21af9a80f2418ff921517d44225af72eff6e50aca00a1815c4157c336b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_270d023e795e481316c73e4c4477ea41f1bad2ef9ade220d7244e89a693df174 = $this->env->getExtension("native_profiler");
        $__internal_270d023e795e481316c73e4c4477ea41f1bad2ef9ade220d7244e89a693df174->enter($__internal_270d023e795e481316c73e4c4477ea41f1bad2ef9ade220d7244e89a693df174_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_270d023e795e481316c73e4c4477ea41f1bad2ef9ade220d7244e89a693df174->leave($__internal_270d023e795e481316c73e4c4477ea41f1bad2ef9ade220d7244e89a693df174_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
