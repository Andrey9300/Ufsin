<?php

/* views/otchet/ajax/proverka_menu.html */
class __TwigTemplate_44b925a7d226321c77511859817da53f3487d3125e1ec75f60bd894c21184ecd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetProverka/common\">Общее число проверок</a></li>
        <li><a href=\"/otchetProverka/narusheniya\">Нарушения по проверкам</a></li>
        <li><a href=\"/otchetProverka/narusheniyaObj\">Нарушения по объектам</a></li>
        <li><a href=\"/otchetProverka/nakazaniya\">Наказаниям</a></li>      
        <li><a href=\"/otchetProverka/narusheniyaAll\">Нарушения по всем учреждениям</a></li>      
        <li><a href=\"/otchetProverka/proverkaNakazaniya\">Сотрудники привлеченные к назазанию</a></li>
        <li><a href=\"/otchetProverka/proverkaNevyp\">Невыполненные нарушения</a></li>
        <li><a href=\"/otchetProverka/proverkaNarusheniyaVnimanie\">Нарушения требующие особого внимания</a></li>
    </ul>
</div>";
    }

    public function getTemplateName()
    {
        return "views/otchet/ajax/proverka_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetProverka/common">Общее число проверок</a></li>*/
/*         <li><a href="/otchetProverka/narusheniya">Нарушения по проверкам</a></li>*/
/*         <li><a href="/otchetProverka/narusheniyaObj">Нарушения по объектам</a></li>*/
/*         <li><a href="/otchetProverka/nakazaniya">Наказаниям</a></li>      */
/*         <li><a href="/otchetProverka/narusheniyaAll">Нарушения по всем учреждениям</a></li>      */
/*         <li><a href="/otchetProverka/proverkaNakazaniya">Сотрудники привлеченные к назазанию</a></li>*/
/*         <li><a href="/otchetProverka/proverkaNevyp">Невыполненные нарушения</a></li>*/
/*         <li><a href="/otchetProverka/proverkaNarusheniyaVnimanie">Нарушения требующие особого внимания</a></li>*/
/*     </ul>*/
/* </div>*/
