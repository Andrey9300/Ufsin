<?php

/* :fkuz:editSanZakl.html.twig */
class __TwigTemplate_6f9e3f59221ec2b5d98b2cce977afa126152d392115325d606f24fbc0f5608e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":fkuz:editSanZakl.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_01c075e75e8f19b41c0c059c5470b304429dddf010c8dc1242cc864403df53c4 = $this->env->getExtension("native_profiler");
        $__internal_01c075e75e8f19b41c0c059c5470b304429dddf010c8dc1242cc864403df53c4->enter($__internal_01c075e75e8f19b41c0c059c5470b304429dddf010c8dc1242cc864403df53c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":fkuz:editSanZakl.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_01c075e75e8f19b41c0c059c5470b304429dddf010c8dc1242cc864403df53c4->leave($__internal_01c075e75e8f19b41c0c059c5470b304429dddf010c8dc1242cc864403df53c4_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_79ced17219eaea3e11f830827d7f304e89bc9cea48b02f52607093ea898e9122 = $this->env->getExtension("native_profiler");
        $__internal_79ced17219eaea3e11f830827d7f304e89bc9cea48b02f52607093ea898e9122->enter($__internal_79ced17219eaea3e11f830827d7f304e89bc9cea48b02f52607093ea898e9122_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<h1>Редактировать санитарно-эпидемиологическое заключение</h1>

";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

<div class=\"row\">
    <div class=\"col-md-4\">
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nomer", array()), 'label', array("label" => "Номер"));
        echo "
        ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nomer", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "
        ";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date", array()), 'label', array("label" => "Дата"));
        echo "
        ";
        // line 14
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date", array()), 'widget', array("attr" => array("class" => "form-control", "data-validation" => "date", "data-validation-optional" => "true", "data-validation-format" => "dd.mm.yyyy")));
        echo "  
        ";
        // line 15
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vidDeytelnosti", array()), 'label', array("label" => "Вид деятельности"));
        echo "
        ";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vidDeytelnosti", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "        
    </div>
</div>

<div class=\"row\">
    <div class=\"col-md-4\">
        <input type=\"submit\" value=\"Сохранить изменения\" class=\"btn btn-success add_button\" />
    </div>
</div>

";
        
        $__internal_79ced17219eaea3e11f830827d7f304e89bc9cea48b02f52607093ea898e9122->leave($__internal_79ced17219eaea3e11f830827d7f304e89bc9cea48b02f52607093ea898e9122_prof);

    }

    // line 28
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_464c45f868f2f5c824e1f917ff5ae178036126e551fd1452b1f9713a2a270057 = $this->env->getExtension("native_profiler");
        $__internal_464c45f868f2f5c824e1f917ff5ae178036126e551fd1452b1f9713a2a270057->enter($__internal_464c45f868f2f5c824e1f917ff5ae178036126e551fd1452b1f9713a2a270057_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 29
        echo "
";
        
        $__internal_464c45f868f2f5c824e1f917ff5ae178036126e551fd1452b1f9713a2a270057->leave($__internal_464c45f868f2f5c824e1f917ff5ae178036126e551fd1452b1f9713a2a270057_prof);

    }

    public function getTemplateName()
    {
        return ":fkuz:editSanZakl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 29,  91 => 28,  73 => 16,  69 => 15,  65 => 14,  61 => 13,  57 => 12,  53 => 11,  46 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <h1>Редактировать санитарно-эпидемиологическое заключение</h1>*/
/* */
/* {{ form_start(form) }}*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         {{ form_label(form.nomer, 'Номер') }}*/
/*         {{ form_widget(form.nomer, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}*/
/*         {{ form_label(form.date, 'Дата') }}*/
/*         {{ form_widget(form.date, { 'attr': {'class': 'form-control', 'data-validation' : 'date', 'data-validation-optional' : 'true', 'data-validation-format' : 'dd.mm.yyyy'} }) }}  */
/*         {{ form_label(form.vidDeytelnosti, 'Вид деятельности') }}*/
/*         {{ form_widget(form.vidDeytelnosti, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}        */
/*     </div>*/
/* </div>*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         <input type="submit" value="Сохранить изменения" class="btn btn-success add_button" />*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
