<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_17b99d5519e3e0287b220922b5a5b6e4cc70d40bfca9508101902ceeaedab2dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e46b929022d433330c493ab8cb9d102d209aac671ed1402b75bee39a69476ec = $this->env->getExtension("native_profiler");
        $__internal_6e46b929022d433330c493ab8cb9d102d209aac671ed1402b75bee39a69476ec->enter($__internal_6e46b929022d433330c493ab8cb9d102d209aac671ed1402b75bee39a69476ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_6e46b929022d433330c493ab8cb9d102d209aac671ed1402b75bee39a69476ec->leave($__internal_6e46b929022d433330c493ab8cb9d102d209aac671ed1402b75bee39a69476ec_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
