<?php

/* fkuz/createSanZakl.html.twig */
class __TwigTemplate_f18ebacf26bd37576390db220b2411efa22d8c14833a4b514a5762087a1fa7bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "fkuz/createSanZakl.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f14899501d7cd909d47618c6cb71d3b97b0e511d365b6181d2b8567cef6d9577 = $this->env->getExtension("native_profiler");
        $__internal_f14899501d7cd909d47618c6cb71d3b97b0e511d365b6181d2b8567cef6d9577->enter($__internal_f14899501d7cd909d47618c6cb71d3b97b0e511d365b6181d2b8567cef6d9577_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "fkuz/createSanZakl.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f14899501d7cd909d47618c6cb71d3b97b0e511d365b6181d2b8567cef6d9577->leave($__internal_f14899501d7cd909d47618c6cb71d3b97b0e511d365b6181d2b8567cef6d9577_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_b35004eded9dc8be7d88f77c50f8a1fa092b075e4a1966264614b2ec5f835fa2 = $this->env->getExtension("native_profiler");
        $__internal_b35004eded9dc8be7d88f77c50f8a1fa092b075e4a1966264614b2ec5f835fa2->enter($__internal_b35004eded9dc8be7d88f77c50f8a1fa092b075e4a1966264614b2ec5f835fa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<h1>Добавить санитарно-эпидемиологическое заключение</h1>

";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

<div class=\"row\">
    <div class=\"col-md-4\">
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nomer", array()), 'label', array("label" => "Номер"));
        echo "
        ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nomer", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "
        ";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date", array()), 'label', array("label" => "Дата"));
        echo "
        ";
        // line 14
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date", array()), 'widget', array("attr" => array("class" => "form-control", "data-validation" => "date", "data-validation-optional" => "true", "data-validation-format" => "dd.mm.yyyy")));
        echo "  
        ";
        // line 15
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vidDeytelnosti", array()), 'label', array("label" => "Вид деятельности"));
        echo "
        ";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vidDeytelnosti", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "        
    </div>
</div>

<div class=\"row\">
    <div class=\"col-md-4\">
        <input type=\"submit\" value=\"Добавить\" class=\"btn btn-success add_button\" />
    </div>
</div>

";
        
        $__internal_b35004eded9dc8be7d88f77c50f8a1fa092b075e4a1966264614b2ec5f835fa2->leave($__internal_b35004eded9dc8be7d88f77c50f8a1fa092b075e4a1966264614b2ec5f835fa2_prof);

    }

    // line 28
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_cf46f7dca58a56bb94ca9fa4617f911f9c888d0caa5b39141e0df3d2a3b3619f = $this->env->getExtension("native_profiler");
        $__internal_cf46f7dca58a56bb94ca9fa4617f911f9c888d0caa5b39141e0df3d2a3b3619f->enter($__internal_cf46f7dca58a56bb94ca9fa4617f911f9c888d0caa5b39141e0df3d2a3b3619f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 29
        echo "
";
        
        $__internal_cf46f7dca58a56bb94ca9fa4617f911f9c888d0caa5b39141e0df3d2a3b3619f->leave($__internal_cf46f7dca58a56bb94ca9fa4617f911f9c888d0caa5b39141e0df3d2a3b3619f_prof);

    }

    public function getTemplateName()
    {
        return "fkuz/createSanZakl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 29,  91 => 28,  73 => 16,  69 => 15,  65 => 14,  61 => 13,  57 => 12,  53 => 11,  46 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <h1>Добавить санитарно-эпидемиологическое заключение</h1>*/
/* */
/* {{ form_start(form) }}*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         {{ form_label(form.nomer, 'Номер') }}*/
/*         {{ form_widget(form.nomer, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}*/
/*         {{ form_label(form.date, 'Дата') }}*/
/*         {{ form_widget(form.date, { 'attr': {'class': 'form-control', 'data-validation' : 'date', 'data-validation-optional' : 'true', 'data-validation-format' : 'dd.mm.yyyy'} }) }}  */
/*         {{ form_label(form.vidDeytelnosti, 'Вид деятельности') }}*/
/*         {{ form_widget(form.vidDeytelnosti, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}        */
/*     </div>*/
/* </div>*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         <input type="submit" value="Добавить" class="btn btn-success add_button" />*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
