<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_51dc76f6989618d83c7510f743195dac71ad77f6d80463b6d7e0db0fcd427e5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2225f0e9f9e5465b54955ce123e9fe73b58d940f4a8eed23db7dc33404fe5148 = $this->env->getExtension("native_profiler");
        $__internal_2225f0e9f9e5465b54955ce123e9fe73b58d940f4a8eed23db7dc33404fe5148->enter($__internal_2225f0e9f9e5465b54955ce123e9fe73b58d940f4a8eed23db7dc33404fe5148_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_2225f0e9f9e5465b54955ce123e9fe73b58d940f4a8eed23db7dc33404fe5148->leave($__internal_2225f0e9f9e5465b54955ce123e9fe73b58d940f4a8eed23db7dc33404fe5148_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
