<?php

/* :organization:showNarusheniyaProverka.html.twig */
class __TwigTemplate_07603755c2b3df37ce2281fbe1cb4d152ab61ea392b768a2fe70393681defe7c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":organization:showNarusheniyaProverka.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_01be0b2ac7046e14f1fecd36efc2d714f4903c580f6ba9f6cbda0582b1e0c3bc = $this->env->getExtension("native_profiler");
        $__internal_01be0b2ac7046e14f1fecd36efc2d714f4903c580f6ba9f6cbda0582b1e0c3bc->enter($__internal_01be0b2ac7046e14f1fecd36efc2d714f4903c580f6ba9f6cbda0582b1e0c3bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":organization:showNarusheniyaProverka.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_01be0b2ac7046e14f1fecd36efc2d714f4903c580f6ba9f6cbda0582b1e0c3bc->leave($__internal_01be0b2ac7046e14f1fecd36efc2d714f4903c580f6ba9f6cbda0582b1e0c3bc_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_d4e3d791ffa763f9e27ea160ecc73a92b273d2b45d4a068794d111930237c1ea = $this->env->getExtension("native_profiler");
        $__internal_d4e3d791ffa763f9e27ea160ecc73a92b273d2b45d4a068794d111930237c1ea->enter($__internal_d4e3d791ffa763f9e27ea160ecc73a92b273d2b45d4a068794d111930237c1ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">

    <div class=\"col-md-3\">
        <div>Выберите проверку</div>
        <select class=\"form-control\" id=\"proverkiNarusheniya\">
            ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["proverka"]) ? $context["proverka"] : $this->getContext($context, "proverka")));
        foreach ($context['_seq'] as $context["_key"] => $context["prov"]) {
            // line 11
            echo "            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["prov"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["prov"], "nomer", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["prov"], "date", array()), "d.m.Y"), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['prov'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "        </select>
    </div>
    
    <div class=\"col-md-3\"> 
        <div>Выберите нарушение</div>
        <div id=\"narusheniya\"></div>
    </div>
</div>
   
<div class=\"row\">  
    <div class=\"col-md-3\">
        <input type=\"submit\" value=\"Редактировать нарушение\" class=\"btn btn-success\" id=\"showNarusheniya\" style=\"margin-top:30px\"/>
    </div>
</div>

";
        
        $__internal_d4e3d791ffa763f9e27ea160ecc73a92b273d2b45d4a068794d111930237c1ea->leave($__internal_d4e3d791ffa763f9e27ea160ecc73a92b273d2b45d4a068794d111930237c1ea_prof);

    }

    // line 30
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_fa7fca38c450656252d7ae08a5e4dd65b0a790b1fbdc731afd0989ccd94b49e1 = $this->env->getExtension("native_profiler");
        $__internal_fa7fca38c450656252d7ae08a5e4dd65b0a790b1fbdc731afd0989ccd94b49e1->enter($__internal_fa7fca38c450656252d7ae08a5e4dd65b0a790b1fbdc731afd0989ccd94b49e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 31
        echo "
";
        
        $__internal_fa7fca38c450656252d7ae08a5e4dd65b0a790b1fbdc731afd0989ccd94b49e1->leave($__internal_fa7fca38c450656252d7ae08a5e4dd65b0a790b1fbdc731afd0989ccd94b49e1_prof);

    }

    public function getTemplateName()
    {
        return ":organization:showNarusheniyaProverka.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 31,  88 => 30,  66 => 13,  53 => 11,  49 => 10,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/* */
/*     <div class="col-md-3">*/
/*         <div>Выберите проверку</div>*/
/*         <select class="form-control" id="proverkiNarusheniya">*/
/*             {% for prov in proverka %}*/
/*             <option value="{{ prov.id }}">{{ prov.nomer }}, {{prov.date|date("d.m.Y") }}</option>*/
/*             {% endfor %}*/
/*         </select>*/
/*     </div>*/
/*     */
/*     <div class="col-md-3"> */
/*         <div>Выберите нарушение</div>*/
/*         <div id="narusheniya"></div>*/
/*     </div>*/
/* </div>*/
/*    */
/* <div class="row">  */
/*     <div class="col-md-3">*/
/*         <input type="submit" value="Редактировать нарушение" class="btn btn-success" id="showNarusheniya" style="margin-top:30px"/>*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
