<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_65e07a73b0c5c75d4a54255ded7ca75069377c62c3c2e05a9ec6f8b2929b6390 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4d4c9b276acb0dae6dcccdb1abdef75e1ff934bddd679eb91ed78a7f2f37ac48 = $this->env->getExtension("native_profiler");
        $__internal_4d4c9b276acb0dae6dcccdb1abdef75e1ff934bddd679eb91ed78a7f2f37ac48->enter($__internal_4d4c9b276acb0dae6dcccdb1abdef75e1ff934bddd679eb91ed78a7f2f37ac48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4d4c9b276acb0dae6dcccdb1abdef75e1ff934bddd679eb91ed78a7f2f37ac48->leave($__internal_4d4c9b276acb0dae6dcccdb1abdef75e1ff934bddd679eb91ed78a7f2f37ac48_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_93b76f19c7146183ad895ceda633b2435d76a53383c71251eaee7a11449d4a9f = $this->env->getExtension("native_profiler");
        $__internal_93b76f19c7146183ad895ceda633b2435d76a53383c71251eaee7a11449d4a9f->enter($__internal_93b76f19c7146183ad895ceda633b2435d76a53383c71251eaee7a11449d4a9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_93b76f19c7146183ad895ceda633b2435d76a53383c71251eaee7a11449d4a9f->leave($__internal_93b76f19c7146183ad895ceda633b2435d76a53383c71251eaee7a11449d4a9f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_422b88756bd9559e1c3df093390b690215396984865b695046a487d91e4dc911 = $this->env->getExtension("native_profiler");
        $__internal_422b88756bd9559e1c3df093390b690215396984865b695046a487d91e4dc911->enter($__internal_422b88756bd9559e1c3df093390b690215396984865b695046a487d91e4dc911_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_422b88756bd9559e1c3df093390b690215396984865b695046a487d91e4dc911->leave($__internal_422b88756bd9559e1c3df093390b690215396984865b695046a487d91e4dc911_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_3e04866b4b1d9a73776036616863e3818289b4e00bb87a9d5a015ff1f183a475 = $this->env->getExtension("native_profiler");
        $__internal_3e04866b4b1d9a73776036616863e3818289b4e00bb87a9d5a015ff1f183a475->enter($__internal_3e04866b4b1d9a73776036616863e3818289b4e00bb87a9d5a015ff1f183a475_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_3e04866b4b1d9a73776036616863e3818289b4e00bb87a9d5a015ff1f183a475->leave($__internal_3e04866b4b1d9a73776036616863e3818289b4e00bb87a9d5a015ff1f183a475_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
