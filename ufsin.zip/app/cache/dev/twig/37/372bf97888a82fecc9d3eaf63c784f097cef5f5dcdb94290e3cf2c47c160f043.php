<?php

/* TwigBundle:Exception:error500.html.twig */
class __TwigTemplate_3adb157ef4d841beeef65031f69dbd0247fc49340beebc7e8a4ecf49189d3675 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error500.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef8fb764268aa0c071b43ca77c9c647ffbe3749423e5ad11fd31985d127d3154 = $this->env->getExtension("native_profiler");
        $__internal_ef8fb764268aa0c071b43ca77c9c647ffbe3749423e5ad11fd31985d127d3154->enter($__internal_ef8fb764268aa0c071b43ca77c9c647ffbe3749423e5ad11fd31985d127d3154_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error500.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ef8fb764268aa0c071b43ca77c9c647ffbe3749423e5ad11fd31985d127d3154->leave($__internal_ef8fb764268aa0c071b43ca77c9c647ffbe3749423e5ad11fd31985d127d3154_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_8cf236e8155150d27169b911ba5076a9390c733e6810f6f95a2ca149102b87cd = $this->env->getExtension("native_profiler");
        $__internal_8cf236e8155150d27169b911ba5076a9390c733e6810f6f95a2ca149102b87cd->enter($__internal_8cf236e8155150d27169b911ba5076a9390c733e6810f6f95a2ca149102b87cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_8cf236e8155150d27169b911ba5076a9390c733e6810f6f95a2ca149102b87cd->leave($__internal_8cf236e8155150d27169b911ba5076a9390c733e6810f6f95a2ca149102b87cd_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_131e3de40568ae927c673218b3e970c06e885cf594d82dd0360bd93b1415ffa8 = $this->env->getExtension("native_profiler");
        $__internal_131e3de40568ae927c673218b3e970c06e885cf594d82dd0360bd93b1415ffa8->enter($__internal_131e3de40568ae927c673218b3e970c06e885cf594d82dd0360bd93b1415ffa8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1 class=\"text-danger\">Произошла ошибка</h1>

    <p class=\"lead\">
        Скорее всего вы не верно ввели данные или произошла техническая ошибка.
    </p>
    
    <p>
        Пожалуйста, проверьте вводимые данные <a href=\"#\" id=\"back_page\">на предыдущей странице</a> и/или повторите снова.
    </p>
";
        
        $__internal_131e3de40568ae927c673218b3e970c06e885cf594d82dd0360bd93b1415ffa8->leave($__internal_131e3de40568ae927c673218b3e970c06e885cf594d82dd0360bd93b1415ffa8_prof);

    }

    // line 17
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_9c1e88d51d03913b6f1e446dffdb538d932673cfc59053c5612f329b9a18e8ab = $this->env->getExtension("native_profiler");
        $__internal_9c1e88d51d03913b6f1e446dffdb538d932673cfc59053c5612f329b9a18e8ab->enter($__internal_9c1e88d51d03913b6f1e446dffdb538d932673cfc59053c5612f329b9a18e8ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 18
        echo "
";
        
        $__internal_9c1e88d51d03913b6f1e446dffdb538d932673cfc59053c5612f329b9a18e8ab->leave($__internal_9c1e88d51d03913b6f1e446dffdb538d932673cfc59053c5612f329b9a18e8ab_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error500.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 18,  70 => 17,  54 => 6,  48 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'error' %}*/
/* */
/* {% block main %}*/
/*     <h1 class="text-danger">Произошла ошибка</h1>*/
/* */
/*     <p class="lead">*/
/*         Скорее всего вы не верно ввели данные или произошла техническая ошибка.*/
/*     </p>*/
/*     */
/*     <p>*/
/*         Пожалуйста, проверьте вводимые данные <a href="#" id="back_page">на предыдущей странице</a> и/или повторите снова.*/
/*     </p>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
/* */
