<?php

/* main/index.html.twig */
class __TwigTemplate_aa0ae52d1d923692949679dee66c92bcf24c2cf0bd846a0fb17a7bbf7c3feb21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "main/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ebdf3b583d51fffc5238ce1d9f31e782a3bae8ceedeba8d24a2168472817d981 = $this->env->getExtension("native_profiler");
        $__internal_ebdf3b583d51fffc5238ce1d9f31e782a3bae8ceedeba8d24a2168472817d981->enter($__internal_ebdf3b583d51fffc5238ce1d9f31e782a3bae8ceedeba8d24a2168472817d981_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "main/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ebdf3b583d51fffc5238ce1d9f31e782a3bae8ceedeba8d24a2168472817d981->leave($__internal_ebdf3b583d51fffc5238ce1d9f31e782a3bae8ceedeba8d24a2168472817d981_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_c5fac240a6719131af9d8cc6391eccba95b718efdaee23504e6c15ace7bd7ecf = $this->env->getExtension("native_profiler");
        $__internal_c5fac240a6719131af9d8cc6391eccba95b718efdaee23504e6c15ace7bd7ecf->enter($__internal_c5fac240a6719131af9d8cc6391eccba95b718efdaee23504e6c15ace7bd7ecf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">
    <h1>Главная</h1>
</div>

";
        
        $__internal_c5fac240a6719131af9d8cc6391eccba95b718efdaee23504e6c15ace7bd7ecf->leave($__internal_c5fac240a6719131af9d8cc6391eccba95b718efdaee23504e6c15ace7bd7ecf_prof);

    }

    // line 11
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_50e1638ee170e43ed32e83f5afd757694d6fe3cab8ac39f6bf66b4e3f39471d1 = $this->env->getExtension("native_profiler");
        $__internal_50e1638ee170e43ed32e83f5afd757694d6fe3cab8ac39f6bf66b4e3f39471d1->enter($__internal_50e1638ee170e43ed32e83f5afd757694d6fe3cab8ac39f6bf66b4e3f39471d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 12
        echo "
";
        
        $__internal_50e1638ee170e43ed32e83f5afd757694d6fe3cab8ac39f6bf66b4e3f39471d1->leave($__internal_50e1638ee170e43ed32e83f5afd757694d6fe3cab8ac39f6bf66b4e3f39471d1_prof);

    }

    public function getTemplateName()
    {
        return "main/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 12,  53 => 11,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/*     <h1>Главная</h1>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
