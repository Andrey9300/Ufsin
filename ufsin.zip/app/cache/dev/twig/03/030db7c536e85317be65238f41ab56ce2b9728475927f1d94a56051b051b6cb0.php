<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_26a5084804ed174e6cb94543e14eb364d2145ce06af7428b1b5e0a651aa69412 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa3c08948fead77e1abc6d400b705b21e32409c00d10db27ee8a364cd27635f6 = $this->env->getExtension("native_profiler");
        $__internal_fa3c08948fead77e1abc6d400b705b21e32409c00d10db27ee8a364cd27635f6->enter($__internal_fa3c08948fead77e1abc6d400b705b21e32409c00d10db27ee8a364cd27635f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_fa3c08948fead77e1abc6d400b705b21e32409c00d10db27ee8a364cd27635f6->leave($__internal_fa3c08948fead77e1abc6d400b705b21e32409c00d10db27ee8a364cd27635f6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
