<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_b336b06b2027ea7d57cc6d236845f199889c75aad5afa475ee318f3e27d61bf5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_abe0af7225b45945cd606b6b4061cee20c4c99c1a5f4ce118d861043482aa35a = $this->env->getExtension("native_profiler");
        $__internal_abe0af7225b45945cd606b6b4061cee20c4c99c1a5f4ce118d861043482aa35a->enter($__internal_abe0af7225b45945cd606b6b4061cee20c4c99c1a5f4ce118d861043482aa35a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_abe0af7225b45945cd606b6b4061cee20c4c99c1a5f4ce118d861043482aa35a->leave($__internal_abe0af7225b45945cd606b6b4061cee20c4c99c1a5f4ce118d861043482aa35a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
