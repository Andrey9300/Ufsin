<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_9c3b37ed017b9e36e5e71faec6cc374400978df8b9ea37a88adfc588ec6c64f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75a9532b8162b6642317a951d0c2eb58be0026313c6a6602b1342cbb030819b7 = $this->env->getExtension("native_profiler");
        $__internal_75a9532b8162b6642317a951d0c2eb58be0026313c6a6602b1342cbb030819b7->enter($__internal_75a9532b8162b6642317a951d0c2eb58be0026313c6a6602b1342cbb030819b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_75a9532b8162b6642317a951d0c2eb58be0026313c6a6602b1342cbb030819b7->leave($__internal_75a9532b8162b6642317a951d0c2eb58be0026313c6a6602b1342cbb030819b7_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_a150385bf52e0e7efce4cddb8dba179d54271ce22ba578a5fa2584907835f90d = $this->env->getExtension("native_profiler");
        $__internal_a150385bf52e0e7efce4cddb8dba179d54271ce22ba578a5fa2584907835f90d->enter($__internal_a150385bf52e0e7efce4cddb8dba179d54271ce22ba578a5fa2584907835f90d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_a150385bf52e0e7efce4cddb8dba179d54271ce22ba578a5fa2584907835f90d->leave($__internal_a150385bf52e0e7efce4cddb8dba179d54271ce22ba578a5fa2584907835f90d_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
