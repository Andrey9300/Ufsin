<?php

/* :fkuz:showLabIssl.html.twig */
class __TwigTemplate_3af01484f5a017866ac9b2c4d9ce14d34f133245e07f900e90130456ecc27ab1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":fkuz:showLabIssl.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e69905c4edffefae40fcc7fe42844495660e5792441904b27a2230353c2e8ddb = $this->env->getExtension("native_profiler");
        $__internal_e69905c4edffefae40fcc7fe42844495660e5792441904b27a2230353c2e8ddb->enter($__internal_e69905c4edffefae40fcc7fe42844495660e5792441904b27a2230353c2e8ddb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":fkuz:showLabIssl.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e69905c4edffefae40fcc7fe42844495660e5792441904b27a2230353c2e8ddb->leave($__internal_e69905c4edffefae40fcc7fe42844495660e5792441904b27a2230353c2e8ddb_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_4d8887b4bce37a5b5c34aaf586ed98190fe075393caf90a843119742adb338e4 = $this->env->getExtension("native_profiler");
        $__internal_4d8887b4bce37a5b5c34aaf586ed98190fe075393caf90a843119742adb338e4->enter($__internal_4d8887b4bce37a5b5c34aaf586ed98190fe075393caf90a843119742adb338e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<div class=\"row\">

    <div class=\"col-md-3\">
        <div>Выберите исследование</div>
        <select class=\"form-control\" id=\"labIssledovaniyaFkuz\">
            ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["labIssl"]) ? $context["labIssl"] : $this->getContext($context, "labIssl")));
        foreach ($context['_seq'] as $context["_key"] => $context["issl"]) {
            // line 11
            echo "            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["issl"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["issl"], "nomer", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["issl"], "date", array()), "d.m.Y"), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['issl'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "        </select>
    </div>
    
    <div class=\"col-md-3\"> 
        <div>Выберите результат</div>
        <div id=\"issledovanie\"></div>
    </div>
</div>
   
<div class=\"row\">  
    <div class=\"col-md-3\">
        <input type=\"submit\" value=\"Редактировать исследование\" class=\"btn btn-success\" id=\"showIssledovaniyaFkuz\" style=\"margin-top:30px\"/>
    </div>
</div>

";
        
        $__internal_4d8887b4bce37a5b5c34aaf586ed98190fe075393caf90a843119742adb338e4->leave($__internal_4d8887b4bce37a5b5c34aaf586ed98190fe075393caf90a843119742adb338e4_prof);

    }

    // line 30
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_c85ef0fb652f3e8ff5cf2c400a33f28a6bfc15d5c421d52cbd6bd72335744ab6 = $this->env->getExtension("native_profiler");
        $__internal_c85ef0fb652f3e8ff5cf2c400a33f28a6bfc15d5c421d52cbd6bd72335744ab6->enter($__internal_c85ef0fb652f3e8ff5cf2c400a33f28a6bfc15d5c421d52cbd6bd72335744ab6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 31
        echo "
";
        
        $__internal_c85ef0fb652f3e8ff5cf2c400a33f28a6bfc15d5c421d52cbd6bd72335744ab6->leave($__internal_c85ef0fb652f3e8ff5cf2c400a33f28a6bfc15d5c421d52cbd6bd72335744ab6_prof);

    }

    public function getTemplateName()
    {
        return ":fkuz:showLabIssl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 31,  88 => 30,  66 => 13,  53 => 11,  49 => 10,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row">*/
/* */
/*     <div class="col-md-3">*/
/*         <div>Выберите исследование</div>*/
/*         <select class="form-control" id="labIssledovaniyaFkuz">*/
/*             {% for issl in labIssl %}*/
/*             <option value="{{ issl.id }}">{{ issl.nomer }}, {{issl.date|date("d.m.Y") }}</option>*/
/*             {% endfor %}*/
/*         </select>*/
/*     </div>*/
/*     */
/*     <div class="col-md-3"> */
/*         <div>Выберите результат</div>*/
/*         <div id="issledovanie"></div>*/
/*     </div>*/
/* </div>*/
/*    */
/* <div class="row">  */
/*     <div class="col-md-3">*/
/*         <input type="submit" value="Редактировать исследование" class="btn btn-success" id="showIssledovaniyaFkuz" style="margin-top:30px"/>*/
/*     </div>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
