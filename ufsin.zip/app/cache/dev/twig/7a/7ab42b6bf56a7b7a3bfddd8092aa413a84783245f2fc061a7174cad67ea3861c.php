<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_b8e96d4854ef6011f14de8d7b4032a09228d05b31c13deb4aadefadc07ec8f28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1bbe1f723708d1b5fa192435491eec75f0273f62ef6b141b8354d38b55998c9 = $this->env->getExtension("native_profiler");
        $__internal_f1bbe1f723708d1b5fa192435491eec75f0273f62ef6b141b8354d38b55998c9->enter($__internal_f1bbe1f723708d1b5fa192435491eec75f0273f62ef6b141b8354d38b55998c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_f1bbe1f723708d1b5fa192435491eec75f0273f62ef6b141b8354d38b55998c9->leave($__internal_f1bbe1f723708d1b5fa192435491eec75f0273f62ef6b141b8354d38b55998c9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
