<?php

/* fkuz/showFilial.html.twig */
class __TwigTemplate_89838e4e723e773fe7ccba8ce8c83ebb0de10385f7341ba14d884cdd44de7c60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "fkuz/showFilial.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<div class=\"row\"> 
    <h1>«";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fkuz"]) ? $context["fkuz"] : null), "nameShort", array()), "html", null, true);
        echo "»</h1>
    <div class=\"col-md-12\">
        <div class=\"row\">    
\t\t\t<div class=\"col-md-6\">
\t\t\t\t<table class=\"table table-hover main\">
\t\t\t\t\t<tbody>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Фактический адрес:</td>
\t\t\t\t\t\t\t<td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fkuz"]) ? $context["fkuz"] : null), "address", array()), "html", null, true);
        echo "</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Руководитель:</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rukovoditel"]) ? $context["rukovoditel"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["ruk"]) {
            // line 20
            echo "\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ruk"], "fio", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ruk"], "zvanie", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ruk'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t";
        // line 24
        if ((isset($context["rukZams"]) ? $context["rukZams"] : null)) {
            // line 25
            echo "\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>Замы:</td>
\t\t\t\t\t\t\t<td>           
\t\t\t\t\t\t\t\t";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["rukZams"]) ? $context["rukZams"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["ruk_zam"]) {
                // line 29
                echo "\t\t\t\t\t\t\t\t\t<div>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["ruk_zam"], "fio", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["ruk_zam"], "zvanie", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["ruk_zam"], "oblastDeaytelnosti", array()), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ruk_zam'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            echo "\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t";
        }
        // line 34
        echo "\t\t\t\t\t</tbody>
\t\t\t\t</table>
\t\t\t</div>
        </div>

\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t";
        // line 41
        if ((isset($context["proverkaNakazaniyaFkuz"]) ? $context["proverkaNakazaniyaFkuz"] : null)) {
            // line 42
            echo "\t\t\t\t\t<hr/>
\t\t\t\t\t<h4 class=\"withDates\">Привлеченные к наказанию</h4>

\t\t\t\t\t<table class=\"table table-hover main narusheniyaOrganization\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>ФИО</td>
\t\t\t\t\t\t\t<td>Номер</td>
\t\t\t\t\t\t\t<td>Дата</td>
\t\t\t\t\t\t\t<td>Тип наказания</td>
\t\t\t\t\t\t\t<td><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></td>
\t\t\t\t\t\t\t<td><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</thead>
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t";
            // line 57
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["proverkaNakazaniyaFkuz"]) ? $context["proverkaNakazaniyaFkuz"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["proverka"]) {
                // line 58
                echo "\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>";
                // line 59
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "fio", array()), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t\t<td>";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "nomer", array()), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t\t<td>";
                // line 61
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["proverka"], "date", array()), "d.m.Y"), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t\t<td>";
                // line 62
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "type", array()), "html", null, true);
                echo "</td>
\t\t\t\t\t\t\t\t<td><a href=\"/fkuz/editNakazanieFkuz/";
                // line 63
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\"><span class=\"glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></a></td>
\t\t\t\t\t\t\t\t<td><a href=\"/fkuz/deleteNakazanieFkuz/";
                // line 64
                echo twig_escape_filter($this->env, $this->getAttribute($context["proverka"], "id", array()), "html", null, true);
                echo "\" class=\"delete_entity\"><span class=\"glyphicon glyphicon-remove\" aria-hidden=\"true\"></span></a></td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['proverka'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 67
            echo "\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t";
        }
        // line 70
        echo "\t\t\t</div>
\t\t</div>

        <div class=\"row\" style=\"margin-bottom: 50px\">
            <hr/>
            <ul class=\"nav navbar-nav add\">
                <li class=\"dropdown\">
                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">Исследования<span class=\"caret\"></span></a>
                    <ul class=\"dropdown-menu\">
                        <li><a href=\"/fkuz/createIssledovanie/";
        // line 79
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fkuz"]) ? $context["fkuz"] : null), "id", array()), "html", null, true);
        echo "\">Добавить лабораторное исследование</a></li>
                        <li><a href=\"/fkuz/showNamesIssledovanie/";
        // line 80
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fkuz"]) ? $context["fkuz"] : null), "id", array()), "html", null, true);
        echo "\">Редактировать лабораторное исследование</a></li>
                    </ul>
                </li>
\t\t\t\t<li><a href=\"/fkuz/createProverkaFkuz/";
        // line 83
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fkuz"]) ? $context["fkuz"] : null), "id", array()), "html", null, true);
        echo "\">Добавить Проверку</a></li>
                <li><a href=\"/fkuz/editFkuz/";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fkuz"]) ? $context["fkuz"] : null), "id", array()), "html", null, true);
        echo "\">Редактировать филиал</a></li>
                <li><a href=\"/fkuz/deleteFkuz/";
        // line 85
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fkuz"]) ? $context["fkuz"] : null), "id", array()), "html", null, true);
        echo "\" class=\"delete_entity\">Удалить филиал</a></li>
            </ul>
        </div>
    </div>
</div>


";
    }

    // line 94
    public function block_sidebar($context, array $blocks = array())
    {
        // line 95
        echo "
";
    }

    public function getTemplateName()
    {
        return "fkuz/showFilial.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 95,  213 => 94,  201 => 85,  197 => 84,  193 => 83,  187 => 80,  183 => 79,  172 => 70,  167 => 67,  158 => 64,  154 => 63,  150 => 62,  146 => 61,  142 => 60,  138 => 59,  135 => 58,  131 => 57,  114 => 42,  112 => 41,  103 => 34,  98 => 31,  85 => 29,  81 => 28,  76 => 25,  74 => 24,  70 => 22,  59 => 20,  55 => 19,  47 => 14,  36 => 6,  32 => 4,  29 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <div class="row"> */
/*     <h1>«{{ fkuz.nameShort }}»</h1>*/
/*     <div class="col-md-12">*/
/*         <div class="row">    */
/* 			<div class="col-md-6">*/
/* 				<table class="table table-hover main">*/
/* 					<tbody>*/
/* 						<tr>*/
/* 							<td>Фактический адрес:</td>*/
/* 							<td>{{ fkuz.address }}</td>*/
/* 						</tr>*/
/* 						<tr>*/
/* 							<td>Руководитель:</td>*/
/* 							<td>*/
/* 								{% for ruk in rukovoditel %}*/
/* 									{{ ruk.fio}}, {{ ruk.zvanie}}*/
/* 								{% endfor %}*/
/* 							</td>*/
/* 						</tr>*/
/* 						{% if rukZams %}*/
/* 						<tr>*/
/* 							<td>Замы:</td>*/
/* 							<td>           */
/* 								{% for ruk_zam in rukZams %}*/
/* 									<div>{{ ruk_zam.fio}}, {{ ruk_zam.zvanie}}, {{ ruk_zam.oblastDeaytelnosti}}</div>*/
/* 								{% endfor %}*/
/* 							</td>*/
/* 						</tr>*/
/* 						{% endif %}*/
/* 					</tbody>*/
/* 				</table>*/
/* 			</div>*/
/*         </div>*/
/* */
/* 		<div class="row">*/
/* 			<div class="col-md-12">*/
/* 				{% if proverkaNakazaniyaFkuz %}*/
/* 					<hr/>*/
/* 					<h4 class="withDates">Привлеченные к наказанию</h4>*/
/* */
/* 					<table class="table table-hover main narusheniyaOrganization">*/
/* 						<thead>*/
/* 						<tr>*/
/* 							<td>ФИО</td>*/
/* 							<td>Номер</td>*/
/* 							<td>Дата</td>*/
/* 							<td>Тип наказания</td>*/
/* 							<td><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></td>*/
/* 							<td><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></td>*/
/* 						</tr>*/
/* 						</thead>*/
/* 						<tbody>*/
/* 						{% for proverka in proverkaNakazaniyaFkuz %}*/
/* 							<tr>*/
/* 								<td>{{ proverka.fio }}</td>*/
/* 								<td>{{ proverka.nomer }}</td>*/
/* 								<td>{{ proverka.date|date("d.m.Y") }}</td>*/
/* 								<td>{{ proverka.type }}</td>*/
/* 								<td><a href="/fkuz/editNakazanieFkuz/{{ proverka.id }}"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></td>*/
/* 								<td><a href="/fkuz/deleteNakazanieFkuz/{{ proverka.id }}" class="delete_entity"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>*/
/* 							</tr>*/
/* 						{% endfor %}*/
/* 						</tbody>*/
/* 					</table>*/
/* 				{% endif %}*/
/* 			</div>*/
/* 		</div>*/
/* */
/*         <div class="row" style="margin-bottom: 50px">*/
/*             <hr/>*/
/*             <ul class="nav navbar-nav add">*/
/*                 <li class="dropdown">*/
/*                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Исследования<span class="caret"></span></a>*/
/*                     <ul class="dropdown-menu">*/
/*                         <li><a href="/fkuz/createIssledovanie/{{ fkuz.id }}">Добавить лабораторное исследование</a></li>*/
/*                         <li><a href="/fkuz/showNamesIssledovanie/{{ fkuz.id }}">Редактировать лабораторное исследование</a></li>*/
/*                     </ul>*/
/*                 </li>*/
/* 				<li><a href="/fkuz/createProverkaFkuz/{{ fkuz.id }}">Добавить Проверку</a></li>*/
/*                 <li><a href="/fkuz/editFkuz/{{ fkuz.id }}">Редактировать филиал</a></li>*/
/*                 <li><a href="/fkuz/deleteFkuz/{{ fkuz.id }}" class="delete_entity">Удалить филиал</a></li>*/
/*             </ul>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
/* */
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
