<?php

/* views/otchet/ajax/zabolevanie_menu.html */
class __TwigTemplate_c2131650b7b9ed5a3b1172130015fceacde6ea2940642972b7d139ed26b8f3ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_26efecaeba42e60475d55998847dc2cfffdbcda21056d77e82fb5d082d5f47f3 = $this->env->getExtension("native_profiler");
        $__internal_26efecaeba42e60475d55998847dc2cfffdbcda21056d77e82fb5d082d5f47f3->enter($__internal_26efecaeba42e60475d55998847dc2cfffdbcda21056d77e82fb5d082d5f47f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "views/otchet/ajax/zabolevanie_menu.html"));

        // line 1
        echo "<div  class=\"row\">
    <ul class=\"nav navbar-nav add\">
        <li><a href=\"/otchetZabolevaniya/\">Общее</a></li>
        <li><a href=\"/otchetZabolevaniya/kontaktnye\">Общее (Контактные)</a></li>
        <li><a href=\"/otchetZabolevaniya/otryad\">Отряды</a></li>
        <li><a href=\"/otchetZabolevaniya/otryadKontakt\">Отряды (Контактные)</a></li>
        <li><a href=\"/otchetZabolevaniya/mbt\">МБТ</a></li>
        <li><a href=\"/otchetZabolevaniya/viyavlenie\">Выявление</a></li>
        <li><a href=\"/otchetZabolevaniya/recidiv\">Заболеваемость</a></li>
        <li><a href=\"/otchetZabolevaniya/postupilIs\">Поступление</a></li>
        <li><a href=\"/otchetZabolevaniya/addressCommon\">Адрес общий</a></li>
        <li><a href=\"/otchetZabolevaniya/ochag\">Очаг</a></li>
        <li><a href=\"/otchetZabolevaniya/patologiya\">Сопутствующая патология</a></li>
        <li><a href=\"/otchetZabolevaniya/povtorno\">Повторно заболевшие</a></li>
        <li><a href=\"/otchetZabolevaniya/izKontaktnyh\">Заболевшие из IV ГДУ</a></li>
    </ul>
</div>";
        
        $__internal_26efecaeba42e60475d55998847dc2cfffdbcda21056d77e82fb5d082d5f47f3->leave($__internal_26efecaeba42e60475d55998847dc2cfffdbcda21056d77e82fb5d082d5f47f3_prof);

    }

    public function getTemplateName()
    {
        return "views/otchet/ajax/zabolevanie_menu.html";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div  class="row">*/
/*     <ul class="nav navbar-nav add">*/
/*         <li><a href="/otchetZabolevaniya/">Общее</a></li>*/
/*         <li><a href="/otchetZabolevaniya/kontaktnye">Общее (Контактные)</a></li>*/
/*         <li><a href="/otchetZabolevaniya/otryad">Отряды</a></li>*/
/*         <li><a href="/otchetZabolevaniya/otryadKontakt">Отряды (Контактные)</a></li>*/
/*         <li><a href="/otchetZabolevaniya/mbt">МБТ</a></li>*/
/*         <li><a href="/otchetZabolevaniya/viyavlenie">Выявление</a></li>*/
/*         <li><a href="/otchetZabolevaniya/recidiv">Заболеваемость</a></li>*/
/*         <li><a href="/otchetZabolevaniya/postupilIs">Поступление</a></li>*/
/*         <li><a href="/otchetZabolevaniya/addressCommon">Адрес общий</a></li>*/
/*         <li><a href="/otchetZabolevaniya/ochag">Очаг</a></li>*/
/*         <li><a href="/otchetZabolevaniya/patologiya">Сопутствующая патология</a></li>*/
/*         <li><a href="/otchetZabolevaniya/povtorno">Повторно заболевшие</a></li>*/
/*         <li><a href="/otchetZabolevaniya/izKontaktnyh">Заболевшие из IV ГДУ</a></li>*/
/*     </ul>*/
/* </div>*/
