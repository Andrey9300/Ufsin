<?php

/* :organization:createObject.html.twig */
class __TwigTemplate_cec08f48199c4971454991e2b6217c4ced7efd979f0b2d69a8d467ad6ff7835e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":organization:createObject.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93303236f57b7167f015889223756301f688f73d4408863b86eeadb8dd8ec550 = $this->env->getExtension("native_profiler");
        $__internal_93303236f57b7167f015889223756301f688f73d4408863b86eeadb8dd8ec550->enter($__internal_93303236f57b7167f015889223756301f688f73d4408863b86eeadb8dd8ec550_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":organization:createObject.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_93303236f57b7167f015889223756301f688f73d4408863b86eeadb8dd8ec550->leave($__internal_93303236f57b7167f015889223756301f688f73d4408863b86eeadb8dd8ec550_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_a6c496fe778282eff15be02947dec042a0ecedb7ab63580b9dc024766e16fe70 = $this->env->getExtension("native_profiler");
        $__internal_a6c496fe778282eff15be02947dec042a0ecedb7ab63580b9dc024766e16fe70->enter($__internal_a6c496fe778282eff15be02947dec042a0ecedb7ab63580b9dc024766e16fe70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
<h1>Добавить объект</h1>

";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "

<div class=\"row\">
    <div class=\"col-md-4\">
        ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label', array("label" => "Наименование"));
        echo "
        ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "form-control", "spellcheck" => "true")));
        echo "
        <input type=\"submit\" value=\"Добавить\" class=\"btn btn-success add_button\" />
    </div>
    <div class=\"col-md-4\"></div>
    <div class=\"col-md-4 list_now\">
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["objects"]) ? $context["objects"] : $this->getContext($context, "objects")));
        foreach ($context['_seq'] as $context["_key"] => $context["object"]) {
            // line 18
            echo "            <div>Добавленные <strong>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["object"], "name", array()), "html", null, true);
            echo "</strong><div style=\"display:inline\"><button style=\"float:none\" id_now=\"/organization/deleteObject/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["object"], "id", array()), "html", null, true);
            echo "\" class=\"close delete_now\" type=\"button\"><span aria-hidden=\"true\">×</span></button></div></div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['object'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "    </div>      
</div>

";
        
        $__internal_a6c496fe778282eff15be02947dec042a0ecedb7ab63580b9dc024766e16fe70->leave($__internal_a6c496fe778282eff15be02947dec042a0ecedb7ab63580b9dc024766e16fe70_prof);

    }

    // line 25
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_1b79c8bb32c58639a6572b3c021da777f9e9590bcfd7181ada285a028e998f82 = $this->env->getExtension("native_profiler");
        $__internal_1b79c8bb32c58639a6572b3c021da777f9e9590bcfd7181ada285a028e998f82->enter($__internal_1b79c8bb32c58639a6572b3c021da777f9e9590bcfd7181ada285a028e998f82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 26
        echo "
";
        
        $__internal_1b79c8bb32c58639a6572b3c021da777f9e9590bcfd7181ada285a028e998f82->leave($__internal_1b79c8bb32c58639a6572b3c021da777f9e9590bcfd7181ada285a028e998f82_prof);

    }

    public function getTemplateName()
    {
        return ":organization:createObject.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 26,  90 => 25,  80 => 20,  69 => 18,  65 => 17,  57 => 12,  53 => 11,  46 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block main %}*/
/* */
/* <h1>Добавить объект</h1>*/
/* */
/* {{ form_start(form) }}*/
/* */
/* <div class="row">*/
/*     <div class="col-md-4">*/
/*         {{ form_label(form.name, 'Наименование') }}*/
/*         {{ form_widget(form.name, { 'attr': {'class': 'form-control', 'spellcheck' : 'true'} }) }}*/
/*         <input type="submit" value="Добавить" class="btn btn-success add_button" />*/
/*     </div>*/
/*     <div class="col-md-4"></div>*/
/*     <div class="col-md-4 list_now">*/
/*         {% for object in objects %}*/
/*             <div>Добавленные <strong>{{ object.name }}</strong><div style="display:inline"><button style="float:none" id_now="/organization/deleteObject/{{ object.id }}" class="close delete_now" type="button"><span aria-hidden="true">×</span></button></div></div>*/
/*         {% endfor %}*/
/*     </div>      */
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/* */
/* {% endblock %}*/
